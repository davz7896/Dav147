
<?php
	include "koneksi.php";

	$id = $_POST["nim"];

	$sql = "INSERT INTO marketer VALUES ('$id')";
	$query = mysql_query($sql) or die (mysql_error());

	echo "Sukses!";

?>