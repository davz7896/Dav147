<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" type="image/jpg" href="img/logo/logo.jpg">
  <title>Tridjaya Kartika Groub</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/format-rupiah.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
	  
      <a class="navbar-brand" href="index.php">Tridjaya Kartika Groub</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
   		<li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Master Data
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="Marketer/index.php">Data Rekening</a></li>
          <li><a href="data_barang.php">Data Kavling</a></li>
          <li><a href="data_customer.php">Data Customer</a></li>
          <li><a href="Marketer/index.php">Data Marketer</a></li>
		  
		</ul>
		<li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Transaksi
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="pembelian.php">Pembelian</a></li>
          <li><a href="penjualan.php">Penjualan</a></li>
          <li><a href="pembayaran_hutang.php">Pembayaran Hutang</a></li>
		  <li><a href="opname.php">Stok Opname Barang</a></li>
		</ul>
		<li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Laporan
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="laporan_pembelian.php">Laporan Pembelian</a></li>
          <li><a href="laporan_penjualan.php">Laporan Penjualan</a></li>
          <li><a href="laporan_stok.php">Laporan Stok</a></li>
		</ul>
		</ul>
      
    </div>
  </div>
</nav>
 

</body>
</html>