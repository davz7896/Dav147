 <div class="row">
    <div class="col-md-12">
      <div class="page-header">
        <h4>
          <i class="glyphicon glyphicon-user"></i> <?=$_SESSION['nama'];?>
          
          <a class="btn btn-success pull-right" href="#" data-target="#modal_tambah" data-toggle="modal">
            <i class="glyphicon glyphicon-plus"></i> Tambah
          </a>
        </h4>
      </div>

  <?php  
  // fungsi untuk menampilkan pesan
  // jika alert = "" (kosong)
  // tampilkan pesan "" (kosong)
  if (empty($_GET['alert'])) {
    echo "";
  }
  // jika alert = 1
  // tampilkan pesan Sukses "Mahasiswa baru berhasil disimpan" 
  elseif ($_GET['alert'] == 1) {
    echo "<div class='alert alert-success alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
              <span aria-hidden='true'>&times;</span>
            </button>
            <strong><i class='glyphicon glyphicon-ok-circle'></i> Sukses!</strong> Data Kavling berhasil disimpan.
          </div>";
  } 
  // jika alert = 2
  // tampilkan pesan Sukses "Mahasiswa berhasil diubah"
  elseif ($_GET['alert'] == 2) {
    echo "<div class='alert alert-success alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
              <span aria-hidden='true'>&times;</span>
            </button>
            <strong><i class='glyphicon glyphicon-ok-circle'></i> Sukses!</strong> Data Kavling berhasil diubah.
          </div>";
  } 
  // jika alert = 3
  // tampilkan pesan Sukses "Mahasiswa berhasil dihapus"
  elseif ($_GET['alert'] == 3) {
    echo "<div class='alert alert-success alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
              <span aria-hidden='true'>&times;</span>
            </button>
            <strong><i class='glyphicon glyphicon-ok-circle'></i> Sukses!</strong> Data kavling berhasil dihapus.
          </div>";
  }
  // jika alert = 4
  // tampilkan pesan Gagal "NIM1 sudah ada"
  elseif ($_GET['alert'] == 4) {
    echo "<div class='alert alert-danger alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
              <span aria-hidden='true'>&times;</span>
            </button>
            <strong><i class='glyphicon glyphicon-remove-circle'></i> Gagal!</strong> NIM1 $_GET[nim1] sudah ada.
          </div>";
  }
  // jika alert = 5
  // tampilkan pesan Upload Gagal "Pastikan file yang diupload sudah benar"
  elseif ($_GET['alert'] == 5) {
  echo "  <div class='alert alert-danger alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
              <span aria-hidden='true'>&times;</span>
            </button>
            <strong><i class='glyphicon glyphicon-remove-circle'></i> Upload Gagal!</strong> Pastikan file yang diupload sudah benar.
          </div>";
  }
  // jika alert = 6
  // tampilkan pesan Upload Gagal "Pastikan ukuran file foto tidak lebih dari 1MB"
  elseif ($_GET['alert'] == 6) {
  echo "  <div class='alert alert-danger alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
              <span aria-hidden='true'>&times;</span>
            </button>
            <strong><i class='glyphicon glyphicon-remove-circle'></i> Upload Gagal!</strong> Pastikan ukuran file foto tidak lebih dari 1MB.
          </div>";
  }
  // jika alert = 7
  // tampilkan pesan Upload Gagal "Pastikan file yang diupload bertipe *.JPG, *.JPEG, *.PNG"
  elseif ($_GET['alert'] == 7) {
  echo "  <div class='alert alert-danger alert-dismissible' role='alert'>
            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
              <span aria-hidden='true'>&times;</span>
            </button>
            <strong><i class='glyphicon glyphicon-remove-circle'></i> Upload Gagal!</strong> Pastikan file yang diupload bertipe *.JPG, *.JPEG, *.PNG.
          </div>";
  }
  ?>

      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">Data Kavling</h3>
        </div>
        <div class="panel-body">
          <table class="table table-striped table-hover" id="dataTables-example">
            <thead>
              <tr>
                <th>No</th>
                <th>Kode Kavling</th>
                <th>Luas Tanah</th>
                <th>Luas Bangunan</th>
                <th>Tipe</th>
                <th>Posisi</th>
                <th>Harga</th>
                <th>PPN</th>
                <th>Total</th>
                <th>UTJ</th>
                <th>DP</th>
                <th>Pelunasan</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>   

            <tbody>
            <?php
            try {
              $no = 1;

              // sql statement untuk menampilkan semua data dari tabel marketer
              $query = "SELECT * FROM kavling ORDER BY nim1 DESC";
              // membuat prepared statements
              $stmt = $pdo->prepare($query);

              // eksekusi query
              $stmt->execute();

              // tampilkan data
              while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {

                //  $tanggal        = $data['tanggal_lahir'];
                //  $tgl            = explode('-',$tanggal);
                //  $tanggal_lahir  = $tgl[2]."-".$tgl[1]."-".$tgl[0];
                $rupiah = "Rp " . number_format($data['harga'],2,',','.');
                $rupiahppn = "Rp " . number_format($data['ppn'],2,',','.');
                $rupiahtotal = "Rp " . number_format($data['total'],2,',','.');
                $rupiahpel = "Rp " . number_format($data['pelunasan'],2,',','.');
                $rupiahutj = "Rp " . number_format($data['utj'],2,',','.');
                $rupiahdp = "Rp " . number_format($data['dp'],2,',','.');
                echo "<tr>
                        <td width='50' class='center'>$no</td>";

                        

                echo "  <td width='60'>$data[nim1]</td>
                        
                        <td width='60'>$data[l_tanah] M<sup>2</sup></td>
                        <td width='60'>$data[l_bangunan] M<sup>2</sup></td>
                        <td width='60'>$data[tipe]</td>
                        <td width='60'>$data[posisi]</td>
                        <td width='100'>$rupiah</td>
                        <td width='100'>$rupiahppn</td>
                        <td width='100'>$rupiahtotal</td>
                        <td width='60'>$rupiahutj</td>
                        <td width='60'>$rupiahdp</td>
                        <td width='60'>$rupiahpel</td>
                        <td width='60'>$data[status]</td>
    
                        <td width='60'>
                          <div class=''>
                            <a href='#' data-toggle='tooltip' data-placement='top' title='Ubah' style='margin-right:5px' class='btn btn-success btn-sm open_modal' id='$data[nim1]' >
                              <i class='glyphicon glyphicon-edit'></i>
                            </a>";
                ?>
                            <a href="#" onclick="confirm_modal('proses-hapus.php?&nim1=<?php echo $data['nim1']; ?>');" data-nim="<?php echo $data['nim1']; ?>" data-toggle="tooltip" data-placement="top" title="Hapus" class="btn btn-danger btn-sm">
                              <i class="glyphicon glyphicon-trash"></i>
                            </a>
              <?php
                echo "
                          </div>
                        </td>
                      </tr>";
                $no++;
              }

              // tutup koneksi database
              $pdo = null;
            } catch (PDOException $e) {
              // tampilkan pesan kesalahan
              echo "ada kesalahan pada query : ".$e->getMessage();
            }
            ?>
            </tbody>           
          </table>
        </div>
      </div> <!-- /.panel -->
    </div> <!-- /.col -->
  </div> <!-- /.row -->
  
  <!-- Modal Popup untuk tambah--> 
  <div id="modal_tambah" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title" id="myModalLabel">
            <i class="glyphicon glyphicon-edit"></i> 
            Input Data Kavling
          </h4>
        </div>

        <div class="modal-body">
          <form action="proses-simpan.php" method="POST" name="modal_popup" enctype="multipart/form-data">
            
            <!-- <div>
              <label>Kode Kavling</label>
              <input type="text" placeholder="Kode Kavling" class="form-control" name="nim1" onkeyup="this.value = this.value.toUpperCase()" value="<?php echo "MR/ /" ?>" autocomplete="off" maxlength="10" required/>
            </div> -->

            <div class="form-group">
              <label>Kode Perumahan</label>
              <select class="form-control" id="kode_perumahan" name="kode_perumahan" autocomplate="off">
                <option>MR</option>
                <option>FR</option>
                <option>Gunung Sari</option>
              </select>
            </div>

            <div class="form-group">
              <label>Blok Rumah</label>
              <select class="form-control" id="blok" name="blok" autocomplate="off">
                <option>A</option>
                <option>B</option>
                <option>C</option>
              </select>
            </div>

            <div>
              <label>No Kavling</label>
              <input type="text" placeholder="Masukan No Kavling disini" class="form-control" name="no_kav" autocomplete="off" maxlength="13" onKeyPress="return goodchars(event,'0123456789',this)" required>
            </div>


            <div>
              <label>Luas Tanah</label>
              <input type="text" placeholder="Masukan Luas Tanah disini" class="form-control" name="l_tanah" autocomplete="off" maxlength="13" onKeyPress="return goodchars(event,'0123456789',this)" required/>
            </div>

            <div>
              <label>Luas Bangunan</label>
              <input type="text" placeholder="Masukan Luas Bangunan disini" class="form-control" name="l_bangunan" autocomplete="off" maxlength="13" onKeyPress="return goodchars(event,'0123456789',this)" required/>
            </div>

            <div>
            <label>Tipe</label>
              <select class="form-control" id="tipe" name="tipe" autocomplate="off">
                <option>Upnormal</option>
                <option>Normal</option>
              </select>
            </div>

            <div>
            <label>Posisi</label>
              <select class="form-control" id="posisi" name="posisi" autocomplate="off">
                <option>Lurus</option>
                <option>Zigzag</option>
                <option>Melingkar</option>
              </select>
            </div>

            <div>
              <label>Harga</label>
              <input type="text" placeholder="Masukan Harga disini" class="form-control" name="harga" autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)" required/>
            </div>

            <!-- <div class="form-group">
              <label>PPN</label>
              <input type="text" class="form-control" name="ppn" autocomplete="off" required/>
            </div> -->

            <!-- <div class="form-group">
              <label>Total</label>
              <input type="text" class="form-control" name="total" autocomplete="off" required/>
            </div> -->

            <div>
              <label>UTJ</label>
              <input type="text" placeholder="Masukan UTJ disini" class="form-control" name="utj" autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"/>
            </div>

            <div>
              <label>DP</label>
              <input type="text" placeholder="Masukan DP disini" class="form-control" name="dp" autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"/>
            </div>

            <div>
              <label>Pelunasan</label>
              <input type="text" placeholder="Masukan Pelunasan disini" class="form-control" name="pelunasan" autocomplete="off" onKeyPress="return goodchars(event,'0123456789',this)"/>
            </div>

            <!-- <div class="form-group">
              <label>Tempat Lahir</label>
              <input type="text" class="form-control" name="tempat_lahir" autocomplete="off" required/>
            </div>

            <div class="form-group">
              <label>Tanggal Lahir</label>
              <div class="input-group">
                <input type="text" class="form-control date-picker" data-date-format="dd-mm-yyyy" name="tanggal_lahir" autocomplete="off" required>
                <span class="input-group-addon">
                  <i class="glyphicon glyphicon-calendar"></i>
                </span>
              </div>
            </div> -->

            <!-- <div class="form-group">
              <label>Jenis Kelamin</label>
              <div class="radio">
                <label class="radio-inline">
                  <input type="radio" name="jenis_kelamin" value="Laki-laki"> Laki-laki
                </label>

                <label class="radio-inline">
                  <input type="radio" name="jenis_kelamin" value="Perempuan"> Perempuan
                </label>
              </div>
            </div> -->

            <!-- <div class="form-group">
              <label>Alamat</label>
              <textarea class="form-control" name="alamat" rows="3" required></textarea>
            </div>

            <div class="form-group">
              <label>Telepon</label>
              <input type="text" class="form-control" name="telepon" autocomplete="off" maxlength="13" onKeyPress="return goodchars(event,'0123456789',this)" required>
            </div> -->

            <!-- <div class="form-group">
              <label>Kota</label>
              <input type="text" class="form-control" name="kota1" autocomplete="off" required/>
            </div> -->

          <!-- <div class="form-group">
              <label>Email</label>
              <input type="text" class="form-control" name="email" autocomplete="off" required/>
            </div>

            <div class="form-group">
              <label>KTP</label>
              <input type="file" name="foto" required>
              <p class="help-block">
                <small>Catatan :</small> <br>
                <small>- Pastikan file yang diupload bertipe *.JPG atau *.PNG</small> <br>
                <small>- Ukuran file foto max 1 Mb</small>
              </p>
            </div> -->

            <div class="modal-footer">
              <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
              <button type="reset" class="btn btn-danger btn-reset" data-dismiss="modal" aria-hidden="true">Batal</button>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Modal Popup untuk ubah--> 
  <div id="modal_ubah" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

  </div>

  <!-- Modal Popup untuk hapus -->
  <div class="modal fade" id="modal_hapus">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title"><i style="margin-right:7px" class="glyphicon glyphicon-trash"></i> Anda yakin ingin menghapus data kavling ?</h4>
        </div>
        <div class="modal-footer">
          <a href="#" type="button" class="btn btn-danger btn-submit" id="link_hapus">Ya, Hapus</a>
          <button type="button" class="btn btn-default btn-reset" data-dismiss="modal">Batal</button>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->