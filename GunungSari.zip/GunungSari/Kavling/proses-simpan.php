<?php
// Panggil koneksi database
require_once "config/database.php";

if (isset($_POST['simpan'])) {
	// ambil data hasil submit dari form
	$nim                = trim($_POST['nim']);
	$tanah              = trim($_POST['l_tanah']);
	$bangunan           = trim($_POST['l_bangunan']);
	$tipe             	= trim($_POST['tipe']);
	$posisi             = trim($_POST['posisi']);
	$harga             	= trim($_POST['harga']);
	$pajak				= "10%";
	$persen				= "100%";
	$ppn            	= trim($pajak/$persen*$harga);
	//$ppn            	= trim($_POST['ppn']);
	$total            	= trim($harga+$ppn);
	$pelunasan          = trim($_POST['pelunasan']);
	$utj               	= trim($_POST['utj']);
	$dp               	= trim($_POST['dp']);
	$status             = trim($_POST['status']);

	
	// $nama_file          = $_FILES['foto']['name'];
	// $ukuran_file        = $_FILES['foto']['size'];
	// $tipe_file          = $_FILES['foto']['type'];
	// $tmp_file           = $_FILES['foto']['tmp_name'];
	
	// tentukan extension yang diperbolehkan
	//$allowed_extensions = array('jpg','jpeg','png');
	
	// Set path folder tempat menyimpan gambarnya
	//$path_file          = "foto/".$nama_file;
	
	// check extension
	//$file               = explode(".", $nama_file);
	//$extension          = array_pop($file);

	try {
		// sql statement untuk seleksi nim dari tabel marketer
		$query = "SELECT nim FROM kavling WHERE nim=:nim";
		// membuat prepared statements
		$stmt = $pdo->prepare($query);

		// mengikat parameter
		$stmt->bindParam(':nim', $nim);

		// eksekusi query
		$stmt->execute();

		$count = $stmt->rowCount();
		// jika nim sudah ada
		if($count > 0) {
			// tampilkan pesan nim sudah ada
			header("location: index.php?nim=$nim&alert=4");
		}
		// jika nim belum ada
		else {
			// Cek apakah tipe file yang diupload sesuai dengan allowed_extensions
			// sql statement untuk menyimpan data ke tabel marketer
			$query = "INSERT INTO kavling(nim,l_tanah,l_bangunan,tipe,posisi,harga,ppn,total,pelunasan,utj,dp,status)	
			VALUES(:nim,:l_tanah,:l_bangunan,:tipe,:posisi,:harga,:ppn,:total,:pelunasan,:utj,:dp,:status)";
  // membuat prepared statements
  $stmt = $pdo->prepare($query);

  // mengikat parameter
  $stmt->bindParam(':nim', $nim);
  $stmt->bindParam(':l_tanah', $tanah);
  $stmt->bindParam(':l_bangunan', $bangunan);
  $stmt->bindParam(':tipe', $tipe);
  $stmt->bindParam(':posisi', $posisi);
  $stmt->bindParam(':harga', $harga);
  $stmt->bindParam(':ppn', $ppn);
  $stmt->bindParam(':total', $total);
  $stmt->bindParam(':pelunasan', $pelunasan);
  $stmt->bindParam(':utj', $utj);
  $stmt->bindParam(':dp', $dp);
  $stmt->bindParam(':status', $status);
  
  // eksekusi query
  $stmt->execute();

  // jika berhasil tampilkan pesan berhasil simpan data
  header('location: index.php?alert=1');
		}

		// tutup koneksi database
        $pdo = null;
	} catch (PDOException $e) {
		// tampilkan pesan kesalahan
        echo "ada kesalahan : ".$e->getMessage();
	}
}						
?>