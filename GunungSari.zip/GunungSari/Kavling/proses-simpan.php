<?php
// Panggil koneksi database
require_once "config/database.php";

if (isset($_POST['simpan'])) {
	// ambil data hasil submit dari form
	$kode_perumahan     = trim($_POST['kode_perumahan']);
	$blok               = trim($_POST['blok']);
	$no_kav             = trim($_POST['no_kav']);
	$nim1               = $kode_perumahan.$blok.$no_kav;
	$tanah              = trim($_POST['l_tanah']);
	$bangunan           = trim($_POST['l_bangunan']);
	$tipe             	= trim($_POST['tipe']);
	$posisi             = trim($_POST['posisi']);
	$harga             	= trim($_POST['harga']);
	$pajak				= "10%";
	$persen				= "100%";
	$ppn            	= trim($pajak/$persen*$harga);
	//$ppn            	= trim($_POST['ppn']);
	$total            	= trim($harga+$ppn);
	$pelunasan          = trim($_POST['pelunasan']);
	$utj               	= trim($_POST['utj']);
	$dp               	= trim($_POST['dp']);
	$status             = trim($_POST['status']);

	
	// $nama_file          = $_FILES['foto']['name'];
	// $ukuran_file        = $_FILES['foto']['size'];
	// $tipe_file          = $_FILES['foto']['type'];
	// $tmp_file           = $_FILES['foto']['tmp_name'];
	
	// tentukan extension yang diperbolehkan
	//$allowed_extensions = array('jpg','jpeg','png');
	
	// Set path folder tempat menyimpan gambarnya
	//$path_file          = "foto/".$nama_file;
	
	// check extension
	//$file               = explode(".", $nama_file);
	//$extension          = array_pop($file);

	try {
		// sql statement untuk seleksi nim1 dari tabel marketer
		$query = "SELECT nim1 FROM kavling WHERE nim1=:nim1";
		// membuat prepared statements
		$stmt = $pdo->prepare($query);

		// mengikat parameter
		$stmt->bindParam(':nim1', $nim1);

		// eksekusi query
		$stmt->execute();

		$count = $stmt->rowCount();
		// jika nim1 sudah ada
		if($count > 0) {
			// tampilkan pesan nim1 sudah ada
			header("location: index.php?nim1=$nim1&alert=4");
		}
		// jika nim1 belum ada
		else {
			// Cek apakah tipe file yang diupload sesuai dengan allowed_extensions
			// sql statement untuk menyimpan data ke tabel marketer
			$query = "INSERT INTO kavling(nim1,kode_perumahan,blok,no_kav,l_tanah,l_bangunan,tipe,posisi,harga,ppn,total,pelunasan,utj,dp,status)	
			VALUES(:nim1,:kode_perumahan,:blok,:no_kav,:l_tanah,:l_bangunan,:tipe,:posisi,:harga,:ppn,:total,:pelunasan,:utj,:dp,:status)";
  // membuat prepared statements
  $stmt = $pdo->prepare($query);

  // mengikat parameter
  $stmt->bindParam(':nim1',$nim1);
  $stmt->bindParam(':kode_perumahan', $kode_perumahan);
  $stmt->bindParam(':blok', $blok);
  $stmt->bindParam(':no_kav', $no_kav);
  $stmt->bindParam(':l_tanah', $tanah);
  $stmt->bindParam(':l_bangunan', $bangunan);
  $stmt->bindParam(':tipe', $tipe);
  $stmt->bindParam(':posisi', $posisi);
  $stmt->bindParam(':harga', $harga);
  $stmt->bindParam(':ppn', $ppn);
  $stmt->bindParam(':total', $total);
  $stmt->bindParam(':pelunasan', $pelunasan);
  $stmt->bindParam(':utj', $utj);
  $stmt->bindParam(':dp', $dp);
  $stmt->bindParam(':status', $status);
  
  // eksekusi query
  $stmt->execute();

  // jika berhasil tampilkan pesan berhasil simpan data
  header('location: index.php?alert=1');
		}

		// tutup koneksi database
        $pdo = null;
	} catch (PDOException $e) {
		// tampilkan pesan kesalahan
        echo "ada kesalahan : ".$e->getMessage();
	}
}						
?>