<?php

//menangkap data yang dipostkan pembeli
$angkaa= $_POST['harga'] ;
$angkab= $_POST['angkab'] ;
$angka1= str_replace(".", "", $angkaa);
$angkaminus = str_replace("", "", -$angka1);
$angka2= str_replace(".", "", $angkab);
echo "$angkaminus <br/> $angka2";
	
?>
