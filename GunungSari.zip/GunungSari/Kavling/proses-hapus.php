<?php
// Panggil koneksi database
require_once "config/database.php";

$nim1 = $_GET['nim1'];

if (isset($nim1)) {
	try {
		// sql statement untuk menghapus data pada tabel marketer
        $query = "DELETE FROM kavling WHERE nim1=:nim1";
        // membuat prepared statements
		$stmt = $pdo->prepare($query);

		//mengikat parameter 
		$stmt->bindParam(':nim1', $nim1);

		// eksekusi query
		$stmt->execute();

        // jika berhasil tampilkan pesan berhasil delete data
		header('location: index.php?alert=3');

		// tutup koneksi database
        $pdo = null;
	} catch (PDOException $e) {
		// tampilkan pesan kesalahan
        echo "ada kesalahan : ".$e->getMessage();
	}
}					
?>