<?php
// Panggil koneksi database
require_once "config/database.php";

if (isset($_POST['simpan'])) {
	if (isset($_POST['nim1'])) {
		// ambil data hasil submit dari form
		$nim1                = trim($_POST['nim1']);
		$tanah              = trim($_POST['l_tanah']);
		$bangunan           = trim($_POST['l_bangunan']);
		$tipe             	= trim($_POST['tipe']);
		$posisi             = trim($_POST['posisi']);
		$harga             	= trim($_POST['harga']);
		$ppn            	= trim($_POST['ppn']);
		$total            	= trim($_POST['total']);
		$pelunasan          = trim($_POST['pelunasan']);
		$utj               	= trim($_POST['utj']);
		$dp               	= trim($_POST['dp']);
		$status             = trim($_POST['status']);

		try {
			$query = "UPDATE kavling SET 		l_tanah		= :l_tanah,
												l_bangunan	= :l_bangunan,															  
												tipe 		= :tipe,
												posisi		= :posisi,
												harga		= :harga,
												ppn			= :ppn,
												total		= :total,
												pelunasan	= :pelunasan,
												utj			= :utj,
												dp			= :dp,
												status		= :status,						  
										WHERE nim1 			= :nim1";
		        // membuat prepared statements
		        $stmt = $pdo->prepare($query);

		        // mengikat parameter
				$stmt->bindParam(':nim1', $nim1);
				$stmt->bindParam(':l_tanah', $tanah);
				$stmt->bindParam(':l_bangunan', $bangunan);
				$stmt->bindParam(':tipe', $tipe);
				$stmt->bindParam(':posisi', $posisi);
				$stmt->bindParam(':harga', $harga);
				$stmt->bindParam(':ppn', $ppn);
				$stmt->bindParam(':total', $total);
				$stmt->bindParam(':pelunasan', $pelunasan);
				$stmt->bindParam(':utj', $utj);
				$stmt->bindParam(':dp', $dp);
				$stmt->bindParam(':status', $status);

			// eksekusi query
	        $stmt->execute();

	        // jika berhasil tampilkan pesan berhasil update data
			header('location: index.php?alert=2');

			// tutup koneksi database
	        $pdo = null;
		} catch (PDOException $e) {
			// tampilkan pesan kesalahan
	        echo "ada kesalahan : ".$e->getMessage();
		}
	}
}				
?>