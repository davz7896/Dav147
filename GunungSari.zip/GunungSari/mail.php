<html>

<head>

       <title>Title here!</title>

</head>

<body><form id="frmkirim" name="frmkirim" method="post"

action="kirimemail.php">

<table width="624" align="center" class="tabel">
<tr>

<th colspan="3" class="header">FORM KIRIM EMAIL</th>

</tr>
<tr>

<td width="131">Nama Penerima</td>

<td width="10">:</td>

<td width="472"><input type="text" name="tujuan" id="tujuan" /></td>

</tr>
<tr>

<td>Email Tujuan</td>

<td>:</td>

<td><input name="E_tujuan" type="text" id="E_tujuan" size="40"

valu=""/></td>

</tr>
<tr>

<td>Nama Pengirim</td>

<td>:</td>

<td><input name="n_pengirim" type="text" id="n_pengirim" value=""/></td>

</tr>
<tr>

<td>Email Pengirim</td>

<td>:</td>

<td><input name="E_pengirim" type="text" id="judul" size="42"

value=""/></td>

</tr>
<tr>

<td>Judul Email</td>

<td>:</td>

<td><input name="judul" type"text" id="judul" size="50" /></td>

</tr>
<tr>
<td><input type="submit" name="kirim" id="kirim" value="kirim"

/><input type="reset" name="batal" id="batal" value="batal"/></td></tr>
</table>
</form>
</body>
</html>