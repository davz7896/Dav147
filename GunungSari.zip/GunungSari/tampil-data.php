 <!-- Modal Popup untuk tambah--> 
  <div id="modal_tambah" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title" id="myModalLabel">
            <i class="glyphicon glyphicon-edit"></i> 
            Input data Marketer
          </h4>
        </div>

        <div class="modal-body">
          <form action="proses-simpan.php" method="POST" name="modal_popup" enctype="multipart/form-data">
            
            <div class="form-group">
              <label>Kode</label>
              <input type="text" class="form-control" name="nim" autocomplete="off" maxlength="10" required/>
            </div>

            <div class="form-group">
              <label>Nama Marketer</label>
              <input type="text" class="form-control" name="nama" autocomplete="off" required/>
            </div>

            <div class="form-group">
              <label>Tempat Lahir</label>
              <input type="text" class="form-control" name="tempat_lahir" autocomplete="off" required/>
            </div>

            <div class="form-group">
              <label>Tanggal Lahir</label>
              <div class="input-group">
                <input type="text" class="form-control date-picker" data-date-format="dd-mm-yyyy" name="tanggal_lahir" autocomplete="off" required>
                <span class="input-group-addon">
                  <i class="glyphicon glyphicon-calendar"></i>
                </span>
              </div>
            </div>

            <div class="form-group">
              <label>Jenis Kelamin</label>
              <div class="radio">
                <label class="radio-inline">
                  <input type="radio" name="jenis_kelamin" value="Laki-laki"> Laki-laki
                </label>

                <label class="radio-inline">
                  <input type="radio" name="jenis_kelamin" value="Perempuan"> Perempuan
                </label>
              </div>
            </div>

            <div class="form-group">
              <label>Telepon</label>
              <input type="text" class="form-control" name="telepon" autocomplete="off" maxlength="13" onKeyPress="return goodchars(event,'0123456789',this)" required>
            </div>

            <div class="form-group">
              <label>Alamat</label>
              <textarea class="form-control" name="alamat" rows="3" required></textarea>
            </div>

            <div class="form-group">
              <label>Kota</label>
              <input type="text" class="form-control" name="kota1" autocomplete="off" required/>
            </div>

          <div class="form-group">
              <label>Email</label>
              <input type="text" class="form-control" name="email" autocomplete="off" required/>
            </div>

            <div class="form-group">
              <label>Foto</label>
              <input type="file" name="foto" required>
              <p class="help-block">
                <small>Catatan :</small> <br>
                <small>- Pastikan file yang diupload bertipe *.JPG atau *.PNG</small> <br>
                <small>- Ukuran file foto max 1 Mb</small>
              </p>
            </div>

            <div class="modal-footer">
              <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
              <button type="reset" class="btn btn-danger btn-reset" data-dismiss="modal" aria-hidden="true">Batal</button>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>