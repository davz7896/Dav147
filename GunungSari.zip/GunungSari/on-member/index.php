<?php
session_start();
/**
 * Jika Tidak login atau sudah login tapi bukan sebagai admin
 * maka akan dibawa kembali kehalaman login atau menuju halaman yang seharusnya.
 */
if ( !isset($_SESSION['user_login']) || 
    ( isset($_SESSION['user_login']) && $_SESSION['user_login'] != 'member' ) ) {

	header('location:./../login.php');
	exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

<style type="text/css">
   .left    { text-align: left;}
   .right   { text-align: right;}
   .center  { text-align: center;}
   .justify { text-align: justify;}
</style>


<link rel="icon" type="image/jpg" href="img/logo/logo.jpg">
  <title>Tridjaya Kartika Groub</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style2.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/format-rupiah.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
	  
      <a class="navbar-brand" href="index.php">TridjayaKartikaGroub</a> 
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
   		<li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Master Data
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="./../Rekening/index.php" size="3">Data Agen Marketing</a></li>
          <li><a href="data_customer.php">Data Customer</a></li>
		  
		</ul>
		<li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Transaksi
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Penjualan</a></li>
          <li><a href="#">Pindah Kavling</a></li>
          <li><a href="#">Ganti Nama</a></li>
          <li><a href="#">Perbankan</a></li>
          <li><a href="#">Penerimaan Pembayaran(Buat Kwintasi)</a></li>
		</ul>
		<li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Laporan
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="laporan_pembelian.php">Laporan Pembelian</a></li>
          <li><a href="laporan_penjualan.php">Laporan Penjualan</a></li>
          <li><a href="laporan_stok.php">Laporan Stok</a></li>
		</ul>
		</ul>
      
    </div>
  </div>
</nav>
<a href="./../logout.php">Logout</a>
<br><br>
<h2>
   <p class="center">HALLO MEMBER</p> </h2>

</body>
</html>