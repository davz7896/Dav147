<?php
if (isset($_POST['nickname']) && $_POST['nickname']) {
    // memasukan file koneksi ke database
    require_once 'config.php';
    // menyimpan variable yang dikirim Form
    $foto = $_POST['foto'];
    $nama = $_POST['nickname'];
    $id_user = $_POST['id_user'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $agen = $_POST['agen_marketing'];
    $email = $_POST['email'];
    $telepon = $_POST['telepon'];
    //$emailpengirim = "putnow1809@gmail.com";
    $nama_file          = $_FILES['foto']['name'];
	$ukuran_file        = $_FILES['foto']['size'];
	$tipe_file          = $_FILES['foto']['type'];
    $tmp_file           = $_FILES['foto']['tmp_name'];
    
    
	// tentukan extension yang diperbolehkan
	$allowed_extensions = array('jpg','jpeg','png');
	
	// Set path folder tempat menyimpan gambarnya
	$path_file          = "foto/".$nama_file;
	
	// check extension
	$file               = explode(".", $nama_file);
    $extension          = array_pop($file);
    
    // cek nilai variable
    if (empty($nama)) {
        header('location: ./register.php?error=' .base64_encode('Nama tidak boleh kosong'));
    }
    if (empty($username)) {
        header('location: ./register.php?error=' .base64_encode('Username tidak boleh kosong'));   
    }
    if (empty($password)) {
        header('location: ./register.php?error=' .base64_encode('Password tidak boleh kosong'));   
    }
    // validasi apakah password dengan repassword sama
    if ($password != $repassword) { // jika tidak sama
        header('location: ./register.php?error=' .base64_encode('Password tidak sama'));   
    }
    // encryption dengan md5
    $password = md5($password);
    $level = 'member'; // default, 
    // SQL Insert
    $sql = "INSERT INTO users (id_user,foto, nama, username, password, agen_marketing, email, telp, level_user) VALUES ('$id_user','$foto', '$nama', '$username', '$password', '$agen', '$email', '$telepon', '$level')";
    $insert = $dbconnect->query($sql);
    // jika gagal
    if (! $insert) {
        echo "<script>alert('".$dbconnect->error."'); window.location.href = './register.php';</script>";
    } else {
        echo "<script>alert('Insert Data Berhasil'); window.location.href = './login.php';</script>";
    }

 }


?>
