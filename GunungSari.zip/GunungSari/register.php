<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Halaman Registrasi</title>

    <link href="assets2/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets2/css/style.1.css" rel="stylesheet">
  </head>
  <body>
    <div class="col-md-4 col-md-offset-4 form-login">
    
    <?php
    /* handle error */
    if (isset($_GET['error'])) : ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <strong>Warning!</strong> <?=base64_decode($_GET['error']);?>
        </div>
    <?php endif;?>

        <div class="outter-form-login">
            <div class="logo-login">
                <em class="glyphicon glyphicon-user"></em>
            </div>
            <form action="send_register.php"  method="post">
            <h3 class="text-center title-login">Registrasi</h3>

                <div class="form-group">
                <label>No Identitas</label>
                    <input type="text" class="form-control" name="id_user" placeholder="Masukan Nomor KTP/ SIM disini">
                </div>


                <div class="form-group">
                <label>Nama </label>
                    <input type="text" class="form-control" name="nama" placeholder="Masukan Nama Lengkap disini">
                </div>

                
                <div class="form-group">
                <label>Username</label>
                    <input type="text" class="form-control" name="username" placeholder="Masukan Username disini">
                </div>

                <div class="form-group">
                <label>Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Masukan Password disini ">
                </div>

                <div class="form-group">
                <label>Re-Paswword</label>
                    <input type="password" class="form-control" name="repassword" placeholder="Masukan Re-Password disini ">
                </div>

                <div class="form-group">
                <label>Agen Marketing</label>
                  <select class="form-control" id="agen_marketing" name="agen_marketing">
                     <option>PT. Tridjaya Kartika</option>
                      <option>PT. MBB</option>
                      <option>PT. TPI</option>
              </select>
                </div>

                <div class="form-group">
                <label>Email</label>
                    <input type="email" class="form-control" name="email" placeholder="Masukan Email disini">
                </div>

                <div class="form-group">
                <label>Telepon</label>
                    <input type="text" class="form-control" name="telepon" placeholder="Masukan Telepon disini">
                </div>
                
                <div class="form-group">
                  <label>Foto</label>
                  <input type="file" name="foto" required>
                  <p class="help-block">
                    <small>Catatan :</small> <br>
                    <small>- Pastikan file yang diupload bertipe *.JPG atau *.PNG</small> <br>
                    <small>- Ukuran file foto max 1 Mb</small>
                  </p>
                </div>

                <input type="submit" class="btn btn-block btn-custom-green" value="REGISTER" name="register"/>
                
                <div class="text-center forget">
                    <p>Back To <a href="./login.php">Login</a></p>
                </div>
            </form>
        </div>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
  </body>
</html>
