-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 09, 2019 at 11:47 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `marketer`
--

CREATE TABLE `marketer` (
  `nim` varchar(10) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` text,
  `level_user` varchar(150) DEFAULT NULL,
  `tempat_lahir` varchar(30) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') NOT NULL,
  `email` varchar(20) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `kota1` varchar(50) NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `marketer`
--

INSERT INTO `marketer` (`nim`, `nama`, `username`, `password`, `level_user`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `email`, `alamat`, `kota1`, `telepon`, `foto`) VALUES
('1', '1', NULL, NULL, NULL, '1', '0000-00-00', 'Perempuan', '1', '1', '1', '1', 'pria.png'),
('2', '2', NULL, NULL, NULL, '2', '0000-00-00', 'Perempuan', '2', '2', '2', '2', 'img-2.png'),
('3', '3', '3', 'eccbc87e4b5ce2fe28308fd9f2a7baf3', 'member', '3', '0000-00-00', 'Perempuan', '3', '3', '3', '3', 'wanita.png'),
('4', '4', '4', 'd41d8cd98f00b204e9800998ecf8427e', 'member', '4', '0000-00-00', 'Perempuan', '4', '34', '4', '4', 'wanita.png'),
('MK001', 'Naning', NULL, NULL, NULL, 'Sidoarjo', '1993-12-20', 'Perempuan', 'naning@gmail.com', 'Wonokromo', 'Surabaya', '0851726371623', 'wanita.png');

-- --------------------------------------------------------

--
-- Table structure for table `rekening`
--

CREATE TABLE `rekening` (
  `nama` varchar(30) NOT NULL,
  `norekening` int(15) NOT NULL,
  `alamat_bank` varchar(15) NOT NULL,
  `namaPT` varchar(50) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rekening`
--

INSERT INTO `rekening` (`nama`, `norekening`, `alamat_bank`, `namaPT`, `catatan`) VALUES
('David', 193013, 'Mandiri Indones', '', 'Coba Coba'),
('Atmaja', 859004572, 'BRI', '', 'COBA AJA'),
('Nadya', 88776655, 'BNI', '', 'cOBA aJA'),
('Yuli', 12526252, 'Mandiri', '', 'Coba Coba'),
('Yoni', 152462412, 'Tridjaya Kartik', 'BCA', 'Coba'),
('Faudia', 24315, 'PT MBB', 'BCA', 'COBA');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `level_user` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `username`, `password`, `level_user`) VALUES
(2, 'ONPHPID', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(2, 'ONPHPID', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
(0, 'David', 'davidagung80', 'cc03e747a6afbbcbf8be7668acfebee5', 'member'),
(0, 'asdasd', 'asdas', 'f7e0ef389ac6133c88aedbd66b44a4e1', 'member');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `marketer`
--
ALTER TABLE `marketer`
  ADD PRIMARY KEY (`nim`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
