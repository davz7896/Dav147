<?php
$con = mysqli_connect("localhost", "root","", "database");
?>

<?php
session_start();
/**
 * Jika Tidak login atau sudah login tapi bukan sebagai admin
 * maka akan dibawa kembali kehalaman login atau menuju halaman yang seharusnya.
 */
if ( !isset($_SESSION['user_login']) || 
    ( isset($_SESSION['user_login']) && $_SESSION['user_login'] != 'admin' ) ) {

	header('location:../index.php');
	exit();
}
?>
 <div class="row">
    <div class="col-md-12">
      <div class="page-header" >
        <h4>
          <i class="glyphicon glyphicon-user"></i> <b><?=$_SESSION['nama'];?></b>
          
          <a class="btn btn-success pull-right" href="#" data-target="#modal_tambah" data-toggle="modal">
            <i class="glyphicon glyphicon-plus"></i> Tambah
          </a>
        </h4>
      </div>

<div class="floating-box">
<div class="form-group">
    <label>Pilih Kode Customer</label>
</div>
 <select name="nim" id="nim" class="form-control" onchange='changeValue(this.value)' style="width:250px" required>
  <option value="">-Pilih-</option>
  
  
  <!-- php select berdasarkan dropwdown -->
  <?php 
    $query=mysqli_query($con, "select * from marketer order by nim asc"); 
    $result = mysqli_query($con, "select * from marketer");  
    $jsArray = "var prdName = new Array();\n";
        while ($row = mysqli_fetch_array($result)) {  
          echo '<option name="nim"  value="' . $row['nim'] . '">' . $row['nim'] . '</option>';  
    $jsArray .= "prdName['" . $row['nim'] . "'] = {nama:'" . addslashes($row['nama']) . "',username:'".addslashes($row['username'])."',email:'".addslashes($row['email'])."'};\n";
    }
  ?>


</select>

</br>
<div class="form-group" action="aksi_data.php">
    <label>Nama Customer</label>
    <input class="form-control"  name="nama" id="nama" style="width:250px" readonly />      
</div>
<div class="form-group">
    <label>Kode TUK</label>
    <input class="form-control" name="username" id="username" style="width:250px" readonly/>      
</div>
<div class="form-group">
    <label>Nama TUK</label>
    <input class="form-control"  name="email" id="email" style="width:250px" readonly />      
</div>

<script type="text/javascript"> 
<?php echo $jsArray; ?>
function changeValue(id){
    document.getElementById('nama').value = prdName[id].nama;
    document.getElementById('username').value = prdName[id].username;
    document.getElementById('email').value = prdName[id].email;
};
</script>
</div>


<div class="floating-box">
<div class="form-group">
    <label>Pilih no Kavling</label>
</div>
 <select name="nim" id="nim" class="form-control" onchange='changeValue(this.value)' style="width:250px" required>
  <option value="">-Pilih-</option>
  
  
  <!-- php select berdasarkan dropwdown -->
  <?php 
    $query=mysqli_query($con, "select * from marketer order by nim asc"); 
    $result = mysqli_query($con, "select * from marketer");  
    $jsArray = "var prdName = new Array();\n";
        while ($row = mysqli_fetch_array($result)) {  
          echo '<option name="nim"  value="' . $row['nim'] . '">' . $row['nim'] . '</option>';  
    $jsArray .= "prdName['" . $row['nim'] . "'] = {nama:'" . addslashes($row['nama']) . "',username:'".addslashes($row['username'])."',email:'".addslashes($row['email'])."'};\n";
    }
  ?>


</select>

</br>
<div class="form-group" action="aksi_data.php">
    <label>Nama Customer</label>
    <input class="form-control"  name="nama" id="nama" style="width:250px" readonly />      
</div>
<div class="form-group">
    <label>Kode TUK</label>
    <input class="form-control" name="username" id="username" style="width:250px" readonly/>      
</div>
<div class="form-group">
    <label>Nama TUK</label>
    <input class="form-control"  name="email" id="email" style="width:250px" readonly />      
</div>

<script type="text/javascript"> 
<?php echo $jsArray; ?>
function changeValue(id){
    document.getElementById('nama').value = prdName[id].nama;
    document.getElementById('username').value = prdName[id].username;
    document.getElementById('email').value = prdName[id].email;
};
</script>
