<?php 
 $query=mysqli_query($con, "select * from marketer order by nim asc"); 
 $result = mysqli_query($con, "select * from marketer");  
 $jsArray = "var prdName = new Array();\n";
 while ($row = mysqli_fetch_array($result)) {  
 echo '<option name="nim"  value="' . $row['nim'] . '">' . $row['nim'] . '</option>';  
 $jsArray .= "prdName['" . $row['nim'] . "'] = {nama:'" . addslashes($row['nama']) . "',username:'".addslashes($row['username'])."',email:'".addslashes($row['email'])."'};\n";
  }
  ?>