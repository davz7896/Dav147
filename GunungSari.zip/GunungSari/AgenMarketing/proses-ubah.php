<?php
// Panggil koneksi database
require_once "config/database.php";

if (isset($_POST['simpan'])) {
	if (isset($_POST['kode'])) {
		// ambil data hasil submit dari form
		$nim                = trim($_POST['kode']);
		$nama              = trim($_POST['nama']);
		$bank              = trim($_POST['bank']);
		$norek           = trim($_POST['no_rek']);
		

		try {
			$query = "UPDATE agen_marketing SET nama = :nama,
												bank		= :bank,
												no_rek	= :no_rek															  
																		  
										WHERE kode 			= :kode";
		        // membuat prepared statements
		        $stmt = $pdo->prepare($query);

		        // mengikat parameter
				$stmt->bindParam(':kode', $nim);
				$stmt->bindParam(':nama', $nama);
				$stmt->bindParam(':bank', $bank);
				$stmt->bindParam(':no_rek', $norek);
				

			// eksekusi query
	        $stmt->execute();

	        // jika berhasil tampilkan pesan berhasil update data
			header('location: index.php?alert=2');

			// tutup koneksi database
	        $pdo = null;
		} catch (PDOException $e) {
			// tampilkan pesan kesalahan
	        echo "ada kesalahan : ".$e->getMessage();
		}
	}
}				
?>