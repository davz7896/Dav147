<?php
// Panggil koneksi database
require_once "config/database.php";

if (isset($_POST['simpan'])) {
	// ambil data hasil submit dari form
	$nim               = trim($_POST['kode']);
	$nama              = trim($_POST['nama']);
	$bank              = trim($_POST['bank']);
	$norek             = trim($_POST['no_rek']);
	
	// $nama_file          = $_FILES['foto']['name'];
	// $ukuran_file        = $_FILES['foto']['size'];
	// $tipe_file          = $_FILES['foto']['type'];
	// $tmp_file           = $_FILES['foto']['tmp_name'];
	
	// tentukan extension yang diperbolehkan
	//$allowed_extensions = array('jpg','jpeg','png');
	
	// Set path folder tempat menyimpan gambarnya
	//$path_file          = "foto/".$nama_file;
	
	// check extension
	//$file               = explode(".", $nama_file);
	//$extension          = array_pop($file);

	try {
		// sql statement untuk seleksi nim dari tabel marketer
		$query = "SELECT kode FROM agen_marketing WHERE kode=:kode";
		// membuat prepared statements
		$stmt = $pdo->prepare($query);

		// mengikat parameter
		$stmt->bindParam(':kode', $nim);

		// eksekusi query
		$stmt->execute();

		$count = $stmt->rowCount();
		// jika nim sudah ada
		if($count > 0) {
			// tampilkan pesan nim sudah ada
			header("location: index.php?kode=$nim&alert=4");
		}
		// jika nim belum ada
		else {
			// Cek apakah tipe file yang diupload sesuai dengan allowed_extensions
			// sql statement untuk menyimpan data ke tabel marketer
			$query = "INSERT INTO agen_marketing(kode,nama,bank,no_rek)	
			VALUES(:kode,:nama,:bank,:no_rek)";
  // membuat prepared statements
  $stmt = $pdo->prepare($query);

  // mengikat parameter
  $stmt->bindParam(':kode', $nim);
  $stmt->bindParam(':nama', $nama);
  $stmt->bindParam(':bank', $bank);
  $stmt->bindParam(':no_rek', $norek);
  
  
  // eksekusi query
  $stmt->execute();

  // jika berhasil tampilkan pesan berhasil simpan data
  header('location: index.php?alert=1');
		}

		// tutup koneksi database
        $pdo = null;
	} catch (PDOException $e) {
		// tampilkan pesan kesalahan
        echo "ada kesalahan : ".$e->getMessage();
	}
}						
?>