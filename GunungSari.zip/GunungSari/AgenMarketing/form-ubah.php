 <?php
  // Panggil koneksi database
  require_once "config/database.php";

  if (isset($_GET['kode'])) {
    try {
      // sql statement untuk menampilkan data dari tabel marketer berdasarkan nim
      $query = "SELECT * FROM agen_marketing WHERE kode=:kode";
      // membuat prepared statements
      $stmt = $pdo->prepare($query);

      //mengikat parameter 
      $stmt->bindParam(':kode', $_GET['kode']);

      // eksekusi query
      $stmt->execute();

      // mengambil data mahasiswa
      $data = $stmt->fetch(PDO::FETCH_ASSOC);

      // nilai untuk mengisi form
      $nim           = $data['kode'];
      $nama           = $data['nama'];
      $bank         = $data['bank'];
      $norek      = $data['no_rek'];   

      // tutup koneksi database
      $pdo = null;
    } catch (PDOException $e) {
      // tampilkan pesan kesalahan
      echo "ada kesalahan pada query : ".$e->getMessage();
    }
  }
  ?>
  
  <script type="text/javascript">
    $(function () {
      //datepicker plugin
      $('.date-picker').datepicker({
        autoclose: true,
        todayHighlight: true
      });
    })
  </script>

  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title" id="myModalLabel">
          <i class="glyphicon glyphicon-edit"></i> 
          Ubah Data Agen
        </h4>
      </div>

      <div class="modal-body">
        <form action="proses-ubah.php" method="POST" name="modal_popup" enctype="multipart/form-data" >
          <div class="form-group">
            <label>Kode</label>
            <input type="text" class="form-control" name="kode" value="<?php echo $nim; ?>" readonly required/>
          </div>

          <div class="form-group">
              <label>Nama</label>
              <select class="form-control" id="nama" name="nama">
                <option>PT. Tridjaya Kartika</option>
                <option>PT. MBB</option>
                <option>PT. TPI</option>
              </select>
            </div>

            <div class="form-group">
              <label>Bank</label>
              <select class="form-control" id="bank" name="bank">
                <option>BCA</option>
                <option>BNI</option>
                <option>BRI</option>
                <option>Mandiri</option>
              </select>
            </div>

          <div class="form-group">
            <label>No Rekening</label>
            <input type="text" class="form-control" name="no_rek" autocomplete="off" value="<?php echo $norek; ?>" required/>
          </div>

          

          <!-- <div class="form-group">
            <label>Telepon</label>
            <input type="text" class="form-control" name="telepon" autocomplete="off" maxlength="13" onKeyPress="return goodchars(event,'0123456789',this)" value="<?php echo $telepon; ?>" required>
          </div> -->

        
           <!-- <div class="form-group">
            <label>Kota</label>
            <input type="text" class="form-control" name="kota1" autocomplete="off" value="<?php echo $kota1; ?>" required/>
          </div> -->
          
          <!-- <div class="form-group">
            <label>Email</label>
            <input type="text" class="form-control" name="email" autocomplete="off" value="<?php echo $email; ?>" required/>
          </div> -->

          

          <div class="modal-footer">
            <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
            <button type="reset" class="btn btn-danger btn-reset" data-dismiss="modal" aria-hidden="true">Batal</button>
          </div>
        </form>
      </div>
    </div>
  </div>