<?php
// Panggil koneksi database
require_once "config/database.php";

$kode_perumahan = $_GET['kode_perumahan'];

if (isset($kode_perumahan)) {
	try {
		// sql statement untuk menghapus data pada tabel marketer
        $query = "DELETE FROM perumahan WHERE kode_perumahan=:kode_perumahan";
        // membuat prepared statements
		$stmt = $pdo->prepare($query);

		//mengikat parameter 
		$stmt->bindParam(':kode_perumahan', $kode_perumahan);

		// eksekusi query
		$stmt->execute();

        // jika berhasil tampilkan pesan berhasil delete data
		header('location: index.php?alert=3');

		// tutup koneksi database
        $pdo = null;
	} catch (PDOException $e) {
		// tampilkan pesan kesalahan
        echo "ada kesalahan : ".$e->getMessage();
	}
}					
?>