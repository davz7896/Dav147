<!DOCTYPE html>
<html>
    <head>
        <title>Ajax Jquery - Belajarphp.net</title>
    </head>
    <body>
        <form action="">
            
            <table>
                <tr><td>NIM</td><td><input type="text" onkeyup="isi_otomatis()" id="nim"></td></tr>
                <tr><td>NAMA</td><td><input readonly type="text" name="nama" id="nama"></td></tr>
                <tr><td>ALAMAT</td><td><input readonly type="text" name="alamat" id="alamat"></td></tr>
                <tr><td>TELEPON</td><td><input readonly type="text" name="telepon" id="telepon"></td></tr>
            
                <tr><td>NAMA PROYEK</td><td><input readonly type="text" name="proyek" value="MILLENNIAL REGENCY"></td></tr>
                <tr><td>KODE PROYEK</td><td><input type="text" onkeyup="isi_otomatis1()" id="nim1"></td></tr>
                <tr><td>NO KAVLING</td><td><input readonly type="text" id="no_kav"></td></tr>
                <tr><td>LB</td><td><input readonly type="text" id="l_bangunan"></td></tr>
                <tr><td>LT</td><td><input readonly type="text" id="l_tanah"></td></tr>
                <tr><td>TIPE</td><td><input readonly type="text" id="tipe"></td></tr>
                <tr><td>HARGA JADI</td><td><input readonly type="text" id="total"></td></tr>
                <tr><td>DPP</td><td><input readonly type="text" id="harga"></td></tr>
                <tr><td>PPN</td><td><input readonly type="text" id="ppn"></td></tr>
            </table>
            
        </form>
        <?php
            
        ?>
        <!-- mengambil data inputan -->
        

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script type="text/javascript">
            function isi_otomatis(){
                var nim = $("#nim").val();
                $.ajax({
                    url: 'proses-ajax.php',
                    data:"nim="+nim ,
                }).success(function (data) {
                    var json = data,
                    obj = JSON.parse(json);
                    $('#nama').val(obj.nama);
                    $('#alamat').val(obj.alamat);
                    $('#telepon').val(obj.telepon);
                });
            }

            function isi_otomatis1(){
                var nim1 = $("#nim1").val();
                $.ajax({
                    url: 'proses-ajax1.php',
                    data:"nim1="+nim1 ,
                }).success(function (data) {
                    var json = data,
                    obj = JSON.parse(json);
                    $('#no_kav').val(obj.no_kav);
                    $('#l_bangunan').val(obj.l_bangunan);
                    $('#l_tanah').val(obj.l_tanah);
                    $('#tipe').val(obj.tipe);
                    $('#total').val(obj.total);
                    $('#harga').val(obj.harga);
                    $('#ppn').val(obj.ppn);
                });
            }
            
        </script>
        
    </body>
</html>
