 <div class="row">
    <div class="col-md-12">
      <div class="page-header">
        <h4>
          <i class="glyphicon glyphicon-user"></i> <?=$_SESSION['nama'];?>
          
          <!-- <a class="btn btn-success pull-right" href="#" data-target="#modal_tambah" data-toggle="modal">
            <i class="glyphicon glyphicon-search"></i> Cari Data Pembeli
          </a>
          <a class="btn btn-success pull-right" href="#" data-target="#modal_tambah" data-toggle="modal">
            <i class="glyphicon glyphicon-search"></i> Cari Data Kavling
          </a> -->
        </h4>
      </div>

  

      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">Input Transaksi Penjualan</h3>
        </div>
        <div class="panel-body">
        <form action="cicilan.php" method="GET">
            <table>
                
                
                <tr><td style="width:200px">DATA PELANGGAN</td></tr>
                <tr><td>Kode Pelanggan</td><td class=".row"><input type="text" onkeyup="isi_otomatis()" name="nim" id="nim"></td></tr>
                <tr><td>Nama</td><td><input type="text" name="nama" id="nama" readonly></td></tr>
                <tr><td>Alamat</td><td><input type="text" name="alamat" id="alamat" readonly></td></tr>
                <tr><td>Telepon</td><td><input type="text" name="telepon" id="telepon" readonly></td></tr>
     
            </table>
            <br>
            <table>
                <tr><td style="width:200px">DATA PROYEK</td></tr>
                <tr><td>Nama Proyek</td><td><input type="text" name="nama_proyek" id="nama_proyek" value="MILLENNIAL REGENCY" readonly></td></tr>
                <tr><td>Kode Proyek</td><td><input type="text" name="nim1" onkeyup="isi_otomatis1()" id="nim1"></td></tr>
                <tr><td>No Kavling</td><td><input type="text" name="no_kav" id="no_kav" readonly></td></tr>
                <tr><td>LB</td><td><input type="text" name="l_bangunan" id="l_bangunan" readonly></td></tr>
                <tr><td>LT</td><td><input type="text" name="l_tanah" id="l_tanah" readonly></td></tr>
                <tr><td>Tipe</td><td><input type="text" name="tipe" id="tipe" readonly></td></tr>
                <tr><td>DPP</td><td><input type="text" name="harga" id="harga" readonly></td></tr>
                <tr><td>PPN</td><td><input type="text" name="ppn" id="ppn" readonly></td></tr>
                <tr><td>Harga Jadi</td><td><input type="text" name="total" id="total" readonly></td></tr>         
            </table>
            <br>
            <table>
                <tr><td style="width:200px">Tanda Jadi</td><td><input type="text" name="tanda_jadi" ></td></tr>
                <tr><td>Uang Muka</td><td><input type="text" name="um" ></td><td>%</td></tr>
                <tr><td>Angsuran</td><td><input type="text" name="angsuran"></td><td>Kali</td></tr>
            </table>
            <tr><input type="submit"  name="proses" value="Proses"></tr>
        </form>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script type="text/javascript">
            function isi_otomatis(){
                var nim = $("#nim").val();
                $.ajax({
                    url: 'proses-ajax.php',
                    data:"nim="+nim ,
                }).success(function (data) {
                    var json = data,
                    obj = JSON.parse(json);
                    $('#nama').val(obj.nama);
                    $('#alamat').val(obj.alamat);
                    $('#telepon').val(obj.telepon);
                });
            }

            function isi_otomatis1(){
                var nim1 = $("#nim1").val();
                $.ajax({
                    url: 'proses-ajax1.php',
                    data:"nim1="+nim1 ,
                }).success(function (data) {
                    var json = data,
                    obj = JSON.parse(json);
                    $('#no_kav').val(obj.no_kav);
                    $('#l_bangunan').val(obj.l_bangunan);
                    $('#l_tanah').val(obj.l_tanah);
                    $('#tipe').val(obj.tipe);
                    $('#harga').val(obj.harga);
                    $('#ppn').val(obj.ppn);
                    $('#total').val(obj.total);
                });
            }
        </script>
        </div>
      </div> <!-- /.panel -->
    </div> <!-- /.col -->
  </div> <!-- /.row -->
  
  