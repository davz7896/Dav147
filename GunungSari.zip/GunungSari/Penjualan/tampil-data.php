 <div class="row">
    <div class="col-md-12">
      <div class="page-header">
        <h4>
          <i class="glyphicon glyphicon-user"></i> <?=$_SESSION['nama'];?>
          
          <!-- <a class="btn btn-success pull-right" href="#" data-target="#modal_tambah" data-toggle="modal">
            <i class="glyphicon glyphicon-search"></i> Cari Data Pembeli
          </a>
          <a class="btn btn-success pull-right" href="#" data-target="#modal_tambah" data-toggle="modal">
            <i class="glyphicon glyphicon-search"></i> Cari Data Kavling
          </a> -->
        </h4>
      </div>

  

      <div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">Input Transaksi Penjualan</h3>
          
        </div>
        <div class="panel-body">
         
        <form action="cicilan.php" method="POST">
        
            <table>               
                <tr><td style="width:200px">DATA PELANGGAN</td></tr>
                <tr><td>Kode Pelanggan</td><td class=".row">
               <select style="position:absolute;top:0px;left:0px;width:200px; height:25px;line-height:20px;margin:0;padding:0;"
               onchange="document.getElementById('nim').value=this.options[this.selectedIndex].text; document.getElementById('idValue').value=this.options[this.selectedIndex].value;">
               <option></option>
               <option value="one">one</option>
               <option value="two">two</option>
               <option value="three">three</option>
            </select>
                
                <input type="text" autocomplete="off" onkeyup="isi_otomatis()" name="nim" id="nim" required></td><td> <a class="btn btn-success" href="#" data-target="#modal_pelanggan" data-toggle="modal">Cek Data Pelanggan</a></td></tr>
                <tr><td>Nama</td><td><input type="text" name="nama" id="nama" autocomplete="off" readonly></td></tr>
                <tr><td>Alamat</td><td><input type="text" name="alamat" id="alamat" autocomplete="off" readonly></td></tr>
                <tr><td>Telepon</td><td><input type="text" name="telepon" id="telepon" autocomplete="off" readonly></td></tr>
     
            </table>
            <br>
            <table>
                <tr><td style="width:200px">DATA PROYEK</td></tr>
                <tr><td>Nama Proyek</td><td><input type="text" name="nama_proyek" id="nama_proyek" value="MILLENNIAL REGENCY" readonly></td></tr>
                <tr><td>Kode Proyek</td><td><input type="text" name="nim1" autocomplete="off" onkeyup="isi_otomatis1()" id="nim1" required></td><td> <a class="btn btn-success" href="#" data-target="#modal_proyek" data-toggle="modal">Cek Data Proyek</a></td></tr>
                <tr><td>No Kavling</td><td><input type="text" name="no_kav" id="no_kav" autocomplete="off" readonly></td></tr>
                <tr><td>LB</td><td><input type="text" name="l_bangunan" id="l_bangunan" autocomplete="off" readonly></td></tr>
                <tr><td>LT</td><td><input type="text" name="l_tanah" id="l_tanah" autocomplete="off" readonly></td></tr>
                <tr><td>Tipe</td><td><input type="text" name="tipe" id="tipe" autocomplete="off" readonly></td></tr>
                <tr><td>DPP</td><td><input style="text-align:right" type="text" name="harga" id="harga" autocomplete="off" readonly></td></tr>
                <tr><td>PPN</td><td><input style="text-align:right" type="text" name="ppn" id="ppn" autocomplete="off" readonly></td></tr>
                <tr><td>Total</td><td><input style="text-align:right" type="text" name="total" id="total" autocomplete="off" readonly></td></tr>         
            </table>
            <br>
            <table>
                <tr><td style="width:200px">Tanda Jadi</td><td><input style="text-align:right" autocomplete="off" type="text" id="tanda_jadi"  name="tanda_jadi" required></td><td><input style="border:0px" id="tanda_jadi"></td></tr>
                <tr><td>Uang Muka</td><td><input style="text-align:right" autocomplete="off" type="text" name="um" required></td><td>%</td></tr>
                <tr><td>Tgl Bayar Uang Muka Ke-1</td> <td><input autocomplete="off" type="date" name="tgl_um" ></td></tr>
                <tr><td>Angsuran</td><td><input style="text-align:right" autocomplete="off" type="text" name="angsuran" required></td><td>Kali</td></tr>
                <tr><td>Tgl Bayar Angsuran Ke-1</td> <td><input autocomplete="off" type="date" name="tgl_ang" ></td></tr>
                <tr><td>Tgl Bayar Angsuran Terakhir</td> <td><input autocomplete="off" type="date" name="tgl_end" ></td></tr>
            </table>
            <tr><input type="submit"  name="proses" value="Proses"></tr>
        </form>
      
        <!-- <form action="proses-simpan.php" method="POST">
        <tr><td>Total</td><td><input style="text-align:right" type="text" name="total1" id="total1" autocomplete="off" value="" readonly></td></tr>
        </form> -->

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        
        <script type="text/javascript">
            function isi_otomatis(){
                var nim = $("#nim").val();
                $.ajax({
                    url: 'proses-ajax.php',
                    data:"nim="+nim ,
                }).success(function (data) {
                    var json = data,
                    obj = JSON.parse(json);
                    $('#nama').val(obj.nama);
                    $('#alamat').val(obj.alamat);
                    $('#telepon').val(obj.telepon);
                });
            }

            function isi_otomatis1(){
                var nim1 = $("#nim1").val();
                $.ajax({
                    url: 'proses-ajax1.php',
                    data:"nim1="+nim1 ,
                }).success(function (data) {
                    var json = data,
                    obj = JSON.parse(json);
                    $('#no_kav').val(obj.no_kav);
                    $('#l_bangunan').val(obj.l_bangunan);
                    $('#l_tanah').val(obj.l_tanah);
                    $('#tipe').val(obj.tipe);
                    $('#harga').val(obj.harga);
                    $('#ppn').val(obj.ppn);
                    $('#total').val(obj.total);
                });
                
            }

            var rupiah = document.getElementById("tanda_jadi");
              rupiah.addEventListener("keyup", function(e) {
                // tambahkan 'Rp.' pada saat form di ketik
                // gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
                rupiah.value = formatRupiah(this.value, "Rp. ");
              });

              /* Fungsi formatRupiah */
              function formatRupiah(angka, prefix) {
                var number_string = angka.replace(/[^,\d]/g, "").toString(),
                  split = number_string.split(","),
                  sisa = split[0].length % 3,
                  rupiah = split[0].substr(0, sisa),
                  ribuan = split[0].substr(sisa).match(/\d{3}/gi);

                // tambahkan titik jika yang di input sudah menjadi angka ribuan
                if (ribuan) {
                  separator = sisa ? "." : "";
                  rupiah += separator + ribuan.join(".");
                }

                rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
                return prefix == undefined ? rupiah : rupiah ? "Rp. " + rupiah : "";
              }

              $(document).ready(function(){
	               $(".tombol-simpan").click(function(){
		               var data = $('.form-user').serialize();
		               $.ajax({
			               type: 'POST',
			               url: "aksi.php",
			               data: data,
			               success: function() {
				               $('.tampildata').load("tampil.php");
			               }
		               });
	               });
               });

        </script>
        
        </div>
      </div> <!-- /.panel -->
    </div> <!-- /.col -->
  </div> <!-- /.row -->
  

  <!-- modal pelanggan -->
  <div class="modal fade" id="modal_pelanggan" role="dialog">
            <div class="modal-dialog">
               <!-- Modal content-->
               <div class="modal-content">
                  <div class="modal-header">
                     <button type="button" class="close" data-dismiss="modal">&times;</button>
                     <h4 class="modal-title">Data Customer</h4>
                  </div>
                  <div class="modal-body">
                     <table id="example" class="table table-bordered">
                        <thead>
                            
                           <tr>
                              <th>No</th>
                              <th>Kode</th>
                              <th>Nama</th>
                              <th>Alamat</th>
                              <th>Telepon</th>
                           </tr>
                        </thead>
                        <tbody>
                           
                           <?php
                                //Data mentah yang ditampilkan ke tabel    
                                require_once "config/database.php";
                                $no = 1;
                                $query = "SELECT * FROM customer ORDER BY nim DESC";
                                $stmt = $pdo->prepare($query);
                                $stmt->execute();
                                // $nama   = $data['nama'];
                                // $alamat = $data['alamat'];
                                while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                    ?>
                                    <tr>
                                        <td><?php echo $no;?></td>
                                        <td><?php echo $data['nim']; ?></td>
                                        <td><?php echo $data['nama']; ?></td>
                                        <td><?php echo $data['alamat']; ?></td>
                                        <td><?php echo $data['telepon']; ?></td>
                                    </tr>
                                    
                                    <?php
                                    
                                    $no++;
                                }
                                
                                ?>
                        </tbody>
                     </table>
                  </div>
                  <div class="modal-footer">
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
               </div>
            </div>
         </div>

        <!-- modal proyek -->
        <div class="modal fade" id="modal_proyek" role="dialog">
            <div class="modal-dialog">
               <!-- Modal content-->
               <div class="modal-content">
                  <div class="modal-header">
                     <button type="button" class="close" data-dismiss="modal">&times;</button>
                     <h4 class="modal-title">Data Proyek</h4>
                  </div>
                  <div class="modal-body">
                     <table id="example" class="table table-bordered">
                        <thead>
                            
                           <tr>
                              <th>No</th>
                              <th>Kode</th>
                              <th>No Kavling</th>
                              <th>Tipe</th>
                              <th>Status</th>
                           </tr>
                        </thead>
                        <tbody>
                           
                           <?php
                                //Data mentah yang ditampilkan ke tabel    
                                require_once "config/database.php";
                                $no = 1;
                                $query = "SELECT * FROM kavling ORDER BY nim1 DESC";
                                $stmt = $pdo->prepare($query);
                                $stmt->execute();
                                // $nama   = $data['nama'];
                                // $alamat = $data['alamat'];
                                while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                    ?>
                                    <tr>
                                        <td><?php echo $no;?></td>
                                        <td><?php echo $data['nim1']; ?></td>
                                        <td><?php echo $data['no_kav']; ?></td>
                                        <td><?php echo $data['tipe']; ?></td>
                                        <td><?php echo $data['status']; ?></td>
                                    </tr>
                                    
                                    <?php
                                    
                                    $no++;
                                }
                                
                                ?>
                        </tbody>
                     </table>
                  </div>
                  <div class="modal-footer">
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
               </div>
            </div>
         </div>