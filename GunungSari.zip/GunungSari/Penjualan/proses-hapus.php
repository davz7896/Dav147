<?php
// Panggil koneksi database
require_once "config/database.php";

$nim = $_GET['id_user'];

if (isset($nim)) {
	try {
		// sql statement untuk menghapus data pada tabel marketer
        $query = "DELETE FROM users WHERE id_user=:id_user";
        // membuat prepared statements
		$stmt = $pdo->prepare($query);

		//mengikat parameter 
		$stmt->bindParam(':id_user', $nim);

		// eksekusi query
		$stmt->execute();

        // jika berhasil tampilkan pesan berhasil delete data
		header('location: index.php?alert=3');

		// tutup koneksi database
        $pdo = null;
	} catch (PDOException $e) {
		// tampilkan pesan kesalahan
        echo "ada kesalahan : ".$e->getMessage();
	}
}					
?>