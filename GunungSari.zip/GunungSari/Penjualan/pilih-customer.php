
<!DOCTYPE html>
<html>
   <head>
   <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
      <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>
   
    <body>
        
    


      <div class="container">
         <div class="panel panel-success">
            <div class="panel-heading">
               <h3 class="panel-title">Transaksi Penjualan</h3>
            </div>
            <div class="panel-body">
               <form>
                  <div class="form-group">
                     <label for="varchar">Data Pembeli</label>
                     <div class="row">
                        <div class="col-md-4">
                           <input type="text" class="form-control pencarian"  placeholder="Nama Pembeli" id="nama-pem">
                           <input type="text" class="form-control pencarian"  placeholder="Alamat" id="alamat-pem">
                           <input type="text" class="form-control pencarian"  placeholder="Telepon" id="telp-pem"><br>
                        </div>
                     </div>
                  </div>
                  <input type="submit" value="Simpan" class="btn btn-parimary">
                  <a class="btn btn-success" href="#" data-target="#myModal" data-toggle="modal">
                      Cari </a>
               </form>
            </div>
         </div>
         <!-- Trigger the modal with a button -->
         <!-- Modal -->
         <div class="modal fade" id="myModal" role="dialog">
            <div class="modal-dialog">
               <!-- Modal content-->
               <div class="modal-content">
                  <div class="modal-header">
                     <button type="button" class="close" data-dismiss="modal">&times;</button>
                     <h4 class="modal-title">DATA Customer</h4>
                  </div>
                  <div class="modal-body">
                     <table id="example" class="table table-bordered">
                        <thead>
                            
                           <tr>
                              <th>No</th>
                              <th>Nama</th>
                              <th>Alamat</th>
                              <th>Telepon</th>
                           </tr>
                        </thead>
                        <tbody>
                           <!-- <tr id="data" onClick="masuk(this,'MHS001')" href="javascript:void(0)">
                              <td><a id="data" onClick="masuk(this,'MHS001')" href="javascript:void(0)">MHS001</a></td>
                              <td><a id="data1" onclick="masuk1(this,'Muhammad')"href="javascript:void(0)">Muhammad Iqbal Ramadhan</td>
                           </tr>
                           <tr id="data" onClick="masuk(this,'MHS002')" href="javascript:void(0)">
                              <td><a id="data" onClick="masuk(this,'MHS002')" href="javascript:void(0)">MHS002</a></td>
                              <td>Muhammad Ramdan Fauzi</td>
                           </tr> -->
                           <?php
                                //Data mentah yang ditampilkan ke tabel    
                                require_once "config/database.php";
                                $no = 1;
                                $query = "SELECT * FROM customer ORDER BY nim DESC";
                                $stmt = $pdo->prepare($query);
                                $stmt->execute();
                                // $nama   = $data['nama'];
                                // $alamat = $data['alamat'];
                                while ($data = $stmt->fetch(PDO::FETCH_ASSOC)) {
                                    ?>
                                    <tr onClick="masuk(this,'<?php echo $data['nama']; ?>' )" href="javascript:void(0)">
                                        <td><?php echo $no;?></td>
                                        <td><?php echo $data['nama']; ?></td>
                                        <td><a id="data1" onClick="masuk1(this,'<?php echo $data['alamat']; ?>' )" href="javascript:void(0)"><?php echo $data['alamat']; ?></a></td>
                                        <td><a id="data2" onClick="masuk2(this,'<?php echo $data['telepon']; ?>' )" href="javascript:void(0)"><?php echo $data['telepon']; ?></a></td>
                                    </tr>
                                    
                                    <?php
                                    
                                    $no++;
                                }
                                
                                ?>
                        </tbody>
                     </table>
                  </div>
                  <div class="modal-footer">
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  </div>
               </div>
            </div>
         </div>
      </div>
      
   </body>
   <script type="text/javascript">
   $(document).ready(function() {
  //focusin berfungsi ketika cursor berada di dalam textbox modal langsung aktif
  $(".pencarian").focusin(function() {
    $("#myModal").modal('show'); // ini fungsi untuk menampilkan modal
  });
  $('#example').DataTable(); // fungsi ini untuk memanggil datatable
});

//function in berfungsi untuk memindahkan data kolom yang di klik menuju text box
function masuk(txt, data) {
  document.getElementById('nama-pem').value = data; // ini berfungsi mengisi value  yang ber id textbox
  //document.getElementById('alamat-pem').value = data; // ini berfungsi mengisi value  yang ber id textbox
  $("#myModal").modal('hide'); // ini berfungsi untuk menyembunyikan modal
}
function masuk1(txt, data1) {
  document.getElementById('alamat-pem').value = data1; // ini berfungsi mengisi value  yang ber id textbox
  $("#myModal").modal('hide'); // ini berfungsi untuk menyembunyikan modal
}
function masuk2(txt, data2) {
  document.getElementById('telp-pem').value = data2; // ini berfungsi mengisi value  yang ber id textbox
  $("#myModal").modal('hide'); // ini berfungsi untuk menyembunyikan modal
}
if (data2==$data['telepon']) {
    document.getElementById('alamat-pem').value=$data['alamat'];
}

   </script>
</html>

