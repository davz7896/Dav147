 <?php
  // Panggil koneksi database
  require_once "config/database.php";

  if (isset($_GET['id_user'])) {
    try {
      // sql statement untuk menampilkan data dari tabel marketer berdasarkan nim
      $query = "SELECT * FROM users WHERE id_user=:id_user";
      // membuat prepared statements
      $stmt = $pdo->prepare($query);

      //mengikat parameter 
      $stmt->bindParam(':id_user', $_GET['id_user']);

      // eksekusi query
      $stmt->execute();

      // mengambil data mahasiswa
      $data = $stmt->fetch(PDO::FETCH_ASSOC);

      // nilai untuk mengisi form
      $id_user           = $data['id_user'];
      $nama          = $data['nama'];
      //$no_ktp  = $data['no_ktp'];
      $username  = $data['username'];
      
      $agen  = $data['agen_marketing'];
      $email  = $data['email'];
      $telepon  = $data['telp'];
      $pass = $data['password'];
      $level        = $data['level_user'];   
      $foto  = $data['foto'];

      // $tanggal       = $data['tanggal_lahir'];
      // $tgl           = explode('-',$tanggal);
      // $tanggal_lahir = $tgl[2]."-".$tgl[1]."-".$tgl[0];
           

      // tutup koneksi database
      $pdo = null;
    } catch (PDOException $e) {
      // tampilkan pesan kesalahan
      echo "ada kesalahan pada query : ".$e->getMessage();
    }
    
  }
  ?>
  <?php
  
  ?>
  
  <script type="text/javascript">
    $(function () {
      //datepicker plugin
      $('.date-picker').datepicker({
        autoclose: true,
        todayHighlight: true
      });
    })
  </script>

  
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title" id="myModalLabel">
          <i class="glyphicon glyphicon-edit"></i> 
          Ubah Data User
        </h4>
      </div>

      <div class="modal-body">
        <form action="proses-ubah.php" method="POST" name="modal_popup" enctype="multipart/form-data" >
          <div class="form-group">
            <label>Kode</label>
            <input type="text" class="form-control" name="id_user" value="<?php echo $id_user; ?>" readonly required/>
          </div>

          <div class="form-group">
            <label>Nama</label>
            <input type="text" class="form-control" name="nama" autocomplete="off" value="<?php echo $nama; ?>" required/>
          </div>
          
          <div class="form-group">
            <label>Username</label>
            <input type="text" class="form-control" name="username" autocomplete="off" value="<?php echo $username; ?>" required/>
          </div>

                 
           <div class="form-group">
            <label>Password</label>
            <input type="text" class="form-control" name="password" autocomplete="off" value="<?php echo $pass; ?>" required/>
          </div>

          <div class="form-group">
              <label>Agen Marketing</label>
              <input type="text" class="form-control" name="agen_marketing" autocomplete="off" value="<?php echo $agen; ?>" required/>
            </div>

          <div class="form-group">
            <label>Email</label>
            <input type="email" class="form-control" name="email" autocomplete="off" value="<?php echo $email; ?>" required/>
          </div>
          
          <div class="form-group">
            <label>Telepon</label>
            <input type="text" class="form-control" name="telp" autocomplete="off" maxlength="13" value="<?php echo $telepon; ?>" onKeyPress="return goodchars(event,'0123456789',this)" required>
          </div>
          
          <div class="form-group">
            <label>Level User</label>
            <input type="text" class="form-control" name="level_user" autocomplete="off" value="<?php echo $level; ?>" required/>
          </div>

          <div class="form-group">
            <label>Foto</label> <br>
            <?php  
            if ($foto=="") { ?>
              <img class="img-mahasiswa" src="foto/default_user.png" alt="Foto" width="110">
            <?php
            } else { ?>
              <img class="img-mahasiswa" src="foto/<?php echo $foto; ?>" alt="Foto" width="110">
            <?php
            }
            ?>
            <br><br>
            <input type="file" name="foto">
            <p class="help-block">
              <small>Catatan :</small> <br>
              <small>- Pastikan file yang diupload bertipe *.JPG atau *.PNG</small> <br>
              <small>- Ukuran file foto max 1 Mb</small>
            </p>
          </div>

          <div class="modal-footer">
            <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
            <button type="reset" class="btn btn-danger btn-reset" data-dismiss="modal" aria-hidden="true">Batal</button>
          </div>
        </form>
      </div>
    </div>
  </div>