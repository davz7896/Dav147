<?php
// Panggil koneksi database
require_once "config/database.php";

if (isset($_POST['simpan'])) {
	if (isset($_POST['kode'])) {
		// ambil data hasil submit dari form
		$kode               = trim($_POST['kode']);
		$nama               = trim($_POST['nama']);
		$norekening         = trim($_POST['norekening']);
		$alamat_bank        = trim($_POST['alamat_bank']);
		$telepon 	        = trim($_POST['telepon']);
		$fax	            = trim($_POST['fax']);
		$kontak             = trim($_POST['kontak']);
		$catatan            = trim($_POST['catatan']);
			
		try {
				// sql statement untuk mengubah data pada tabel rekening
		        $query = "UPDATE rekening   SET nama 			= :nama,
												  norekening 	= :norekening,
												  alamat_bank	= :alamat_bank,
												  telepon       = :telepon,
												  fax	 		= :fax,
												  kontak 		= :kontak,										
												  catatan	    = :catatan	
										    WHERE kode 			= :kode";
		        // membuat prepared statements
		        $stmt = $pdo->prepare($query);

		        // mengikat parameter
				$stmt->bindParam(':kode', $kode);
				$stmt->bindParam(':nama', $nama);
				$stmt->bindParam(':norekening', $norekening);
				$stmt->bindParam(':alamat_bank', $alamat_bank);
				$stmt->bindParam(':telepon', $telepon);
				$stmt->bindParam(':fax', $fax);
				$stmt->bindParam(':kontak', $kontak);
				$stmt->bindParam(':catatan', $catatan);
				// eksekusi query
				$stmt->execute();

				// jika berhasil tampilkan pesan berhasil update data
				header('location: index.php?alert=2');
	
				// tutup koneksi database
				$pdo = null;
			}
			
			catch (PDOException $e) {
				// tampilkan pesan kesalahan
				echo "ada kesalahan : ".$e->getMessage();
			}         
			
		} 
	}
				
?>