<?php
// Panggil koneksi database
require_once "config/database.php";

if (isset($_POST['simpan'])) {
	if (isset($_POST['norekening'])) {
		// ambil data hasil submit dari form
		$norekening         = trim($_POST['norekening']);
		$nama               = trim($_POST['nama']);
		$alamat_bank        = trim($_POST['alamat_bank']);
		$namaPT      	    = trim($_POST['namaPT']);
		$catatan            = trim($_POST['catatan']);
			
		try {
				// sql statement untuk mengubah data pada tabel rekening
		        $query = "UPDATE rekening   SET nama 			= :nama,
												  alamat_bank	= :alamat_bank,	
												  namaPT		= :namaPT,							
												  catatan	    = :catatan	
										    WHERE norekening 	= :norekening";
		        // membuat prepared statements
		        $stmt = $pdo->prepare($query);

		        // mengikat parameter
				$stmt->bindParam(':nama', $nama);
				$stmt->bindParam(':norekening', $norekening);
				$stmt->bindParam(':alamat_bank', $alamat_bank);
				$stmt->bindParam(':namaPT', $namaPT);
				$stmt->bindParam(':catatan', $catatan);
				// eksekusi query
				$stmt->execute();

				// jika berhasil tampilkan pesan berhasil update data
				header('location: index.php?alert=2');
	
				// tutup koneksi database
				$pdo = null;
			}
			
			catch (PDOException $e) {
				// tampilkan pesan kesalahan
				echo "ada kesalahan : ".$e->getMessage();
			}         
			
		} 
	}
				
?>