<?php
// Panggil koneksi database
require_once "config/database.php";

try {
if (isset($_POST['simpan'])) {
	// ambil data hasil submit dari form
	$nama               = trim($_POST['nama']);
	$norekening         = trim($_POST['norekening']);
	$alamat_bank      	= trim($_POST['alamat_bank']);
	$namaPT      		= trim($_POST['namaPT']);
	$catatan            = trim($_POST['catatan']);
	

	
		// sql statement untuk seleksi  dari tabel rekening
		$query = "SELECT norekening FROM rekening WHERE norekening=:norekening";
		// membuat prepared statements
		$stmt = $pdo->prepare($query);
		// mengikat parameter
		$stmt->bindParam(':norekening', $norekening);

		// eksekusi query
		$stmt->execute();

		$count = $stmt->rowCount();
		// jika norekening sudah ada
	
				        $query = "INSERT INTO rekening(nama,norekening,alamat_bank,namaPT,catatan)	
								  VALUES(:nama,:norekening,:alamat_bank,:namaPT,:catatan)";
				        // membuat prepared statements
				        $stmt = $pdo->prepare($query);

				        // mengikat parameter
						$stmt->bindParam(':nama', $nama);
						$stmt->bindParam(':norekening', $norekening);
						$stmt->bindParam(':alamat_bank', $alamat_bank);
						$stmt->bindParam(':namaPT', $namaPT);
						$stmt->bindParam(':catatan', $catatan);

				        $stmt->execute();

				        // jika berhasil tampilkan pesan berhasil simpan data
						header('location: index.php?alert=1');
						
					
					$pdo = null;
						// tutup koneksi database
	}	
}

catch (PDOException $e) {
	// tampilkan pesan kesalahan
	echo "ada kesalahan : ".$e->getMessage();
}	
?>