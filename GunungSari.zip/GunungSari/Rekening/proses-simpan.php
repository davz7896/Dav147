<?php
// Panggil koneksi database
require_once "config/database.php";

try {
if (isset($_POST['simpan'])) {
	// ambil data hasil submit dari form
	$kode               = trim($_POST['kode']);
	$nama               = trim($_POST['nama']);
	$norekening         = trim($_POST['norekening']);
	$alamat_bank      	= trim($_POST['alamat_bank']);
	$telepon            = trim($_POST['telepon']);
	$fax             	= trim($_POST['fax']);
	$kontak             = trim($_POST['kontak']);
	$catatan            = trim($_POST['catatan']);
	

	
		// sql statement untuk seleksi kode dari tabel rekening
		$query = "SELECT kode FROM rekening WHERE kode=:kode";
		// membuat prepared statements
		$stmt = $pdo->prepare($query);
		// mengikat parameter
		$stmt->bindParam(':kode', $kode);

		// eksekusi query
		$stmt->execute();

		$count = $stmt->rowCount();
		// jika kode sudah ada
	
				        $query = "INSERT INTO rekening(kode,nama,norekening,alamat_bank,telepon,fax,kontak,catatan)	
								  VALUES(:kode,:nama,:norekening,:alamat_bank,:telepon,:fax,:kontak,:catatan)";
				        // membuat prepared statements
				        $stmt = $pdo->prepare($query);

				        // mengikat parameter
						$stmt->bindParam(':kode', $kode);
						$stmt->bindParam(':nama', $nama);
						$stmt->bindParam(':norekening', $norekening);
						$stmt->bindParam(':alamat_bank', $alamat_bank);
						$stmt->bindParam(':telepon', $telepon);
						$stmt->bindParam(':fax', $fax);
						$stmt->bindParam(':kontak', $kontak);
						$stmt->bindParam(':catatan', $catatan);

				        $stmt->execute();

				        // jika berhasil tampilkan pesan berhasil simpan data
						header('location: index.php?alert=1');
						
					
					$pdo = null;
						// tutup koneksi database
	}	
}

catch (PDOException $e) {
	// tampilkan pesan kesalahan
	echo "ada kesalahan : ".$e->getMessage();
}	
?>