<?php
// Panggil koneksi database
require_once "config/database.php";

$kode = $_GET['kode'];

if (isset($kode)) {
	try {
		// sql statement untuk menghapus data pada tabel is_mahasiswa
        $query = "DELETE FROM rekening WHERE kode=:kode";
        // membuat prepared statements
		$stmt = $pdo->prepare($query);

		//mengikat parameter 
		$stmt->bindParam(':kode', $kode);

		// eksekusi query
		$stmt->execute();

        // jika berhasil tampilkan pesan berhasil delete data
		header('location: index.php?alert=3');

		// tutup koneksi database
        $pdo = null;
	} catch (PDOException $e) {
		// tampilkan pesan kesalahan
        echo "ada kesalahan : ".$e->getMessage();
	}
}					
?>