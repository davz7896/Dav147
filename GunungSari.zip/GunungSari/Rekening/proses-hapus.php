<?php
// Panggil koneksi database
require_once "config/database.php";

$kode = $_GET['norekening'];

if (isset($norekening)) {
	try {
		// sql statement untuk menghapus data pada tabel is_mahasiswa
        $query = "DELETE FROM rekening WHERE norekening=:norekening";
        // membuat prepared statements
		$stmt = $pdo->prepare($query);

		//mengikat parameter 
		$stmt->bindParam(':norekening', $norekening);

		// eksekusi query
		$stmt->execute();

        // jika berhasil tampilkan pesan berhasil delete data
		header('location: index.php?alert=3');

		// tutup koneksi database
        $pdo = null;
	} catch (PDOException $e) {
		// tampilkan pesan kesalahan
        echo "ada kesalahan : ".$e->getMessage();
	}
}					
?>