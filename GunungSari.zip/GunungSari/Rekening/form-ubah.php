<?php
  // Panggil koneksi database
  require_once "config/database.php";

  if (isset($_GET['norekening'])) {
    try {
      // sql statement untuk menampilkan data dari tabel rekening berdasarkan norekening
      $query = "SELECT * FROM rekening WHERE norekening=:norekening";
      // membuat prepared statements
      $stmt = $pdo->prepare($query);
 
      //mengikat parameter 
      $stmt->bindParam(':norekening', $_GET['norekening']);

      // eksekusi query
      $stmt->execute();

      // mengambil data mahasiswa
      $data = $stmt->fetch(PDO::FETCH_ASSOC);

      // nilai untuk mengisi form
      $norekening          = $data['norekening'];
      $nama          = $data['nama'];
      $norekening    = $data['norekening'];
      $alamat_bank   = $data['alamat_bank'];
      $catatan       = $data['catatan'];

      // tutup koneksi database
      $pdo = null;
    } catch (PDOException $e) {
      // tampilkan pesan kesalahan
      echo "ada kesalahan pada query : ".$e->getMessage();
    }
  }
  ?>
  
  <script type="text/javascript">
    $(function () {
      //datepicker plugin
      $('.date-picker').datepicker({
        autoclose: true,
        todayHighlight: true
      });
    })
  </script>

  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title" id="myModalLabel">
          <i class="glyphicon glyphicon-edit"></i> 
          Ubah data Rekening
        </h4>
      </div>

      <div class="modal-body">
        <form action="proses-ubah.php" method="POST" name="modal_popup" enctype="multipart/form-data" >
        <div class="form-group">
            <label>No Rekening</label>
            <input type="text" class="form-control" name="norekening" value="<?php echo $norekening; ?>" readonly required/>
          </div>

          <div class="form-group">
            <label>Nama</label>
            <input type="text" class="form-control" name="nama" value="<?php echo $nama; ?>"/>
          </div>
          
          <div class="form-group">
            <label>Alamat Bank</label>
            <textarea class="form-control" name="alamat_bank" rows="3" required> <?php echo $alamat_bank; ?></textarea>
          </div>

          <div class="form-group">
            <label>Catatan</label>
            <textarea class="form-control" name="catatan" rows="3" required><?php echo $catatan; ?></textarea>
          </div>

          <div class="modal-footer">
            <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
            <button type="reset" class="btn btn-danger btn-reset" data-dismiss="modal" aria-hidden="true">Batal</button>
          </div>
        </form>
      </div>
    </div>
  </div>