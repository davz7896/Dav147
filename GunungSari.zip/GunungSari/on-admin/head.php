<?php
session_start();

if ( !isset($_SESSION['user_login']) || 
    ( isset($_SESSION['user_login']) && $_SESSION['user_login'] != 'admin' ) ) {

	header('location:./../login.php');
	exit();
}

include "tracking.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>

<style type="text/css">
   .left    { text-align: left;}
   .right   { text-align: right;}
   .center  { text-align: center;}
   .justify { text-align: justify;}
</style>


<link rel="icon" type="image/jpg" href="img/logo/logo.jpg">
  <title>Tridjaya Kartika Groub</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style2.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/format-rupiah.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
	  
      <a class="navbar-brand" href="./../index.php">Millennial Regency</a> 
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
   		<li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Master Data
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="./../AgenMarketing/index.php">Data Agen Marketing</a></li>
          <li><a href="./../Customer/index.php">Data Customer</a></li>
          <li><a href="./../Kavling/index.php">Data Kavling</a></li>
          <li><a href="./../User/index.php">Data User</a></li>
          <li><a href="./../Perumahan/index.php">Data Perumahan</a></li>
		  
		</ul>
    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Transaksi
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="./../Penjualan/index.php">Penjualan</a></li>
          <li><a href="#">Pindah Kavling</a></li>
          <li><a href="#">Ganti Nama</a></li>
          <li><a href="#">Batal</a></li>
          
		</ul>
		<li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Laporan
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="laporan_pembelian.php">Laporan Pembelian</a></li>
          <li><a href="laporan_penjualan.php">Laporan Penjualan</a></li>
          <li><a href="laporan_stok.php">Laporan Stok</a></li>
    </ul>
    <li><a href="./../logout.php">Logout</a></li>
		</ul>
      
    </div>
  </div>
</nav>
</body>
</html>