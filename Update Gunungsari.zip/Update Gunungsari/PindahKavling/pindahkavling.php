

<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script>
    // window.print();
  </script>
</head>
<body>

<div class="container">
<center><h3>SLIP ORDER PINDAH KAVLING</h3></center>
<hr width="100%">

<table>
<?php
require_once "config/database.php";


if (isset($_POST['proses'])) {
  $kode_transaksi     = $_POST['kode_transaksi'];
  $id_pem             = $_POST['id_pelanggan'];
  $nama               = $_POST['nama'];
  $alamat             = $_POST['alamat'];
  $telepon            = $_POST['telepon'];
  $nama_proyek        = $_POST['nama_proyek'];
  $blok               = $_POST['blok'];
  $no_kav             = $_POST['no_kav'];
  $lb                 = $_POST['l_bangunan'];
  $lt                 = $_POST['l_tanah'];
  $utj                = $_POST['utj'];
  $dp                 = $_POST['dp'];
  $angsuran           = $_POST['angsuran'];
  $x_angsur           = $_POST['x_angsur'];
  $tgl_angsur_awal    = $_POST['tgl_angsur_awal'];
  $tgl_angsur_akhir   = $_POST['tgl_angsur_akhir'];
  $harga_jadi         = $_POST['harga_jadi'];
  
	
  $kode_proyek        = $_POST['nim1'];
  $no_kav             = $_POST['no_kav1'];
  $lb                 = $_POST['l_bangunan'];
  $lt                 = $_POST['l_tanah'];
  $tipe               = $_POST['tipe'];
  $biaya              = $_POST['biaya'];
  
  $nota               = $_POST['nim1'].$_POST['no_kav'].$_POST['x_angsur'];

  // $tanda_jadi_str = preg_replace("/[^0-9]/", "", $tanda_jadi);
   $harga_jadi_str = preg_replace("/[^0-9]/", "", $harga_jadi);
   $biaya_str = preg_replace("/[^0-9]/", "", $biaya);
  
  //perhitungan
  $total = $harga_jadi_str + $biaya_str;
  // $sisa_bayar = $harga_jadi_str - $tanda_jadi_str;
  // $uang_muka = ($um/100) * $sisa_bayar;
  // $jum_angsuran = ($sisa_bayar-$uang_muka)/$angsuran;
  // $total = ($jum_angsuran * $angsuran) + $uang_muka + $tanda_jadi_str;

  //menampilkan dengan format rupiah
  // $view_sisa_bayar = "Rp.".number_format($sisa_bayar,0,',','.');
  // $view_uang_muka = "Rp.".number_format($uang_muka,0,',','.');
  // $view_tanda_jadi = "Rp.".number_format($tanda_jadi_str,0,',','.');
  // $view_angsuran = "Rp.".number_format($jum_angsuran,0,',','.');
   $view_total = "Rp.".number_format($total,0,',','.');
  // $view_dpp = "Rp.".number_format($dpp,0,',','.');
  // $view_ppn = "Rp.".number_format($ppn,0,',','.');
  // $view_harga_jadi = "Rp.".number_format($harga_jadi,0,',','.');

  //menampilkan tanggal sekarang
  $tgl=date('d-m-Y');
  $tgl_um=date('d-m-Y');

  $dari = $tgl_angsur_awal;// tanggal mulai
  $sampai = $tgl_angsur_akhir;// tanggal akhir

  try {
    // $query = "DELETE FROM penjualan WHERE kode_transaksi=:nota";
    // $stmt = $pdo->prepare($query);
    // $stmt->bindParam(':nota', $kode_transaksi);
    // $stmt->execute();
    // $pdo = null;

    

    $query = "INSERT INTO `pindah_kavling`(`nota_baru`, `nota_lama`, `id_pelanggan`, `id_kavling`, `no_kavling`, `tgl_jual`, `utj`, `dp`,`angsuran`,`x_angsur`,`tgl_angsur_awal`,`tgl_angsur_akhir`,`harga_jadi`,`biaya_pndah_kav`) 
            VALUES (:nota_baru,:nota_lama,:id_pem,:nim1,:no_kav1,:tgl_um,:utj,:um,:angsuran,:x_angsur,:tgl_ang,:tgl_end,:harga_jadi,:biaya)";
    $stmt = $pdo->prepare($query);
    
    $stmt->bindParam(':nota_baru', $nota);
    $stmt->bindParam(':nota_lama', $kode_transaksi);
    $stmt->bindParam(':id_pem', $id_pem);
		$stmt->bindParam(':nim1', $kode_proyek);
		$stmt->bindParam(':no_kav1', $no_kav);
		$stmt->bindParam(':tgl_um', $tgl_um);
    $stmt->bindParam(':utj', $utj);
    $stmt->bindParam(':um', $dp);
    $stmt->bindParam(':angsuran', $angsuran);
    $stmt->bindParam(':x_angsur', $x_angsur);
    $stmt->bindParam(':tgl_ang', $tgl_angsur_awal);
    $stmt->bindParam(':tgl_end', $tgl_angsur_akhir);
    $stmt->bindParam(':harga_jadi', $harga_jadi);
    $stmt->bindParam(':biaya', $biaya);
    
    $stmt->execute();
    //echo "sudah simpan";
    $pdo = null;
    // $query = "UPDATE penjualan SET 
    //                           id_pelanggan 	= :nim,
    //                           id_kavling 		= :nim1,
    //                           no_kavling 		= :no_kav,
    //                           tgl_jual    	= :tgl_um,
    //                           utj     			= :utj,
    //                           dp      			= :um,
    //                           angsuran   		= :angsuran,
    //                           x_angsur      = :xangsur,
    //                           tgl_angsur_awal = :tgl_awal,
    //                           tgl_angsur_akhir = :tgl_akhir,
    //                           harga_jadi    = :hargajadi,
    //                           WHERE kode_transaksi 		= :kode_transaksi";
    
    
    
		// $stmt->bindParam(':nim', $kode_pelanggan);
		// $stmt->bindParam(':nim1', $kode_proyek);
		// $stmt->bindParam(':no_kav', $no_kav);
		// $stmt->bindParam(':tgl_um', $tgl_um);
		// $stmt->bindParam(':utj', $utj);
    // $stmt->bindParam(':angsuran', $angsuran);
    // $stmt->bindParam(':xangsur', $x_angsur);
    // $stmt->bindParam(':tgl_awal', $tgl_angsur_awal);
    // $stmt->bindParam(':tgl_akhir', $tgl_angsur_akhir);
		// $stmt->bindParam(':harga_jadi', $harga_jadi);
    
    
    //echo "sudah simpan";
    
  } catch (PDOException $e) {
    echo "ada kesalahan : ".$e->getMessage();
  }
}
?>
    <thead>
      
    </thead>
    <tbody>
    
      <tr>
        <td style="width:200px">Nama Pembeli</td>
        <td style="width:10px">:</td>
        <td><?php echo "$nama" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Alamat</td>
        <td style="width:10px">:</td>
        <td><?php echo "$alamat" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Telepon</td>
        <td style="width:10px">:</td>
        <td><?php echo "$telepon" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Lokasi Perumahan</td>
        <td style="width:10px">:</td>
        <td><?php echo "$nama_proyek" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Tanggal Penjualan</td>
        <td style="width:10px">:</td>
        <td><?php echo "$tgl" ?></td>
      </tr>
      <tr>
        <td style="width:200px">No Kavling</td>
        <td style="width:10px">:</td>
        <td><?php echo "$no_kav" ?></td>
      </tr>
      <tr>
        <td style="width:200px">L Tanah / L Bangunan</td>
        <td style="width:10px">:</td>
        <td><?php echo "$lt/$lb" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Harga</td>
        <td style="width:10px">:</td>
        <td><?php echo "$harga_jadi" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Biaya Pindah Kavling</td>
        <td style="width:10px">:</td>
        <td><?php echo "$biaya" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Total</td>
        <td style="width:10px">:</td>
        <td><?php echo "$view_total" ?></td>
        
      </tr>
      
    </tbody>
  </table>
<br>

  <h4>JADWAL PEMBAYARAN YANG DISETUJUI</h4>
         
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Jenis Pembayaran</th>
        <th>Jatuh Tempo</th>
        <th>Jumlah</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>TANDA JADI</td>
        <td><?php echo "$tgl"; ?></td>
        <td><?php echo "$utj" ?></td>
      </tr>
      <tr>
        <td>UANG MUKA</td>
        <td><?php echo "$tgl_um" ?></td>
        <td><?php echo "$dp" ?></td>
      </tr>
      <tr>
        <td>BIAYA GANTI NAMA</td>
        <td><?php echo "$tgl_um" ?></td>
        <td><?php echo "$biaya" ?></td>
      </tr>
      
      <tr>
      <td><?php 
      for ($i=1; $i<=$x_angsur; $i++)
      {
      echo"<table>
      <tr><td>ANGSURAN $i </td> </tr> 
     
      </table>";
      } ?></td>
        <td><?php
              while (strtotime($dari) <= strtotime($sampai)) {
        
               $dari = mktime(0,0,0,date("m",strtotime($dari)), date("d",strtotime($dari))+30,date("Y",strtotime($dari)));
                $dari=date("d-m-Y", $dari);
               echo "$dari<br/>";
           }
            ?></td>
        <td>
        <?php 
      for ($i=1; $i<=$x_angsur; $i++)
      {
      echo"<table>
      <tr><td>$angsuran</td></tr> 
      </table>";
      } ?>
        </td>
      </tr>
      <tr>
        <td colspan="2"><strong>TOTAL</strong></td>
        <td><?php echo "$view_total" ?></td>
      </tr>
    </tbody>
  </table>

</div>

</body>
</html>