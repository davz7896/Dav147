<?php
require_once "config/database.php";
$no_nota = $_GET['kode_transaksi'];
$query = "SELECT `kode_transaksi`,`nama`,`id_pelanggan`,`id_kavling`,`alamat`,`telepon`,`blok`,`no_kav`,`l_tanah`,`l_bangunan`,`utj`,`dp`,`angsuran`,`x_angsur`,`tgl_angsur_awal`,`tgl_angsur_akhir`,`harga_jadi` FROM `penjualan` JOIN `customer` ON penjualan.id_pelanggan = customer.nim JOIN `kavling` ON penjualan.id_kavling = kavling.nim1 WHERE kode_transaksi='$no_nota'";
$stmt = $pdo->prepare($query);
$stmt->execute();
$pindahkav = $stmt->fetch(PDO::FETCH_ASSOC);
$data = array(
            'id_pelanggan' =>  $pindahkav['id_pelanggan'],
            'id_kavling' =>  $pindahkav['id_kavling'],
            'nama'      =>  $pindahkav['nama'],
            'alamat'   =>  $pindahkav['alamat'],
            'telepon'    =>  $pindahkav['telepon'],
            'blok'    =>  $pindahkav['blok'],
            'no_kav'    =>  $pindahkav['no_kav'],
            'l_tanah'    =>  $pindahkav['l_tanah'],
            'l_bangunan'    =>  $pindahkav['l_bangunan'],
            'utj'    =>  $pindahkav['utj'],
            'dp'    =>  $pindahkav['dp'],
            'angsuran'    =>  $pindahkav['angsuran'],
            'x_angsur'    =>  $pindahkav['x_angsur'],
            'tgl_angsur_awal'    =>  $pindahkav['tgl_angsur_awal'],
            'tgl_angsur_akhir'    =>  $pindahkav['tgl_angsur_akhir'],
            'harga_jadi'    =>  $pindahkav['harga_jadi'],
        );
 echo json_encode($data);
?>