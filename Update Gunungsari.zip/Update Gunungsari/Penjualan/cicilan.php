

<!DOCTYPE html>
<html lang="en">
<head>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script>
    window.print();
  </script>
</head>
<body>

<div class="container">
<center><h3>SLIP ORDER</h3></center>
<hr width="100%">

<table>
<?php
require_once "config/database.php";


if (isset($_POST['proses'])) {
  $kode_pelanggan     = $_POST['nim'];
  $nama               = $_POST['nama'];
  $alamat             = $_POST['alamat'];
  $telepon            = $_POST['telepon'];
 
  $kode_proyek        = $_POST['nim1'];
  $nama_proyek        = $_POST['nama_proyek'];
  $no_kav             = $_POST['no_kav'];
  $lb                 = $_POST['l_bangunan'];
  $lt                 = $_POST['l_tanah'];
  $tipe               = $_POST['tipe'];

	$harga_jadi         = $_POST['total'];
	$dpp                = $_POST['harga'];
	$ppn                = $_POST['ppn'];
  $tanda_jadi         = $_POST['tanda_jadi'];
  $um                 = $_POST['um'];
  $tgl_um             = $_POST['tgl_um'];
  $angsuran           = $_POST['angsuran'];
  $tgl_ang            = $_POST['tgl_ang'];
  $tgl_end            = $_POST['tgl_end'];
  
  $nota               = $_POST['nim1'].$_POST['no_kav'].$_POST['angsuran'];

  $tanda_jadi_str = preg_replace("/[^0-9]/", "", $tanda_jadi);
  $harga_jadi_str = preg_replace("/[^0-9]/", "", $harga_jadi);
  
  //perhitungan
  $sisa_bayar = $harga_jadi_str - $tanda_jadi_str;
  $uang_muka = ($um/100) * $sisa_bayar;
  $jum_angsuran = ($sisa_bayar-$uang_muka)/$angsuran;
  $total = ($jum_angsuran * $angsuran) + $uang_muka + $tanda_jadi_str;

  //menampilkan dengan format rupiah
  $view_sisa_bayar = "Rp.".number_format($sisa_bayar,0,',','.');
  $view_uang_muka = "Rp.".number_format($uang_muka,0,',','.');
  $view_tanda_jadi = "Rp.".number_format($tanda_jadi_str,0,',','.');
  $view_angsuran = "Rp.".number_format($jum_angsuran,0,',','.');
  $view_total = "Rp.".number_format($total,0,',','.');
  $view_dpp = "Rp.".number_format($dpp,0,',','.');
  $view_ppn = "Rp.".number_format($ppn,0,',','.');
  $view_harga_jadi = "Rp.".number_format($harga_jadi,0,',','.');

  //menampilkan tanggal sekarang
  $tgl=date('d-m-Y');
  $tgl_um=date('d-m-Y');
  

  $dari = $tgl_ang;// tanggal mulai
  $sampai = $tgl_end;// tanggal akhir

  try {
    $query = "INSERT INTO `penjualan`(`kode_transaksi`, `id_pelanggan`, `id_kavling`, `no_kavling`, `tgl_jual`, `utj`, `dp`,`angsuran`,`x_angsur`,`tgl_angsur_awal`,`tgl_angsur_akhir`,`harga_jadi`) 
            VALUES (:nota,:nim,:nim1,:no_kav,:tgl_um,:utj,:um,:angsuran,:x_angsur,:tgl_ang,:tgl_end,:harga_jadi)";
    $stmt = $pdo->prepare($query);
    
    $stmt->bindParam(':nota', $nota);
		$stmt->bindParam(':nim', $kode_pelanggan);
		$stmt->bindParam(':nim1', $kode_proyek);
		$stmt->bindParam(':no_kav', $no_kav);
		$stmt->bindParam(':tgl_um', $tgl_um);
		$stmt->bindParam(':utj', $tanda_jadi);
    $stmt->bindParam(':um', $view_uang_muka);
    $stmt->bindParam(':angsuran', $view_angsuran);
    $stmt->bindParam(':x_angsur', $angsuran);
    $stmt->bindParam(':tgl_ang', $dari);
    $stmt->bindParam(':tgl_end', $sampai);
		$stmt->bindParam(':harga_jadi', $view_harga_jadi);
    
    $stmt->execute();
    //echo "sudah simpan";
    $pdo = null;
  } catch (PDOException $e) {
    echo "ada kesalahan : ".$e->getMessage();
  }
}
?>
    <thead>
      
    </thead>
    <tbody>
    
      <tr>
        <td style="width:200px">Nama Pembeli</td>
        <td style="width:10px">:</td>
        <td><?php echo "$nama" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Alamat</td>
        <td style="width:10px">:</td>
        <td><?php echo "$alamat" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Telepon</td>
        <td style="width:10px">:</td>
        <td><?php echo "$telepon" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Lokasi Perumahan</td>
        <td style="width:10px">:</td>
        <td><?php echo "$nama_proyek" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Tanggal Penjualan</td>
        <td style="width:10px">:</td>
        <td><?php echo "$tgl" ?></td>
      </tr>
      <tr>
        <td style="width:200px">No Kavling</td>
        <td style="width:10px">:</td>
        <td><?php echo "$no_kav" ?></td>
      </tr>
      <tr>
        <td style="width:200px">L Tanah / L Bangunan</td>
        <td style="width:10px">:</td>
        <td><?php echo "$lt/$lb" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Harga</td>
        <td style="width:10px">:</td>
        <td><?php echo "$view_dpp" ?></td>
      </tr>
      <tr>
        <td style="width:200px">PPN</td>
        <td style="width:10px">:</td>
        <td><?php echo "$view_ppn" ?></td>
      </tr>
      <tr>
        <td style="width:200px">Total</td>
        <td style="width:10px">:</td>
        <td><?php echo "$view_harga_jadi" ?></td>
        
      </tr>
      
    </tbody>
  </table>
<br>

  <h4>JADWAL PEMBAYARAN YANG DISETUJUI</h4>
         
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Jenis Pembayaran</th>
        <th>Jatuh Tempo</th>
        <th>Jumlah</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>TANDA JADI</td>
        <td><?php echo "$tgl"; ?></td>
        <td><?php echo "$view_tanda_jadi" ?></td>
      </tr>
      <tr>
        <td>UANG MUKA</td>
        <td><?php echo "$tgl_um" ?></td>
        <td><?php echo "$view_uang_muka" ?></td>
      </tr>
      
      <tr>
      <td><?php 
      for ($i=1; $i<=$angsuran; $i++)
      {
      echo"<table>
      <tr><td>ANGSURAN $i </td> </tr> 
     
      </table>";
      } ?></td>
        <td><?php
              while (strtotime($dari) <= strtotime($sampai)) {
        
               $dari = mktime(0,0,0,date("m",strtotime($dari)), date("d",strtotime($dari))+30,date("Y",strtotime($dari)));
                $dari=date("d-m-Y", $dari);
               echo "$dari<br/>";
           }
            ?></td>
        <td>
        <?php 
      for ($i=1; $i<=$angsuran; $i++)
      {
      echo"<table>
      <tr><td>$view_angsuran</td></tr> 
     
      </table>";
      } ?>
        </td>
      </tr>
      <tr>
        <td colspan="2"><strong>TOTAL</strong></td>
        <td><?php echo "$view_total" ?></td>
      </tr>
    </tbody>
  </table>

</div>

</body>
</html>