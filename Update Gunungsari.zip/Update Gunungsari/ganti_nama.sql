-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2019 at 11:43 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_gunungsari`
--

-- --------------------------------------------------------

--
-- Table structure for table `ganti_nama`
--

CREATE TABLE `ganti_nama` (
  `nota` varchar(30) NOT NULL,
  `id_pelanggan` varchar(30) NOT NULL,
  `id_kavling` varchar(30) NOT NULL,
  `no_kavling` varchar(30) NOT NULL,
  `tgl_jual` varchar(30) NOT NULL,
  `utj` varchar(30) NOT NULL,
  `dp` varchar(30) NOT NULL,
  `angsuran` varchar(30) NOT NULL,
  `x_angsur` varchar(10) NOT NULL,
  `tgl_angsur_awal` varchar(30) NOT NULL,
  `tgl_angsur_akhir` varchar(30) NOT NULL,
  `harga_jadi` varchar(30) NOT NULL,
  `biaya_gnti_nama` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ganti_nama`
--

INSERT INTO `ganti_nama` (`nota`, `id_pelanggan`, `id_kavling`, `no_kavling`, `tgl_jual`, `utj`, `dp`, `angsuran`, `x_angsur`, `tgl_angsur_awal`, `tgl_angsur_akhir`, `harga_jadi`, `biaya_gnti_nama`) VALUES
('FR/A/0030033', '7136163', 'FR/A/003', '003', '20-05-2019', 'Rp. 1.000.000', 'Rp.1.340.000', 'Rp.1.786.667', '3', '2019-05-17', '2019-07-17', 'Rp.7.700.000', 'Rp. 1.000.000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ganti_nama`
--
ALTER TABLE `ganti_nama`
  ADD PRIMARY KEY (`nota`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
