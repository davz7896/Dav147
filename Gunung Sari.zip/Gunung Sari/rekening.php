<?php

require_once("config.php");

if(isset($_POST['register'])){

    // filter data yang diinputkan
    $kode = filter_input(INPUT_POST, 'kode', FILTER_SANITIZE_STRING);
    $nama = filter_input(INPUT_POST, 'nama', FILTER_SANITIZE_STRING);
    $rekening = filter_input(INPUT_POST, 'rekening', FILTER_SANITIZE_STRING);
    $alamat_bank = filter_input(INPUT_POST, 'alamat_bank', FILTER_SANITIZE_STRING);
    $telepon = filter_input(INPUT_POST, 'telepon', FILTER_SANITIZE_STRING);
    $fax = filter_input(INPUT_POST, 'fax', FILTER_SANITIZE_STRING);
    $kontak_orang = filter_input(INPUT_POST, 'kontak_orang', FILTER_SANITIZE_STRING);
    $catatan = filter_input(INPUT_POST,'catatan', FILTER_SANITIZE_STRING);
    // enkripsi password
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    


    // menyiapkan query
    $sql = "INSERT INTO users (kode, nama, rekening, password, alamat_bank, telepon, fax, kontak_orang, catatan) 
            VALUES (:kode, :nama, :rekening, :password, :alamat_bank, :telepon, :fax, :kontak_orang, :catatan)";
    $stmt = $db->prepare($sql);

    // bind parameter ke query
    $params = array(
        ":kode" => $kode,
        ":nama" => $nama,
        ":password" => $password,
        ":rekening" => $rekening,
        ":alamat_bank" => $alamat_bank,
        ":telepon" => $telepon,
        ":fax" => $fax,
        ":kontak_orang" => $kontak_orang,
        ":catatan" => $catatan
        
    );

    // eksekusi query untuk menyimpan ke database
    $saved = $stmt->execute($params);

    // jika query simpan berhasil, maka user sudah terdaftar
    // maka alihkan ke halaman login
    if($saved) header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kavling Register</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">

        <p>&larr; <a href="index.php">Home</a>

        <p><h3> Registrasi Data Rekening </h3></p>

        <form action="" method="POST">

            <div class="form-group">
                <label for="kode">Kode</label>
                <input class="form-control" type="text" name="kode" placeholder="Masukan Kode" onkeypress="return Angkasaja(event)" />
            </div>

            <div class="form-group">
                <label for="nama">Nama</label>
                <input class="form-control" type="text" name="nama" placeholder="Masukan Nama" />
            </div>

            <div class="form-group">
                <label for="rekening">Rekening</label>
                <input class="form-control" type="text" name="rekening" placeholder="Masukkan Rekening " onkeypress="return Angkasaja(event)" />
            </div>

            <div class="form-group">
                <label for="alamat_bank">Alamat Bank</label>
                <input class="form-control" type="text" name="alamat_bank" placeholder="Masukan Alamat Bank" />
            </div>

            <div class="form-group">
                <label for="telepon">Telepon</label>
                <input class="form-control" type="number" name="telepon" placeholder="Masukan No Telepon" onkeypress="return Angkasaja(event)" />
            </div>

            <div class="form-group">
                <label for="fax">Fax</label>
                <input class="form-control" type="number" name="fax" placeholder="Masukan Fax" />
            </div>

            <div class="form-group">
                <label for="fax">Kontak Orang</label>
                <input class="form-control" type="number" name="kontak_orang" placeholder="Masukan No Kontak" onkeypress="return Angkasaja(event)" />
            </div>

            <div class="form-group">
                <label for="catatan">Catatan</label>
                <textarea class="form-control" rows="5" id="comment" name="catatan" placeholder="Masukan yang Perlu dicatat"></textarea>
               
            </div>
  
            <input type="submit" class="btn btn-success btn-block" name="register" value="Daftar" />

        </form>
            
        </div>

        <div class="col-md-6">
            <img class="img img-responsive" src="img/logodpn.png" />
        </div>

    </div>
</div>

<!-- //Java untuk mengatur pemasukan angka saja -->
<script type="text/javascript">
function Angkasaja(evt) {
var charCode = (evt.which) ? evt.which : event.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57))
return false;
return true;
}
</script>
</body>
</html>