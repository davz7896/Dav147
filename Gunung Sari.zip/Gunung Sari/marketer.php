<?php

require_once("config.php");

if(isset($_POST['register'])){

    // filter data yang diinputkan
    $kode = filter_input(INPUT_POST, 'kode', FILTER_SANITIZE_STRING);
    $nama = filter_input(INPUT_POST, 'nama', FILTER_SANITIZE_STRING);
    $alamat1 = filter_input(INPUT_POST, 'alamat1', FILTER_SANITIZE_STRING);
    $kota1 = filter_input(INPUT_POST, 'kota1', FILTER_SANITIZE_STRING);
    $telepon1 = filter_input(INPUT_POST, 'telepon1', FILTER_SANITIZE_STRING);
    $npwp = filter_input(INPUT_POST, 'npwp', FILTER_SANITIZE_STRING);
    
    // enkripsi password
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    


    // menyiapkan query
    $sql = "INSERT INTO marketer (kode, nama, alamat1, kota1,telepon1, npwp) 
            VALUES (:kode, :nama, :alamat1, :kota1, :telepon1, :npwp)";
    $stmt = $db->prepare($sql);

    // bind parameter ke query
    $params = array(
        ":kode" => $kode,
        ":nama" => $nama,
        ":alamat1" => $alamat1,
        ":kota1" => $kota1,
        ":telepon1" => $telepon1,
        ":npwp" => $npwp
        
    );

    // eksekusi query untuk menyimpan ke database
    $saved = $stmt->execute($params);

    // jika query simpan berhasil, maka user sudah terdaftar
    // maka alihkan ke halaman login
    if($saved) header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Kavling Register</title>

    <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6">

        <p>&larr; <a href="index.php">Home</a>

        <p><h3> Registrasi Data Marketer </h3></p>

        <form action="" method="POST">

            <div class="form-group">
                <label for="kode">Kode</label>
                <input class="form-control" type="text" name="kode" placeholder="Kode secara otomatis" />
            </div>

            <div class="form-group">
                <label for="nama">Nama</label>
                <input class="form-control" type="text" name="nama" placeholder="Masukan Nama" />
            </div>

            <div class="form-group">
                <label for="alamat1">Alamat-1</label>
                <input class="form-control" type="text" name="alamat1" placeholder="Masukkan Alamat-1 " />
            </div>

            <div class="form-group">
                <label for="kota1">Kota-1</label>
                <input class="form-control" type="text" name="kota1" placeholder="Masukan Alamat Bank" />
            </div>

            <div class="form-group">
                <label for="telepon1">Telepon-1</label>
                <input class="form-control" type="number" name="telepon1" placeholder="Masukan No Telepon-1" onkeypress="return Angkasaja(event)" />
            </div>

            <div class="form-group">
                <label for="npwp">NPWP</label>
                <input class="form-control" type="number" name="npwp" placeholder="Masukan NPWP" />
            </div>
  
            <input type="submit" class="btn btn-success btn-block" name="register" value="Daftar" />

        </form>
            
        </div>

        <div class="col-md-5">
        <br><br><br>
             <div class="form-group">
                <label for="kode">Tanggal Lahir</label>
                <input class="form-control" type="text" name="kode" placeholder="Masukan Tanggal Lahir" />
            </div>

            <div class="form-group">
                <label for="nama">Email</label>
                <input class="form-control" type="text" name="nama" placeholder="Masukan Email" />
            </div>

            <div class="form-group">
                <label for="alamat1">Kontak Orang</label>
                <input class="form-control" type="text" name="alamat1" placeholder="Masukkan Kontak Orang " />
            </div>

            <div class="form-group">
                <label for="kota1">Link PDF</label>
                <input class="form-control" type="text" name="kota1" placeholder="Link PDF" />
            </div>
        </div>

 <div class="col-md-5">
        <br><br><br>
             <div class="form-group">
                <label for="kode">Tanggal Lahir</label>
                <input class="form-control" type="text" name="kode" placeholder="Masukan Tanggal Lahir" />
            </div>

            <div class="form-group">
                <label for="nama">Email</label>
                <input class="form-control" type="text" name="nama" placeholder="Masukan Email" />
            </div>

            <div class="form-group">
                <label for="alamat1">Kontak Orang</label>
                <input class="form-control" type="text" name="alamat1" placeholder="Masukkan Kontak Orang " />
            </div>

            <div class="form-group">
                <label for="kota1">Link PDF</label>
                <input class="form-control" type="text" name="kota1" placeholder="Link PDF" />
            </div>
        </div>
    </div>
</div>

<!-- //Java untuk mengatur pemasukan angka saja -->
<script type="text/javascript">
function Angkasaja(evt) {
var charCode = (evt.which) ? evt.which : event.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57))
return false;
return true;
}
</script>
</body>
</html>