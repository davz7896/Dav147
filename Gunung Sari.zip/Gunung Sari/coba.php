<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gunung Sari Front Office</title>

     <link rel="stylesheet" href="css/bootstrap.min.css" />
</head>
<body class="bg-light">
   

                        <div class="btn-group">
                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                    Default <span class="caret"></span>
                                </button>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="#"> Menu 1 </a></li>
                                    <li><a href="#"> Menu 2 </a></li>
                                    <li><a href="#"> Menu 3 </a></li>
                                    <li class="devider"></li>
                                    <li><a href="#"> Menu 4 </a></li>
                                </ul>
                        </div>

</body>
</html>