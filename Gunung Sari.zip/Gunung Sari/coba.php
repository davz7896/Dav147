<html>
<head>
<title>Input Data Hanya Angka - ROOT93.CO.ID</title>
</head>
<body>
<h1>Mengatur Input Form Hanya Boleh Diisi Angka Saja</h1>
<form action="" method="POST">
<input type="text" onkeypress="return Angkasaja(event)"/>
<input type="submit" name="submit" value="Kirim">
</form>
<script type="text/javascript">
function Angkasaja(evt) {
var charCode = (evt.which) ? evt.which : event.keyCode
if (charCode > 31 && (charCode < 48 || charCode > 57))
return false;
return true;
}
</script>
</body>
</html>