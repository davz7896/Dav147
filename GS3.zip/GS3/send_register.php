<?php
if (isset($_POST['username_admin']) && $_POST['username_admin']) {
    // memasukan file koneksi ke database
    require_once 'config.php';
    // menyimpan variable yang dikirim Form
    $nama_admin = $_POST['nama_admin'];
    $id_admin = $_POST['id_admin'];
    $username_admin = $_POST['username_admin'];
    $pass_admin = $_POST['pass_admin'];
    $konfirm = $_POST['konfirm'];
    $agen_marketing = $_POST['agen_marketing'];
    $email = $_POST['email'];
    $telepon = $_POST['telepon'];
    $foto = $_POST['foto'];

    $nama_file          = $_FILES['foto']['name'];
	$ukuran_file        = $_FILES['foto']['size'];
	$tipe_file          = $_FILES['foto']['type'];
	$tmp_file           = $_FILES['foto']['tmp_name'];
	
	// tentukan extension yang diperbolehkan
	$allowed_extensions = array('jpg','jpeg','png');
	
	// Set path folder tempat menyimpan gambarnya
	$path_file          = "foto/".$nama_file;
	
	// check extension
	$file               = explode(".", $nama_file);
    $extension          = array_pop($file);
    
    // cek nilai variable
    if (empty($nama_admin)) {
        header('location: ./register.php?error=' .base64_encode('Nama tidak boleh kosong'));
    }
    if (empty($username_admin)) {
        header('location: ./register.php?error=' .base64_encode('Username tidak boleh kosong'));   
    }
    if (empty($pass_admin)) {
        header('location: ./register.php?error=' .base64_encode('Password tidak boleh kosong'));   
    }
    // validasi apakah password dengan repassword sama
    if ($pass_admin != $konfirm) { // jika tidak sama
        header('location: ./register.php?error=' .base64_encode('Password tidak sama'));   
    }
    // encryption dengan md5
    $password = md5($password);
    $level = 'member'; // default, 
    // SQL Insert
    $sql = "INSERT INTO t_admin (id_admin,foto, nama_admin, username_admin, pass_admin, agen_marketing, email, telepon) VALUES ('$id_admin','$foto', '$nama_admin', '$username_admin', '$pass_admin', '$agen_marketing', '$email', '$telepon')";
    $insert = $dbconnect->query($sql);
    // jika gagal
    if (! $insert) {
        echo "<script>alert('".$dbconnect->error."'); window.location.href = './register.php';</script>";
    } else {
        echo "<script>alert('Insert Data Berhasil'); window.location.href = './index.php';</script>";
    }
}


?>
