<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbName = "db_kredit_1kj2n3";
$koneksi= mysql_connect($host, $user, $pass);
mysql_select_db($dbName)
or die ("Connect Failed !! : ".mysql_error());
?>