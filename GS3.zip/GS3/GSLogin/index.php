<?php
	include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Halaman Login</title>

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style2.css" rel="stylesheet">
  </head>
  <body>
    <div class="col-md-4 col-md-offset-4 form-login">
    
    <?php
    /* handle error */
    if (isset($_GET['error'])) : ?>
        <div class="alert alert-warning alert-dismissible" role="alert">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
          <strong>Warning!</strong> <?=base64_decode($_GET['error']);?>
        </div>
    <?php endif;?>

        <div class="outter-form-login">
        <div class="logo-login">
            <em class="glyphicon glyphicon-user"></em>
        </div>
            <form action="check-login.php" class="inner-login" method="post">
            <h3 class="text-center title-login">Pastikan Mengisi Data dengan Lengkap</h3>
                
                <div class="text-center forget">
                <a data-target="#modal_tambah" data-toggle="modal" href="#"><p>KLIK DISINI UNTUK DAFTAR</p></a>
                </div>
            </form>
        </div>
    </div>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

 <!-- Modal Popup untuk tambah--> 
 <div id="modal_tambah" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title" id="myModalLabel">
            <i class="glyphicon glyphicon-edit"></i> 
            Daftar User
          </h4>
        </div>

        <div class="modal-body">
          <form action="proses-simpan.php" method="POST" name="modal_popup" enctype="multipart/form-data">
            
            <div class="form-group">
              <label>No KTP</label>
              <input type="text" class="form-control" name="id_admin" autocomplete="off" maxlength="10"  required/>
            </div>

            <div class="form-group">
              <label>Nama</label>
              <input type="text" class="form-control" name="nama_admin" autocomplete="off" required/>
            </div>


            <div class="form-group">
              <label>Username</label>
              <input type="text" class="form-control" name="username_admin" autocomplete="off" required/>
            </div>
            
            <div class="form-group">
           <label>Password</label>
              <input type="password" class="form-control" name="pass_admin" autocomplete="off" required/>
          </div>

          <div class="form-group">
           <label>Re-Password</label>
              <input type="password" class="form-control" name="repassword" autocomplete="off" required/>
          </div>

            <div class="form-group">
              <label>Agen Marketing</label>
              <input type="text" class="form-control" name="agen_marketing" autocomplete="off" required/>
            </div>
     
            <div class="form-group">
              <label>Telepon</label>
              <input type="text" class="form-control" name="telepon" autocomplete="off" maxlength="13" onKeyPress="return goodchars(event,'0123456789',this)" required>
            </div>

          <div class="form-group">
              <label>Email</label>
              <input type="text" class="form-control" name="email" autocomplete="off" required/>
            </div>

            <div class="form-group">
              <label>Level User</label>
              <input type="text" class="form-control" name="level_user" autocomplete="off" required/>
            </div>

            <div class="form-group">
              <label>Foto</label>
              <input type="file" name="foto" required>
              <p class="help-block">
                <small>Catatan :</small> <br>
                <small>- Pastikan file yang diupload bertipe *.JPG atau *.PNG</small> <br>
                <small>- Ukuran file foto max 1 Mb</small>
              </p>
            </div>

            <div class="modal-footer">
              <input type="submit" class="btn btn-success btn-submit" name="simpan" value="Simpan">
              <button type="reset" class="btn btn-danger btn-reset" data-dismiss="modal" aria-hidden="true">Batal</button>
            </div>

          </form>
        </div>
      </div>
    </div>
  </div>

  </body>
</html>