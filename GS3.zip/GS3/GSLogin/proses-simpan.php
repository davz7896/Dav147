<?php
// Panggil koneksi database
require_once "config/database.php";

if (isset($_POST['simpan'])) {
	// ambil data hasil submit dari form
	$id_admin           = trim($_POST['id_admin']);
	$nama_admin         = trim($_POST['nama_admin']);
	$username_admin		= trim($_POST['username_admin']);
    $pass_admin 	    = trim($_POST['pass_admin']);
	$repassword  	    = trim($_POST['repassword']);
	$agen_marketing     = trim($_POST['agen_marketing']);
	$email			    = trim($_POST['email']);
	$telepon	        = trim($_POST['telepon']);

	
	$nama_file          = $_FILES['foto']['name'];
	$ukuran_file        = $_FILES['foto']['size'];
	$tipe_file          = $_FILES['foto']['type'];
	$tmp_file           = $_FILES['foto']['tmp_name'];
	
	// tentukan extension yang diperbolehkan
	$allowed_extensions = array('jpg','jpeg','png');
	
	// Set path folder tempat menyimpan gambarnya
	$path_file          = "foto/".$nama_file;
	
	// check extension
	$file               = explode(".", $nama_file);
	$extension          = array_pop($file);

	try {
		// sql statement untuk seleksi id_admin dari tabel marketer
		$query = "SELECT id_admin FROM t_admin WHERE id_admin=:id_admin";
		// membuat prepared statements
		$stmt = $pdo->prepare($query);

		// mengikat parameter
		$stmt->bindParam(':id_admin', $id_admin);

		// eksekusi query
		$stmt->execute();

		$count = $stmt->rowCount();
		// jika id_admin sudah ada
		if($count > 0) {
			// tampilkan pesan id_admin sudah ada
			header("location: index.php?id_admin=$id_admin&alert=4");
		}
		// jika id_admin belum ada
		else {
			// Cek apakah tipe file yang diupload sesuai dengan allowed_extensions
			if (in_array($extension, $allowed_extensions)) {
                // Jika tipe file yang diupload sesuai dengan allowed_extensions, lakukan : 
                if($ukuran_file <= 1000000) { // Cek apakah ukuran file yang diupload kurang dari sama dengan 1MB
                    // Jika ukuran file kurang dari sama dengan 1MB, lakukan :
                    // Proses upload
                    if(move_uploaded_file($tmp_file, $path_file)) { // Cek apakah gambar berhasil diupload atau tidak
                		// Jika gambar berhasil diupload, Lakukan : 
						// sql statement untuk menyimpan data ke tabel marketer
						
						$pass_admin = md5($pass_admin);
						$level_admin = 'user'; // default, 
						$stat_admin = 1 ; // default, 
	
				        $query = "INSERT INTO t_admin(id_admin,nama_admin,username_admin,pass_admin,level_admin,stat_admin,agen_marketing,email,telepon,foto)	
								  VALUES(:id_admin,:nama_admin,:username_admin,:pass_admin,:level_admin,:stat_admin,:agen_marketing,:email,:telepon,:foto)";
				        // membuat prepared statements
				        $stmt = $pdo->prepare($query);

				        // mengikat parameter
						$stmt->bindParam(':id_admin', $id_admin);
						$stmt->bindParam(':nama_admin', $nama_admin);
						$stmt->bindParam(':username_admin', $username_admin);
						$stmt->bindParam(':pass_admin', $pass_admin);
						$stmt->bindParam(':level_admin', $level_admin);
						$stmt->bindParam(':stat_admin', $stat_admin);
						$stmt->bindParam(':agen_marketing', $agen_marketing);
						$stmt->bindParam(':email', $email);
						$stmt->bindParam(':telepon', $telepon);
						$stmt->bindParam(':foto',$nama_file);

						// eksekusi query
				        $stmt->execute();

				        // jika berhasil tampilkan pesan berhasil simpan data
						header('location: index.php?alert=1');
                    } else {
                        // Jika gambar gagal diupload, tampilkan pesan gagal upload
                        header("location: index.php?alert=5");
                    }
                } else {
                    // Jika ukuran file lebih dari 1MB, tampilkan pesan gagal upload
                    header("location: index.php?alert=6");
                }
            } else {
                // Jika tipe file yang diupload bukan jpg, jpeg, png, tampilkan pesan gagal upload
                header("location: index.php?alert=7");
            }
		}

		// tutup koneksi database
        $pdo = null;
	} catch (PDOException $e) {
		// tampilkan pesan kesalahan
        echo "ada kesalahan : ".$e->getMessage();
	}
}						
?>