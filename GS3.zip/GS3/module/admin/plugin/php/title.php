<?php
if($m==1){
	echo"Home";
}else if($m==2){
	echo"Kavling";
}else if($m==3){
	echo"Pelanggan";
}else if($m==4){
	echo"Angsuran";
}else if($m==5){
	echo"Laporan";
}else if($m==6){
	echo"Admin";
}else if($m==7){
	echo"PERUMAHAN";
}else if($m==8){
	echo"Laporan Pelanggan";
}else if($m==9){
	echo"Laporan Angsuran";
}else if($m==10){
	echo"Laporan Kavling";
}else if($m==11){
	echo"Edit Merk";
}else if($m==12){
	echo"Tambah Kavling";
}else if($m==13){
	echo"Edit Kavling";
}else if($m==14){
	echo"Data Kavling";
}else if($m==15){
	echo"Perusahaan";
}else if($m==16){
	echo"Pencarian Kavling";
}else if($m==17){
	echo"Edit Admin";
}else if($m==18){
	echo"Tambah Pelanggan";
}else if($m==19){
	echo"Pembelian Pelanggan";
}else if($m==20){
	echo"Data Pelanggan";
}else if($m==21){
	echo"Edit Data Pelanggan";
}else if($m==22){
	echo"Edit Data Pembelian";
}else if($m==23){
	echo"Pencarian Pelanggan";
}else if($m==24){
	echo"Pembayaran Angsuran";
}else{
	echo"404";
}
?>