<?php
error_reporting(0);

mysql_connect("localhost","root","");
mysql_select_db("db_kredit_1kj2n3");
?>