<ul id='menu'>
	<li><a href='?m=1'>Milineal Regency</a></li>
    <li><a>Data Master</a>
    	<ul id='submenu'>
            <li><a href='?m=15'style='margin-top:0px'>Data Agen Marketing</a></li>
            <li><a href='?m=3' style='margin-top:0px'>Data Customer</a></li>
        	<li><a href='?m=2' style='margin-top:0px'>Data Kavling</a></li>          
        	<li><a href='?m=6' style='margin-top:0px'>Data User</a></li>
        </ul>
    </li>
    <li><a>Transaksi</a>
    	<ul id='submenu'>
            <li><a href='?m=4' style='margin-top:0px'>Penjualan</a></li>
            <li><a>Pindah Kavling</a></li>
        	<li><a>Ganti Nama</a></li>          
        	<li><a>Perbankan</a></li>
            <li><a>Penerimaan Pembayaran Kwintasi</a></li>
        </ul>
    </li>
    <li><a href='?m=5'>Laporan</a>
    	<ul id='submenu'>
        	<li><a href='?m=8' style='margin-top:0px'>Pelanggan</a></li>
            <li><a href='?m=9'>Angsuran</a></li>
            <li><a href='?m=10'>Kavling</a></li>
        </ul>
    </li>
    <li><a href='proses/system/logout.php'>Keluar</a></li>
</ul>
