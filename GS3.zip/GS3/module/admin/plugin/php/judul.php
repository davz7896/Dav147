<center>
<h1>
	<b>
    <?php
	if($m==1){
    	echo"Selamat Datang Di Aplikasi Milineal Regency<br />";
        echo"$nama_perusahaan";
	}else if($m==2){
		echo"<a class ='link2' href='?m=12'><button class='button' style='vertical-align:middle'><span>Tambah Kavling </span></a>";
	}else if($m==3){
		echo" <a class ='link2' href='?m=18'><button class='button' style='vertical-align:middle'><span>Tambah Customer </span></a>";
	}else if($m==4){
		echo"Angsuran";
	}else if($m==5){
		echo"Laporan";
	}else if($m==6){
		echo"Admin";
	}else if($m==7){
		echo"Perumahan";
	}else if($m==8){
		echo"Laporan Customer";
	}else if($m==9){
		echo"Laporan Angsuran";
	}else if($m==10){
		echo"Laporan Kavling";
	}else if($m==11){
		echo"Edit Perumahan";
	}else if($m==12){
		echo"Tambah Kavling";
	}else if($m==13){
		echo"Edit Kavling";
	}else if($m==14){
		echo"Data Kavling";
	}else if($m==15){
		echo"Perusahaan";
	}else if($m==16){
		echo"Pencarian Kavling";
	}else if($m==17){
		echo"Edit Admin";
	}else if($m==18){
		echo"Tambah Customer";
	}else if($m==19){
		echo"Pembelian Customer";
	}else if($m==20){
		echo"Data Customer";
	}else if($m==21){
		echo"Edit Data Customer";
	}else if($m==22){
		echo"Edit Data Pembelian";
	}else if($m==23){
		echo"Pencarian Customer";
	}else if($m==24){
		echo"Pembayaran Angsuran";
	}else{
	}
	?>     
	</b>
</h1>
</center>
<br /><hr /><br />
