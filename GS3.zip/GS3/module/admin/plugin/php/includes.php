<?php
if($m==1){
	include("module/system/home.php");
}else if($m==2){
	include("module/produk/produk.php");
}else if($m==3){
	include("module/pelanggan/pelanggan.php");
}else if($m==4){
	include("module/angsuran/angsuran.php");
}else if($m==5){
	include("module/laporan/laporan.php");
}else if($m==6){
	include("module/admin/admin.php");
}else if($m==7){
	include("module/produk/merk.php");
}else if($m==8){
	include("module/laporan/laporan_pelanggan.php");
}else if($m==9){
	include("module/laporan/laporan_angsuran.php");
}else if($m==10){
	include("module/laporan/laporan_produk.php");
}else if($m==11){
	include("module/produk/edit_merk.php");
}else if($m==12){
	include("module/produk/add_produk.php");
}else if($m==13){
	include("module/produk/edit_produk.php");
}else if($m==14){
	include("module/produk/view_produk.php");
}else if($m==15){
	include("module/system/perusahaan.php");
}else if($m==16){
	include("module/produk/cari_produk.php");
}else if($m==17){
	include("module/admin/edit_admin.php");
}else if($m==18){
	include("module/pelanggan/add_pelanggan.php");
}else if($m==19){
	include("module/pelanggan/pembelian.php");
}else if($m==20){
	include("module/pelanggan/view_pelanggan.php");
}else if($m==21){
	include("module/pelanggan/edit_data_pelanggan.php");
}else if($m==25){
	include("module/AgenMarketing/index.php");
}else if($m==22){
	include("module/pelanggan/edit_data_pembelian.php");
}else if($m==23){
	include("module/pelanggan/cari_pelanggan.php");
}else if($m==24){
	include("module/angsuran/pembayaran_angsuran.php");
}else{
	include("module/system/404.php");
}
?>