// JavaScript Document

function show_data_notif(){
	url_notif = "ajax/data_notif.php";
	if(window.XMLHttpRequest){
		ajax_notif = new XMLHttpRequest();
	}else{
		ajax_notif = new ActiveXObject("Microsoft.XMLHTTP");
	}
	ajax_notif.onreadystatechange=function(){
		if(ajax_notif.readyState==4 && ajax_notif.status==200){
			kata_notif = ajax_notif.responseText;
			pecah_notif = kata_notif.split("</div>");
			jumlah_notifku = pecah_notif.length;
			hasil_jum_notifku = jumlah_notifku-1;
			
			if(hasil_jum_notifku==0){	
				document.getElementById("notif-list").innerHTML="<div style='margin-top:50px;font-size:15px;font-weight:bold;text-align:center;display:block'>Tidak Ada Pemberitahuan</div>";
			}else{
				document.getElementById("notif-list").innerHTML=ajax_notif.responseText;
			}
		}else{
			document.getElementById("notif-list").innerHTML="<center><img src='asset/image/loading.gif' width='50px' height='50px' style='margin-top:100px'></center>";
		}
	}
	ajax_notif.open("GET",url_notif,true);
	ajax_notif.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_notif.send();
}

function jum_data_notif(){
	url_notif_jum = "ajax/data_notif.php";
	if(window.XMLHttpRequest){
		ajax_notif_jum = new XMLHttpRequest();
	}else{
		ajax_notif_jum = new ActiveXObject("Microsoft.XMLHTTP");
	}
	ajax_notif_jum.onreadystatechange=function(){
		if(ajax_notif_jum.readyState==4 && ajax_notif_jum.status==200){
			kata = ajax_notif_jum.responseText;
			pecah = kata.split("</div>");
			jumlah_notif = pecah.length;
			hasil_jum_notif = jumlah_notif-1;
			document.getElementById("notif-lay").innerHTML="<b style='margin-right:3px'>"+hasil_jum_notif+"</b>";
		}else{
		}
	}
	ajax_notif_jum.open("GET",url_notif_jum,true);
	ajax_notif_jum.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_notif_jum.send();
	setTimeout("jum_data_notif()",5000);
}

function cicilan(){
	url_cil = "ajax/cicilan_produk.php";
	if(window.XMLHttpRequest){
		ajax_cil = new XMLHttpRequest();
	}else{
		ajax_cil = new ActiveXObject("Microsoft.XMLHTTP");
	}
	ajax_cil.onreadystatechange=function(){
		if(ajax_cil.readyState==4 && ajax_cil.status==200){
			document.getElementById("load-ajax-field-cil-produk").innerHTML="";
			data_cicilan = ajax_cil.responseText;
			pecah_cicilan = data_cicilan.split("-");
			document.getElementById("load-ajax-field-cil-produk").innerHTML=pecah_cicilan[0];
			document.getElementById("cicilan-10-produk").value=pecah_cicilan[1];
			document.getElementById("cicilan-16-produk").value=pecah_cicilan[2];
			document.getElementById("cicilan-22-produk").value=pecah_cicilan[3];
			document.getElementById("cicilan-28-produk").value=pecah_cicilan[4];
			document.getElementById("cicilan-34-produk").value=pecah_cicilan[5];
		}else{
			document.getElementById("load-ajax-field-cil-produk").innerHTML="<center><img src='asset/image/loading.gif' width='20px' height='20px' style='margin-top:2px'></center>";
		}
	}
	bunga = document.getElementById("bunga-produk").value
	harga = document.getElementById("harga-produk").value;
	dp = document.getElementById("dp-produk").value;
	ajax_cil.open("POST",url_cil,true);
	ajax_cil.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_cil.send("bunga="+bunga+"&harga="+harga+"&dp="+dp);
}

function validasi_username(username){
	url_username = "ajax/validasi_username_admin.php";
	if(window.XMLHttpRequest){
		ajax_username = new XMLHttpRequest();
	}else{
		ajax_username = new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	ajax_username.onreadystatechange=function(){
		if(ajax_username.readyState==4 && ajax_username.status==200){
			if(ajax_username.responseText=="Kosong"){
				document.getElementById("hasil-script-username").innerHTML="<center><img src='asset/icon/check.png' width='20px' height='20px' style='margin-top:5px'></center>";
				document.getElementById("field-pass-admin").disabled="";
				document.getElementById("field-pass-confirm-admin").disabled="";
				document.getElementById("field-nama-admin").disabled="";
				document.getElementById("field-level-admin").disabled="";
				document.getElementById("button-admin").disabled="";
			}else{
				document.getElementById("hasil-script-username").innerHTML="<center><img src='asset/icon/uncheck.png' width='20px' height='20px' style='margin-top:5px'></center>";
				document.getElementById("field-pass-admin").disabled="disabled";
				document.getElementById("field-pass-confirm-admin").disabled="disabled";
				document.getElementById("field-nama-admin").disabled="disabled";
				document.getElementById("field-level-admin").disabled="disabled";
				document.getElementById("button-admin").disabled="disabled";
			}
		}else{
			document.getElementById("hasil-script-username").innerHTML="<center><img src='asset/image/loading.gif' width='20px' height='20px' style='margin-top:5px'></center>";
		}
	}
	
	ajax_username.open("POST",url_username,true);
	ajax_username.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_username.send("username="+username);
}

function show_produk_buy(kode){
	if(kode==0){
	}else{
	url_produk = "ajax/buy_produk.php";
	if(window.XMLHttpRequest){
		ajax_produk = new XMLHttpRequest();
	}else{
		ajax_produk = new ActiveXObject("Microsoft.XMLHTTP");
	}
	ajax_produk.onreadystatechange=function(){
		if(ajax_produk.readyState==4 && ajax_produk.status==200){
			document.getElementById("load-ajax-field-beli-produk").innerHTML="";
			document.getElementById("pilihan-beli-produk").innerHTML=ajax_produk.responseText;
		}else{
			document.getElementById("load-ajax-field-beli-produk").innerHTML="<center><img src='asset/image/loading.gif' width='20px' height='20px' style='margin-top:4px'></center>";
		}
	}
	ajax_produk.open("POST",url_produk,true);
	ajax_produk.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_produk.send("kode="+kode);
	}
}

function tampilkan_produk_pilihan(kode){
	if(kode==0){
	}else{
	url_pilduk = "ajax/pilihan_produk.php";
	if(window.XMLHttpRequest){
		ajax_pilduk = new XMLHttpRequest();
	}else{
		ajax_pilduk = new ActiveXObject("Microsoft.XMLHTTP");
	}
	ajax_pilduk.onreadystatechange=function(){
		if(ajax_pilduk.readyState==4 && ajax_pilduk.status==200){
			document.getElementById("hasil-data-ajax-field-beli-produk").innerHTML="<div id='tampilan-hasil-pilihan-produk'>"+ajax_pilduk.responseText+"</div>";
		}else{
				document.getElementById("hasil-data-ajax-field-beli-produk").innerHTML="<center><img src='asset/image/loading.gif' width='50px' height='50px' style='margin-top:20px'></center>";
		}
	}
	ajax_pilduk.open("POST",url_pilduk,true);
	ajax_pilduk.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_pilduk.send("kode="+kode);
	}
}

function show_angsuran(kode,urut){
	url_angsuran = "ajax/data_angsuran.php";
	if(window.XMLHttpRequest){
		ajax_angsuran = new XMLHttpRequest();
	}else{
		ajax_angsuran = new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	$("#overlay").show(1000);
	
	ajax_angsuran.onreadystatechange=function(){
		if(ajax_angsuran.readyState==4 && ajax_angsuran.status==200){
			document.getElementById("overlay").innerHTML="<div id='div-overlay-data' style='width:500px'>"+ajax_angsuran.responseText+"</div>";
		}else{
			document.getElementById("overlay").innerHTML="<div style='width:500px;height:100px' id='div-overlay-data'><center><img src='asset/image/loading.gif' width='50px' height='50px' style='margin-top:20px'></center></div>";
		}
	}
	ajax_angsuran.open("POST",url_angsuran,true);
	ajax_angsuran.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_angsuran.send("kode="+kode+"&urut="+urut);
}

function tampil_laporan_pelanggan(){
	
	awal_tgl = document.getElementById("awal-tgl").value;
	awal_bulan = document.getElementById("awal-bulan").value;
	awal_tahun = document.getElementById("awal-tahun").value;
	
	batas_tgl = document.getElementById("batas-tgl").value;
	batas_bulan = document.getElementById("batas-bulan").value;
	batas_tahun = document.getElementById("batas-tahun").value;
	
	url_lap_pelanggan = "ajax/data_laporan_pelanggan.php";
	if(window.XMLHttpRequest){
		ajax_lap_pelanggan = new XMLHttpRequest();
	}else{
		ajax_lap_pelanggan = new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	ajax_lap_pelanggan.onreadystatechange=function(){
		if(ajax_lap_pelanggan.readyState==4 && ajax_lap_pelanggan.status==200){
			document.getElementById("hasil-tampil-laporan-pelanggan").innerHTML=ajax_lap_pelanggan.responseText;
		}else{
			document.getElementById("hasil-tampil-laporan-pelanggan").innerHTML="<center><img src='asset/image/loading.gif' width='50px' height='50px' style='margin-top:50px'></center>";
		}
	}
	ajax_lap_pelanggan.open("POST",url_lap_pelanggan,true);
	ajax_lap_pelanggan.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_lap_pelanggan.send("tgl_mulai="+awal_tgl+"&bulan_mulai="+awal_bulan+"&tahun_mulai="+awal_tahun+"&tgl_batas="+batas_tgl+"&bulan_batas="+batas_bulan+"&tahun_batas="+batas_tahun);
}

function tampil_laporan_angsuran(){
	
	awal_tgl = document.getElementById("awal-tgl").value;
	awal_bulan = document.getElementById("awal-bulan").value;
	awal_tahun = document.getElementById("awal-tahun").value;
	
	batas_tgl = document.getElementById("batas-tgl").value;
	batas_bulan = document.getElementById("batas-bulan").value;
	batas_tahun = document.getElementById("batas-tahun").value;
	
	url_lap_angsuran = "ajax/data_laporan_angsuran.php";
	if(window.XMLHttpRequest){
		ajax_lap_angsuran = new XMLHttpRequest();
	}else{
		ajax_lap_angsuran = new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	ajax_lap_angsuran.onreadystatechange=function(){
		if(ajax_lap_angsuran.readyState==4 && ajax_lap_angsuran.status==200){
			document.getElementById("hasil-tampil-laporan-angsuran").innerHTML=ajax_lap_angsuran.responseText;
		}else{
			document.getElementById("hasil-tampil-laporan-angsuran").innerHTML="<center><img src='asset/image/loading.gif' width='50px' height='50px' style='margin-top:50px'></center>";
		}
	}
	ajax_lap_angsuran.open("POST",url_lap_angsuran,true);
	ajax_lap_angsuran.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_lap_angsuran.send("tgl_mulai="+awal_tgl+"&bulan_mulai="+awal_bulan+"&tahun_mulai="+awal_tahun+"&tgl_batas="+batas_tgl+"&bulan_batas="+batas_bulan+"&tahun_batas="+batas_tahun);
}