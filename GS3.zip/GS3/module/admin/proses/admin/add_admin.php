<title>Redirect...</title>
<?php

include("../../plugin/php/config.php");
include("../../plugin/php/admindata.php");



$username = mysql_real_escape_string($_POST['username_admin']);
$pass = mysql_real_escape_string(md5($_POST['pass_admin']));
$konfirm = mysql_real_escape_string(md5($_POST['konfirm']));
$nama = mysql_real_escape_string(str_replace("'","`",$_POST['nama_admin']));
$no_ktp = mysql_real_escape_string($_POST['no_ktp']);
$agen_marketing = mysql_real_escape_string($_POST['agen_marketing']);
$email = mysql_real_escape_string($_POST['email']);
$telepon = mysql_real_escape_string($_POST['telepon']);
$level = mysql_real_escape_string($_POST['level_admin']);

if(strcmp($pass,"$konfirm")==0){

$rows_admin = mysql_num_rows(mysql_query("select*from t_admin"));
$jum_admin = $rows_admin+1;

$id_admin = "ADM0".$jum_admin;

$sql = mysql_query("insert into t_admin values ('$id_admin','$username','$pass','$nama','$level','1','$no_ktp','$agen_marketing','$email','$telepon')");

	if($sql){
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin Berhasil Di Tambah</div>";
		header("refresh:1; url=../../?m=17&k=$id_admin");
	}else{
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin Gagal Di Tambah</div>";
		header("refresh:1; url=../../?m=6");
	}
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin Gagal Di Tambah</div>";
	header("refresh:1; url=../../?m=6");
}

?>