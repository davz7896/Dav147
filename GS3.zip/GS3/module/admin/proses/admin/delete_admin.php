<title>Redirect...</title>
<?php
session_start();
$admin = $_SESSION['admin'];
include("../../plugin/php/config.php");
include("../../plugin/php/admindata.php");
if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, anda tidak punya hak untuk proses ini</h2></b></center>";
	header("refresh:1; url=../../?m=1");
}else{

$id = mysql_real_escape_string($_GET['id']);

$data = mysql_fetch_array(mysql_query("select*from t_admin where id_admin='$id'"));
$nama = $data['nama_admin'];

$hapus = mysql_query("update t_admin set stat_admin='0' where id_admin='$id'");

if($hapus){
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin $nama Berhasil Di Hapus</div>";
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin $nama Gagal Di Hapus</div>";
}

header("refresh:1; url=../../?m=6");

}
?>