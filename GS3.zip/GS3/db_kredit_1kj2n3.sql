-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2019 at 08:29 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kredit_1kj2n3`
--

-- --------------------------------------------------------

--
-- Table structure for table `agen_marketing`
--

CREATE TABLE `agen_marketing` (
  `kode` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `bank` varchar(50) NOT NULL,
  `no_rek` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `agen_marketing`
--

INSERT INTO `agen_marketing` (`kode`, `nama`, `bank`, `no_rek`) VALUES
('A0001', 'PT.MBB', 'B.BCA', '542784'),
('A0002', 'PT MILINEAL REGENCY', 'BCA', '1313123123');

-- --------------------------------------------------------

--
-- Table structure for table `t_admin`
--

CREATE TABLE `t_admin` (
  `id_admin` varchar(255) NOT NULL,
  `username_admin` varchar(255) NOT NULL,
  `pass_admin` varchar(255) NOT NULL,
  `nama_admin` varchar(255) NOT NULL,
  `level_admin` varchar(10) NOT NULL,
  `stat_admin` int(5) NOT NULL,
  `no_ktp` int(30) DEFAULT NULL,
  `agen_marketing` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `telepon` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_admin`
--

INSERT INTO `t_admin` (`id_admin`, `username_admin`, `pass_admin`, `nama_admin`, `level_admin`, `stat_admin`, `no_ktp`, `agen_marketing`, `email`, `telepon`) VALUES
('ADM01', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Admin', 'admin', 1, NULL, NULL, NULL, NULL),
('ADM010', 'david', 'd41d8cd98f00b204e9800998ecf8427e', 'David', 'user', 1, 2147483647, 'PT.Milineal Regency', 'davidagung80@gmail.com', '083452423413'),
('ADM03', 'Purwo', '27b288e070d7029531dc05dedb22aa78', 'Purwo Hadi', 'user', 1, 2147483647, 'PT.Milineal Regency', 'putnow1809@gmail.com', '083452423413');

-- --------------------------------------------------------

--
-- Table structure for table `t_angsuran`
--

CREATE TABLE `t_angsuran` (
  `kode_angsuran` int(255) NOT NULL,
  `kode_pelanggan` varchar(255) NOT NULL,
  `id_admin` varchar(255) NOT NULL,
  `tgl_angsuran` date NOT NULL,
  `denda_angsuran` int(100) NOT NULL,
  `stat_bayar_angsuran` int(5) NOT NULL,
  `stat_angsuran` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_angsuran`
--

INSERT INTO `t_angsuran` (`kode_angsuran`, `kode_pelanggan`, `id_admin`, `tgl_angsuran`, `denda_angsuran`, `stat_bayar_angsuran`, `stat_angsuran`) VALUES
(31, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(32, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(33, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(34, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(35, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(36, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(37, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(38, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(39, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(40, 'PLGN01', 'ADM01', '2019-04-23', 0, 1, 1),
(41, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1),
(42, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1),
(43, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1),
(44, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1),
(45, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1),
(46, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1),
(47, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1),
(48, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1),
(49, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1),
(50, 'PLGN02', 'ADM01', '2019-04-24', 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `t_merk`
--

CREATE TABLE `t_merk` (
  `kode_merk` varchar(255) NOT NULL,
  `gambar_merk` varchar(255) NOT NULL,
  `nama_merk` varchar(255) NOT NULL,
  `stat_merk` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_merk`
--

INSERT INTO `t_merk` (`kode_merk`, `gambar_merk`, `nama_merk`, `stat_merk`) VALUES
('PRM01', 'PRM01-Grand Land Regency.jpg', 'Grand Land Regency', 1),
('PRM02', 'PRM02-Florencia Regency.jpg', 'Florencya Regency', 1),
('PRM03', 'PRM03-Perumahan1.jpg', 'Milineal Regency', 1);

-- --------------------------------------------------------

--
-- Table structure for table `t_pelanggan`
--

CREATE TABLE `t_pelanggan` (
  `kode_pelanggan` varchar(255) NOT NULL,
  `id_admin` varchar(255) NOT NULL,
  `tgl_pelanggan` date NOT NULL,
  `nama_pelanggan` varchar(255) NOT NULL,
  `telp_pelanggan` varchar(50) NOT NULL,
  `alamat_pelanggan` longtext NOT NULL,
  `no_ktp_pelanggan` varchar(255) NOT NULL,
  `berkas_ktp` varchar(255) NOT NULL,
  `berkas_kk` varchar(255) NOT NULL,
  `berkas_slip` varchar(255) NOT NULL,
  `stat_pelanggan` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_pelanggan`
--

INSERT INTO `t_pelanggan` (`kode_pelanggan`, `id_admin`, `tgl_pelanggan`, `nama_pelanggan`, `telp_pelanggan`, `alamat_pelanggan`, `no_ktp_pelanggan`, `berkas_ktp`, `berkas_kk`, `berkas_slip`, `stat_pelanggan`) VALUES
('PLGN01', 'ADM01', '2019-04-23', 'Dono', '8713616917', 'Jakarta', '132123', 'ktp-PLGN01-img-2.png', 'kosong', 'kosong', 1),
('PLGN02', 'ADM01', '2019-04-24', 'epri', '1231726', 'Blitar', '173261873', 'ktp-PLGN02-img-4.png', 'kosong', 'kosong', 1);

--
-- Triggers `t_pelanggan`
--
DELIMITER $$
CREATE TRIGGER `tambah_pelanggan` AFTER INSERT ON `t_pelanggan` FOR EACH ROW insert into t_pembelian values (new.kode_pelanggan,'','0','0','0','0','0','0','0')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `t_pembelian`
--

CREATE TABLE `t_pembelian` (
  `kode_pelanggan` varchar(255) NOT NULL,
  `kode_produk` varchar(255) NOT NULL,
  `uang_muka_pembelian` double NOT NULL,
  `hasil_cicilan` double NOT NULL,
  `sisa_pembayaran` int(100) NOT NULL,
  `stat_cicilan` int(5) NOT NULL,
  `bayar_terakhir` varchar(100) NOT NULL,
  `batas_bayar` varchar(100) NOT NULL,
  `stat_beli` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_pembelian`
--

INSERT INTO `t_pembelian` (`kode_pelanggan`, `kode_produk`, `uang_muka_pembelian`, `hasil_cicilan`, `sisa_pembayaran`, `stat_cicilan`, `bayar_terakhir`, `batas_bayar`, `stat_beli`) VALUES
('PLGN01', 'KAV01', 1000000000, 100000000, 0, 10, '23-04-2019', '10-3-2020', 1),
('PLGN02', 'KAV03', 1000000000, 500000000, -2147483648, 10, '24-04-2019', '10-3-2020', 1);

-- --------------------------------------------------------

--
-- Table structure for table `t_perusahaan`
--

CREATE TABLE `t_perusahaan` (
  `kode_perusahaan` varchar(255) NOT NULL,
  `nama_perusahaan` varchar(255) NOT NULL,
  `alamat_perusahaan` varchar(255) NOT NULL,
  `telp_perusahaan` varchar(50) NOT NULL,
  `mail_perusahaan` varchar(255) NOT NULL,
  `web_perusahaan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_perusahaan`
--

INSERT INTO `t_perusahaan` (`kode_perusahaan`, `nama_perusahaan`, `alamat_perusahaan`, `telp_perusahaan`, `mail_perusahaan`, `web_perusahaan`) VALUES
('TK001', 'PT. TRIDJAYA KARTIKA GROUP', 'Margorejo', '312512376', 'tridjayakartika@gmail.com', 'tridjayakartika.com');

-- --------------------------------------------------------

--
-- Table structure for table `t_produk`
--

CREATE TABLE `t_produk` (
  `kode_produk` varchar(255) NOT NULL,
  `kode_merk` varchar(255) NOT NULL,
  `gambar_produk` varchar(255) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `stok_produk` int(25) DEFAULT NULL,
  `harga_produk` double NOT NULL,
  `uang_muka_produk` double NOT NULL,
  `bunga_produk` double NOT NULL,
  `desk_produk` longtext NOT NULL,
  `stat_produk` int(5) NOT NULL,
  `l_tanah` int(30) DEFAULT NULL,
  `l_bangunan` int(30) DEFAULT NULL,
  `tipe` varchar(50) DEFAULT NULL,
  `posisi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_produk`
--

INSERT INTO `t_produk` (`kode_produk`, `kode_merk`, `gambar_produk`, `nama_produk`, `stok_produk`, `harga_produk`, `uang_muka_produk`, `bunga_produk`, `desk_produk`, `stat_produk`, `l_tanah`, `l_bangunan`, `tipe`, `posisi`) VALUES
('KAV01', 'PRM02', 'KAV01-Kav001.jpg', '01', 0, 1000000000, 0, 10, 'Rumah Kav 01 siap huni', 1, 150, 160, 'Hawk', 'Tusuk Burung'),
('KAV02', 'PRM01', 'KAV02-Kav002.jpeg', '01', 1, 2000000000, 0, 10, 'Rumah 01 Grand Land Regenct siap huni', 1, 150, 160, 'Busi', 'Di tengah'),
('KAV03', 'PRM03', 'KAV03-Kav003.jpg', '01', 0, 3000000000, 0, 10, 'Rumah KAV01 siap huni didekat sawah', 1, 160, 150, 'Hawk', 'Di Dekat Sawah');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `agen_marketing`
--
ALTER TABLE `agen_marketing`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `t_admin`
--
ALTER TABLE `t_admin`
  ADD PRIMARY KEY (`id_admin`,`username_admin`);

--
-- Indexes for table `t_angsuran`
--
ALTER TABLE `t_angsuran`
  ADD PRIMARY KEY (`kode_angsuran`);

--
-- Indexes for table `t_merk`
--
ALTER TABLE `t_merk`
  ADD PRIMARY KEY (`kode_merk`);

--
-- Indexes for table `t_pelanggan`
--
ALTER TABLE `t_pelanggan`
  ADD PRIMARY KEY (`kode_pelanggan`);

--
-- Indexes for table `t_pembelian`
--
ALTER TABLE `t_pembelian`
  ADD PRIMARY KEY (`kode_pelanggan`,`kode_produk`);

--
-- Indexes for table `t_perusahaan`
--
ALTER TABLE `t_perusahaan`
  ADD PRIMARY KEY (`kode_perusahaan`);

--
-- Indexes for table `t_produk`
--
ALTER TABLE `t_produk`
  ADD PRIMARY KEY (`kode_produk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t_angsuran`
--
ALTER TABLE `t_angsuran`
  MODIFY `kode_angsuran` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
