<?php
session_start();

if(isset($_SESSION['admin'])){
	header("location:system/");
}else{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='system/plugin/css/style.login.css' rel='stylesheet' type='text/css' />
<link href='system/plugin/css/style.1.css' rel='stylesheet' type='text/css' />
<link href='system/plugin/css/bootstrap.min.css' rel='stylesheet' type='text/css' />
<title>Login | Sistem Informasi Kredit Motor</title>
<script src='system/plugin/javascript/ajax.login.js' type='text/javascript'></script>
</head>

<body>
<div class='login-layout'>
<div class='login-form'>
<div id='login-alert'>Form Login</div>
<table cellpadding="5">
<tr>
	<td><label for='username'>Username</label></td>
    <td><input type='text' name='username' id='username' class='input-field' placeholder="Username" autofocus required /></td>
</tr>
<tr>	
	<td><label for='pass'>Password</label></td>
    <td><input type='password' name='pass' id='pass' class='input-field' placeholder="Password" required /></td>
</tr>
<tr>
	<td></td><td><input type='button' style='float:left' value='Masuk' id='button-login-id' onkeypress="login()" onclick="login()" class='button-login'/>
    <div  style='margin:5px 0px 0px 10px;float:left' id='place-of-load-ajax'></div></td>
</tr>
</table>
<div id='form-label'>
<a href="GSLogin/index.php"><p>Belum Punya Akun?</p></a>
</div>
</div>
</div>
</body>
</html>
<?php } ?>