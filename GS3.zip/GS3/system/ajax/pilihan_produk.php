<?php
include("../plugin/php/config.php");

$kode = mysql_real_escape_string($_POST['kode']);
$d_view_produk = mysql_fetch_array(mysql_query("select*from t_produk natural join t_merk where kode_produk='$kode' and stok_produk>0 and stat_produk='1'"));

$kode_merk_e = $d_view_produk['kode_merk'];
$nama_merk = $d_view_produk['nama_merk'];
$gambar_produk = $d_view_produk['gambar_produk'];
$nama_produk = $d_view_produk['nama_produk'];
$stok_produk = $d_view_produk['stok_produk'];
$harga_produk = $d_view_produk['harga_produk'];
$harga_produk_view = "Rp.".number_format($harga_produk,0,',','.');
$dp_produk = $d_view_produk['uang_muka_produk'];
$dp_produk_view = "Rp.".number_format($dp_produk,0,',','.');
$bunga_produk = $d_view_produk['bunga_produk'];
$desk_produk = $d_view_produk['desk_produk'];

echo"
<img src='asset/produk/produk/$gambar_produk' width='150px' height='150px'>
<br><br>
<b>Kavling :</b><br>
$nama_merk <br>
<b>Nama :</b><br>
$nama_produk <br>
<b>Harga :</b><br>
$harga_produk_view <br>
<div id='bunga-pilihan-pembelian' style='display:none'>$bunga_produk</div>
<div id='dp-pilihan-pembelian' style='display:none'>$dp_produk</div>
<div id='harga-pilihan-pembelian' style='display:none'>$harga_produk</div>
";
?>