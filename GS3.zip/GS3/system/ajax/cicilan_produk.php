<?php
include("../plugin/php/config.php");

$bunga = mysql_real_escape_string($_POST['bunga']);
$harga = mysql_real_escape_string($_POST['harga']);
$dp  = mysql_real_escape_string($_POST['dp']);

$hasil_bunga = ($bunga/100) * $harga;
$view_bunga = "Rp.".number_format($hasil_bunga,0,',','.');

$bagi_10 = ( $harga - $dp ) / 10;
$hasil_10 = "Rp.".number_format($bagi_10 + $hasil_bunga,0,',','.');

$bagi_16 = ( $harga - $dp ) / 16;
$hasil_16 = "Rp.".number_format($bagi_16 + $hasil_bunga,0,',','.');
 
$bagi_22 = ( $harga - $dp ) / 22;
$hasil_22 = "Rp.".number_format($bagi_22 + $hasil_bunga,0,',','.');

$bagi_28 = ( $harga - $dp ) / 28;
$hasil_28 = "Rp.".number_format($bagi_28 + $hasil_bunga,0,',','.');

$bagi_34 = ( $harga - $dp ) / 34;
$hasil_34 = "Rp.".number_format($bagi_34 + $hasil_bunga,0,',','.');

echo"$view_bunga-$hasil_10/bln-$hasil_16/bln-$hasil_22/bln-$hasil_28/bln-$hasil_34/bln";
?>