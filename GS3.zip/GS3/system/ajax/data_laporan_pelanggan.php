<?php
session_start();
$admin = $_SESSION['admin'];
include("../plugin/php/config.php");
include("../plugin/php/mydata.php");
include("../plugin/php/admindata.php");

$tgl_mulai = mysql_real_escape_string($_POST['tgl_mulai']);
$bulan_mulai = mysql_real_escape_string($_POST['bulan_mulai']);
$tahun_mulai = mysql_real_escape_string($_POST['tahun_mulai']);

$tgl_batas = mysql_real_escape_string($_POST['tgl_batas']);
$bulan_batas = mysql_real_escape_string($_POST['bulan_batas']);
$tahun_batas = mysql_real_escape_string($_POST['tahun_batas']);

echo"
<div id='div-cetak'>
<div style='border:1px solid #000; padding:10px'>
<div style='text-align:center;line-height:30px'>
<b style='font-size:20px'>Laporan Pelanggan</b><br>
<b>$nama_perusahaan</b> <br>
$alamat_perusahaan<br>
";
if($tgl_mulai==$tgl_batas && $bulan_mulai==$bulan_batas && $tgl_mulai==$tgl_batas){
	echo"Tanggal : $tgl_mulai - $bulan_mulai - $tahun_mulai";
}else{
	echo"Tanggal : $tgl_mulai - $bulan_mulai - $tahun_mulai sampai $tgl_batas - $bulan_batas - $tahun_batas";
}
echo"
</div>
<hr>
";

if(strcmp($data_level_admin,"admin")==0){
?>
<table cellpadding="5" cellspacing="0" border='1' align="center" width="100%">
<tr>
	<th>No</th><th>Nama</th><th>Alamat</th><th>Perumahan/Kavling</th><th>Pegawai</th><th>Tanggal</th>
</tr>
<?php
$query_report_plgn = mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk natural join t_admin where tgl_pelanggan between '$tahun_mulai-$bulan_mulai-$tgl_mulai' and '$tahun_batas-$bulan_batas-$tgl_batas' and stat_pelanggan='1' and stat_beli='1' order by tgl_pelanggan");

$rp=0;
while($data_report_plgn = mysql_fetch_array($query_report_plgn)){
	$rp++;
	$nama_plgn = $data_report_plgn['nama_pelanggan'];
	$alamat_plgn = $data_report_plgn['alamat_pelanggan'];
	$merk_plgn = $data_report_plgn['nama_merk'];
	$produk_plgn = $data_report_plgn['nama_produk'];
	$admin_plgn = $data_report_plgn['nama_admin'];
	$tanggal_plgn = $data_report_plgn['tgl_pelanggan'];
	$plode_tanggal = explode("-",$tanggal_plgn);
	$tgl_plgn = $plode_tanggal[2];
	$bulan_plgn = $plode_tanggal[1];
	$tahun_plgn = $plode_tanggal[0];
	echo"
	<tr>
		<td align='right'>$rp</td>
		<td>$nama_plgn</td>
		<td>$alamat_plgn</td>
		<td>$merk_plgn $produk_plgn</td>
		<td>$admin_plgn</td>
		<td align='right'>$tgl_plgn - $bulan_plgn - $tahun_plgn</td>
	</tr>
	";
}
?>
</table>
<?php
}else{
?>
<table cellpadding="5" cellspacing="0" border='1' align="center" width="100%">
<tr>
	<th>No</th><th>Nama</th><th>Alamat</th><th>Produk</th><th>Tanggal</th>
</tr>
<?php
$query_report_plgn = mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk natural join t_admin where tgl_pelanggan between '$tahun_mulai-$bulan_mulai-$tgl_mulai' and '$tahun_batas-$bulan_batas-$tgl_batas' and stat_pelanggan='1' and stat_beli='1' and id_admin='$admin' order by tgl_pelanggan");
$rp=0;
while($data_report_plgn = mysql_fetch_array($query_report_plgn)){
	$rp++;
	$nama_plgn = $data_report_plgn['nama_pelanggan'];
	$alamat_plgn = $data_report_plgn['alamat_pelanggan'];
	$merk_plgn = $data_report_plgn['nama_merk'];
	$produk_plgn = $data_report_plgn['nama_produk'];
	$tanggal_plgn = $data_report_plgn['tgl_pelanggan'];
	$plode_tanggal = explode("-",$tanggal_plgn);
	$tgl_plgn = $plode_tanggal[2];
	$bulan_plgn = $plode_tanggal[1];
	$tahun_plgn = $plode_tanggal[0];
	echo"
	<tr>
		<td align='right'>$rp</td>
		<td>$nama_plgn</td>
		<td>$alamat_plgn</td>
		<td>$merk_plgn $produk_plgn</td>
		<td align='right'>$tgl_plgn - $bulan_plgn - $tahun_plgn</td>
	</tr>
	";
}
?>
</table>

<?php } ?>
</div></div>
<br /><div class='clr'></div><br />
<center><a class='no-print' href="javascript:printDiv('div-cetak');"><input type='button' value='Cetak' class='button-class'/></a></center>