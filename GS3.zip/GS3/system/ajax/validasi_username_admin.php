<?php
include("../plugin/php/config.php");

$username = mysql_real_escape_string($_POST['username']);

$rows_username = mysql_num_rows(mysql_query("select*from t_admin where username_admin='$username'"));

if($rows_username==0){
	echo"Kosong";
}else{
	echo"Ada";
}
?>