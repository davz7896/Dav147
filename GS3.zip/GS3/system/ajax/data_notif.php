<?php
include("../plugin/php/config.php");
?>
<?php
$tanggal = date("d");
$bulan = date("m");
$tahun = date("Y");

$q_data_plgn_notif = mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk where stat_pelanggan='1' and stat_beli='1' and bayar_terakhir!=0 order by nama_pelanggan");
while($d_data_plgn_notif = mysql_fetch_array($q_data_plgn_notif)){
	$kode_plgn = $d_data_plgn_notif['kode_pelanggan'];
	$nama_plgn = $d_data_plgn_notif['nama_pelanggan'];
	$produk_plgn = $d_data_plgn_notif['nama_produk'];
	$merk_plgn = $d_data_plgn_notif['nama_merk'];
		
	$batas_terakhir = $d_data_plgn_notif['batas_bayar'];
	$plode_batas_akhir = explode("-",$batas_terakhir);
	$tgl_akhir_batas = $plode_batas_akhir[0];
	$bulan_akhir_batas = $plode_batas_akhir[1];
	$th_akhir_batas = $plode_batas_akhir[2];
	
	$bayar_terakhir = $d_data_plgn_notif['bayar_terakhir'];
	$plode_bayar_akhir = explode("-",$bayar_terakhir);
	$tgl_akhir_bayar = $plode_bayar_akhir[0];
	$bulan_akhir_bayar = $plode_bayar_akhir[1];
	$th_akhir_bayar = $plode_bayar_akhir[2];
	
	if($tahun==$th_akhir_batas && $bulan==$bulan_akhir_batas){
		if(($tgl_akhir_batas-$tanggal)==3){
			echo"
			<div id='div-notif' onclick='direct_page(\"?m=20&k=$kode_plgn\")' style='background:#FF6;border:1px solid #FC3;'>
			<b>$nama_plgn</b> hampir mendekati tanggal angsuran
			</div>
			";
		}else if(($tgl_akhir_batas-$tanggal)==2){
			echo"
			<div id='div-notif' onclick='direct_page(\"?m=20&k=$kode_plgn\")' style='background:#FF6;border:1px solid #FC3;'>
			<b>$nama_plgn</b> hampir mendekati tanggal angsuran
			</div>
			";
		}else if(($tgl_akhir_batas-$tanggal)==1){
			echo"
			<div id='div-notif' onclick='direct_page(\"?m=20&k=$kode_plgn\")' style='background:#FF6;border:1px solid #FC3;'>
			<b>$nama_plgn</b> hampir mendekati tanggal angsuran
			</div>
			";
		}else if($tgl_akhir_batas==$tanggal){
			echo"
			<div id='div-notif' onclick='direct_page(\"?m=20&k=$kode_plgn\")' style='background:#F66;border:1px solid #900;'>
			<b>$nama_plgn</b> sudah masuk tanggal angsuran
			</div>
			";
		}
	}else{
	}
}
?>
<?php
$q_produk_notif = mysql_query("select*from t_produk natural left join t_merk where stat_produk='1'");
while($d_notif_produk = mysql_fetch_array($q_produk_notif)){
	$kode_prdk = $d_notif_produk['kode_produk'];
	$stok_prdk = $d_notif_produk['stok_produk'];
	$nama_prdk = $d_notif_produk['nama_produk'];
	$merk_prdk = $d_notif_produk['nama_merk'];
	
	if($stok_prdk>3){
	}else{
	if($stok_prdk==3){
		echo"
			<div id='div-notif' onclick='direct_page(\"?m=13&k=$kode_prdk\")' style='background:#FF6;border:1px solid #FC3'>
			<b>$merk_prdk $nama_prdk</b> hampir habis stok
			</div>
		";
	}else if($stok_prdk==2){
		echo"
			<div id='div-notif' onclick='direct_page(\"?m=13&k=$kode_prdk\")' style='background:#FF6;border:1px solid #FC3'>
			<b>$merk_prdk $nama_prdk</b> hampir habis stok
			</div>
		";
	}else if($stok_prdk==1){
		echo"
			<div id='div-notif' onclick='direct_page(\"?m=13&k=$kode_prdk\")' style='background:#FF6;border:1px solid #FC3'>
			<b>$merk_prdk $nama_prdk</b> hampir habis stok
			</div>
		";
	}else if($stok_prdk==0){
		echo"
			<div id='div-notif' onclick='direct_page(\"?m=13&k=$kode_prdk\")' style='background:#F66;border:1px solid #900'>
			<b>$merk_prdk $nama_prdk</b> habis stok
			</div>
		";
	}
	}
}
?>