<?php
include("../plugin/php/config.php");

echo"<option value='0'>-- Pilih Produk --</option>";

$kode_pilih = mysql_real_escape_string($_POST['kode']);

$q_pilih_produk = mysql_query("select*from t_produk where kode_merk='$kode_pilih' and stat_produk='1' and stok_produk>0");

while($d_pilih_produk = mysql_fetch_array($q_pilih_produk)){
	$kode_pilih_produk = $d_pilih_produk['kode_produk'];
	$nama_pilih_produk = $d_pilih_produk['nama_produk'];
	echo"<option value='$kode_pilih_produk'>$nama_pilih_produk</option>";
}
?>