<?php
include("../plugin/php/config.php");
include("../plugin/php/mydata.php");

$kode = mysql_real_escape_string($_POST['kode']);
$urut = mysql_real_escape_string($_POST['urut']);

$data = mysql_fetch_array(mysql_query("select*from t_angsuran natural join t_pelanggan natural join t_produk natural join t_merk where kode_angsuran='$kode' and stat_angsuran='1'"));

$kode_plgn = $data['kode_pelanggan'];
$nama = $data['nama_pelanggan'];
$produk = $data['nama_produk'];
$merk = $data['nama_merk'];
$denda_ags_view = "Rp.".number_format($data['denda_angsuran'],0,",",".");
$tanggal_ags = $data['tgl_angsuran'];
$plode_tanggal_ags = explode("-",$tanggal_ags);
$tgl_ags = $plode_tanggal_ags[2];
$bulan_ags = $plode_tanggal_ags[1];
$th_ags = $plode_tanggal_ags[0];

echo"
<div id='div-cetak'>
<div id='print-data-angsuran' style='border:1px solid #000;padding:10px'>
<center>
<b>
Bukti Pembayaran Angsuran <br>
$nama_perusahaan
</b>
</center>
<hr>
<table cellpadding='5' width='100%'>
<tr>
	<td>Angsuran ke</td>
	<td>:</td>
	<td>$urut</td>
</tr>
<tr>
	<td width='150px'>Kode Pelanggan</td>
	<td>:</td>
	<td>$kode_plgn</td>
</tr>
<tr>
	<td>Nama Pelanggan</td>
	<td>:</td>
	<td>$nama</td>
</tr>
<tr>
	<td>Produk</td>
	<td>:</td>
	<td>$merk $produk</td>
</tr>
<tr>
	<td>Denda</td>
	<td>:</td>
	<td>$denda_ags_view</td>
</tr>
<tr>
	<td colspan='3' align='right'>Cirebon, $tgl_ags-$bulan_ags-$th_ags</td>
</tr>
<tr>
	<td></td><td></td><td>
	<a class='no-print' href=\"javascript:printDiv('div-cetak');\"><input type='button' value='Cetak' class='button-class'/></a>
<a class='no-print'><input type='button' class='button-class' value='Keluar' onclick='outlay()'></div>
</td>
</tr>
</table>
</div>
</div>
";
?>