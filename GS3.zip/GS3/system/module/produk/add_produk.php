<?php
if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, anda tidak punya hak untuk halaman ini</h2></b></center>";
}else{

$rows_produk = mysql_num_rows(mysql_query("select*from t_produk"));
$jum_produk = $rows_produk + 1;
$kode_produk = "KAV"."0"."$jum_produk";

?>
<form method="post" action="proses/produk/add_produk.php" enctype="multipart/form-data">
<table cellpadding="5">
<tr>
    <td>
    	<label>Masukan Nama Perumahan</label>
    </td>
    <td>
        <select name='merk' class='inp-pad'>
        	<?php
			$q_mert = mysql_query("select*from t_merk where stat_merk='1' order by nama_merk");
			while($d_mert = mysql_fetch_array($q_mert)){
				$kode_mert = $d_mert['kode_merk'];
				$nama_mert = $d_mert['nama_merk'];
				echo"<option value='$kode_mert'>$nama_mert</option>";
			}
			?>
        </select>
    </td>
</tr>
<tr>
	<td>
    	<label>Kode</label>
    </td>
    <td>
    	<input type='text' name='kode' <?php echo"value='$kode_produk'"; ?> class='input-field' readonly id='kode-produk'>
    </td>
</tr>
<tr>
	<td><label for='img-produk'>Gambar</label></td>
    <td><input type='file' name='gambar' required id='img-produk' /></td>
</tr>
<tr>
	<td><label for='nama-produk'>No Kavling</label></td>
    <td><input type='text' name='nama' class='input-field' required id='nama-produk' placeholder="Masukan No Kavling" /></td>
</tr>
<tr>
	<td><label for='nama-produk'>Luas Tanah</label></td>
    <td><input type='text' name='l_tanah' class='input-field' required id='nama-produk' placeholder="Masukan Luas Tanah" /></td>
</tr>
<tr>
	<td><label for='nama-produk'>Luas Bangunan</label></td>
    <td><input type='text' name='l_bangunan' class='input-field' required id='nama-produk' placeholder="Masukan Luas Bangunan "/></td>
</tr>
<tr>
	<td><label for='nama-produk'>Tipe</label></td>
    <td><input type='text' name='tipe' class='input-field' required id='nama-produk' placeholder="Masukan Tipe" /></td>
</tr>
<tr>
	<td><label for='nama-produk'>Posisi</label></td>
    <td><input type='text' name='posisi' class='input-field' required id='nama-produk' placeholder="Masukan Posisi" /></td>
</tr>
	<td><label for='harga-produk'>Harga</label></td>
    <td>
    <input type='number' name='harga' placeholder="Harga" onkeyup="money_produk()" class='input-field' required id='harga-produk' style='width:150px;text-align:right;float:left' />
    <div id='view-ajax-field-harga-produk' style='float:left;margin-top:3px;margin-left:10px;height:25px'>Rp.0</div>
    </td>
</tr>
<tr>
	<td><label for='bunga-produk'>Bunga ( % )</label></td>
    <td>
    <input type='number' name='bunga' onchange="" placeholder="PPN( % )" class='input-field' required id='bunga-produk' style='width:150px;float:left;text-align:right' />
    <div id='load-ajax-field-cil-produk' style='float:left;margin-top:3px;margin-left:10px;height:25px'></div>
    </td>
</tr>
<tr>
	<td valign="top"><label for='desk-produk'>Deskripsi</label></td>
    <td>
    	<textarea name='desk' class='input-field' required id='desk-produk' placeholder="Deskripsi" style='width:450px; height:150px'></textarea>
    </td>
</tr>
<tr>
	<td></td><td><input type='submit' value='Tambah' class='button-class' /></td>
</tr>
</table>
</form>
<br /><hr /><br />
<?php } ?>