<?php
if(!strcmp($data_level_admin,"admin")==0){
?>
<table class='table-data' width='100%' align="center" cellpadding="10" cellspacing="0" border='0'>
<tr class='table-data-header'>
	<th id='table-data-header-left'>No</th><th>Gambar</th><th>Nama</th><th></th><th id='table-data-header-right'></th>
</tr>
<?php
$q_merk = mysql_query("select*from t_merk where stat_merk='1' order by nama_merk");
$m=0;
while($d_merk = mysql_fetch_array($q_merk)){
	$m++;
	$img_merk = $d_merk['gambar_merk'];
	$kode_merk = $d_merk['kode_merk'];
	$nama_merk = $d_merk['nama_merk'];
	echo"
	<tr>
		<td valign='middle' align='center'>$m</td>
		<td valign='middle' align='center'><img src='asset/produk/merk/$img_merk' width='50px' height='50px'></td>
		<td valign='middle' align='center'>$nama_merk</td>
		<td valign='middle' align='center' id='td-data-aksi-green'>
			<a href='?m=11&k=$kode_merk' style='display:block'><img src='asset/icon/edit.png' width='25px' height='25px'></a>
		</td>
		<td valign='middle' align='center' id='td-data-aksi-red'>
			<a href='proses/produk/delete_merk.php?id=$kode_merk' onclick='return confirm (\"Hapus Merk $nama_merk\")' style='display:block'><img src='asset/icon/delete.png' width='25px' height='25px'></a>
		</td>
	</tr>
	";
}
?>
<tr>
	<tr><th class='table-data-footer' colspan="5"></th></tr>
</tr>
</table>

<?php
}else{
?>
<?php
$rows_add_merk = mysql_num_rows(mysql_query("select*from t_merk"));
$kode_add_merk = $rows_add_merk + 1;
?>
<form method="post" action="proses/produk/add_merk.php" enctype="multipart/form-data">
<table cellpadding="5">
<tr>
	<td><label for='kd-add-merk'>Kode</label></td>
    <td><input type='text' name='kode' class='input-field' id='kd-add-merk' readonly <?php echo"value='PRM0$kode_add_merk'"; ?> style='width:200px' /></td>
</tr>
<tr>
	<td><label for='img-add-merk'>Gambar</label></td>
    <td><input type='file' name='gambar' required id='img-add-merk' /></td>
</tr>
<tr>
	<td><label for='nama-add-merk'>Nama</label></td>
    <td><input type='text' name='nama' class='input-field' required id='nama-add-merk' placeholder="Nama Perumahan" /></td>
</tr>
<tr>
	<td></td><td><input type='submit' value='Tambah' class='button-class' /></td>
</tr>
</table>
</form>
<br /><hr /><br />
<table class='table-data' width='100%' align="center" cellpadding="10" cellspacing="0" border='0'>
<tr class='table-data-header'>
	<th id='table-data-header-left'>No</th><th>Gambar</th><th>Nama</th><th></th><th id='table-data-header-right'></th>
</tr>
<?php
$q_merk = mysql_query("select*from t_merk where stat_merk='1' order by nama_merk");
$m=0;
while($d_merk = mysql_fetch_array($q_merk)){
	$m++;
	$img_merk = $d_merk['gambar_merk'];
	$kode_merk = $d_merk['kode_merk'];
	$nama_merk = $d_merk['nama_merk'];
	echo"
	<tr>
		<td valign='middle' align='center'>$m</td>
		<td valign='middle' align='center'><img src='asset/produk/merk/$img_merk' width='50px' height='50px'></td>
		<td valign='middle' align='center'>$nama_merk</td>
		<td valign='middle' align='center' id='td-data-aksi-green'>
			<a href='?m=11&k=$kode_merk' style='display:block'><img src='asset/icon/edit.png' width='25px' height='25px'></a>
		</td>
		<td valign='middle' align='center' id='td-data-aksi-red'>
			<a href='proses/produk/delete_merk.php?id=$kode_merk' onclick='return confirm (\"Hapus Merk $nama_merk\")' style='display:block'><img src='asset/icon/delete.png' width='25px' height='25px'></a>
		</td>
	</tr>
	";
}
?>
<tr>
	<tr><th class='table-data-footer' colspan="5"></th></tr>
</tr>
</table>

<?php } ?>