<?php
if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, anda tidak punya hak untuk halaman ini</h2></b></center>";
}else{
	
$rows_edit_produk = mysql_num_rows(mysql_query("select*from t_produk where kode_produk='$k' and stat_produk='1'"));
if($rows_edit_produk==0){
	header("location:?m=404");
}else{

$d_edit_produk = mysql_fetch_array(mysql_query("select*from t_produk where kode_produk='$k'"));

$kode_merk_e = $d_edit_produk['kode_merk'];
$gambar_produk = $d_edit_produk['gambar_produk'];
$nama_produk = $d_edit_produk['nama_produk'];
$stok_produk = $d_edit_produk['stok_produk'];
$l_tanah = $d_edit_produk['l_tanah'];
$l_bangunan = $d_edit_produk['l_bangunan'];
$tipe = $d_edit_produk['tipe'];
$posisi = $d_edit_produk['posisi'];
$harga_produk = $d_edit_produk['harga_produk'];
$harga_produk_view = "Rp.".number_format($harga_produk,0,',','.');
$dp_produk = $d_edit_produk['uang_muka_produk'];
$dp_produk_view = "Rp.".number_format($dp_produk,0,',','.');
$bunga_produk = $d_edit_produk['bunga_produk'];
$desk_produk = $d_edit_produk['desk_produk'];

$hasil_bunga = ($bunga_produk/100) * $harga_produk;
$view_bunga = "Rp.".number_format($hasil_bunga,0,',','.');

$bagi_10 = ( $harga_produk - $dp_produk ) / 10;
$hasil_10 = "Rp.".number_format($bagi_10 + $hasil_bunga,0,',','.');

$bagi_16 = ( $harga_produk - $dp_produk ) / 16;
$hasil_16 = "Rp.".number_format($bagi_16 + $hasil_bunga,0,',','.');
 
$bagi_22 = ( $harga_produk - $dp_produk ) / 22;
$hasil_22 = "Rp.".number_format($bagi_22 + $hasil_bunga,0,',','.');

$bagi_28 = ( $harga_produk - $dp_produk ) / 28;
$hasil_28 = "Rp.".number_format($bagi_28 + $hasil_bunga,0,',','.');

$bagi_34 = ( $harga_produk - $dp_produk ) / 34;
$hasil_34 = "Rp.".number_format($bagi_34 + $hasil_bunga,0,',','.');

?>
<form method="post" action="proses/produk/edit_produk.php" enctype="multipart/form-data">
<?php echo"<img src='asset/produk/produk/$gambar_produk' width='100px' height='100px'><br><br>"; ?>
<table cellpadding="5">
<tr>
    <td>
    	<label>Merk</label>
    </td>
    <td>
        <select name='merk' class='inp-pad'>
        	<?php
			$q_mert = mysql_query("select*from t_merk where stat_merk='1' order by nama_merk");
			while($d_mert = mysql_fetch_array($q_mert)){
				$kode_mert = $d_mert['kode_merk'];
				$nama_mert = $d_mert['nama_merk'];
				
				if(strcmp($kode_merk_e,"$kode_mert")==0){
					$sem = "selected";
				}else{
					$sem = "";
				}
				
				echo"<option value='$kode_mert' $sem>$nama_mert</option>";
			}
			?>
        </select>
    </td>
</tr>
<tr>
	<td>
    	<label>Kode</label>
    </td>
    <td>
    	<input type='text' name='kode' <?php echo"value='$k'"; ?> class='input-field' readonly id='kode-produk'>
    </td>
</tr>
<tr>
	<td><label for='cimage'>Gambar</label><input type='checkbox' name='vimage' value='1' id='cimage' /></td>
    <td><input type='file' name='gambar' id='img-produk' /></td>
</tr>
<tr>
	<td><label for='nama-produk'>Nama</label></td>
    <td><input type='text' name='nama' class='input-field' required id='nama-produk' <?php echo"value='$nama_produk'"; ?> /></td>
</tr>	

<tr>
	<td><label for='nama-produk'>Luas Tanah</label></td>
    <td><input type='text' name='l_tanah' class='input-field' required id='nama-produk' <?php echo"value='$l_tanah'"; ?> /></td>
</tr>
<tr>
	<td><label for='nama-produk'>Luas Bangunan</label></td>
    <td><input type='text' name='l_bangunan' class='input-field' required id='nama-produk' <?php echo"value='$l_bangunan'"; ?> /></td>
</tr>
<tr>
	<td><label for='nama-produk'>Tipe</label></td>
    <td><input type='text' name='tipe' class='input-field' required id='nama-produk' <?php echo"value='$tipe'"; ?> /></td>
</tr>
<tr>
	<td><label for='nama-produk'>Posisi</label></td>
    <td><input type='text' name='posisi' class='input-field' required id='nama-produk' <?php echo"value='$posisi'"; ?> /></td>
</tr>

	<td><label for='harga-produk'>Harga</label></td>
    <td>
    <input type='number' name='harga' <?php echo"value='$harga_produk'"; ?> onkeyup="money_produk()" class='input-field' required id='harga-produk' style='width:150px;text-align:right;float:left' />
    <div id='view-ajax-field-harga-produk' style='float:left;margin-top:3px;margin-left:10px;height:25px'><?php echo"$harga_produk_view"; ?></div>
    </td>
</tr>
<tr>
	<td><label for='bunga-produk'>Bunga Cicilan ( % )</label></td>
    <td>
    <input type='number' name='bunga' onchange="cicilan()" <?php echo"value='$bunga_produk'"; ?> class='input-field' required id='bunga-produk' style='width:150px;float:left;text-align:right' />
    <div id='load-ajax-field-cil-produk' style='float:left;margin-top:3px;margin-left:10px;height:25px'><?php echo"$view_bunga"; ?></div>
    </td>
</tr>
<tr>
	<td valign="top"><label for='desk-produk'>Deskripsi</label></td>
    <td>
    	<textarea name='desk' class='input-field' required id='desk-produk' placeholder="Deskripsi" style='width:450px; height:150px'><?php echo"$desk_produk"; ?></textarea>
    </td>
</tr>
<tr>
	<td></td><td><input type='submit' value='Simpan' class='button-class' /></td>
</tr>
</table>
</form>
<br /><hr /><br />
<?php } } ?>