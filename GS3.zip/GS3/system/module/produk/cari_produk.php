<?php
$cari = str_replace("'","`",$_POST['cari']);
$jum_produk = mysql_num_rows(mysql_query("select*from t_produk where nama_produk like ('%$cari%') and stat_produk='1'"));
if($jum_produk==0){
?>
<form method="post" action="?m=16" style='float:right; height:50px; line-height:30px; margin-right:30px'>
<input type='text' name='cari' class='input-field' placeholder="Pencarian Nama Produk" required />
<input type='submit' value='Cari' class='button-class' />
</form>
<div class='clr'></div>
<hr />
<?php
	echo"<br><br><center><b><h2>Maaf, Pencarian $cari Kosong</h2></b></center>";
}else{
?>
<form method="post" action="?m=16" style='float:right; height:50px; line-height:30px; margin-right:30px'>
<input type='text' name='cari' class='input-field' placeholder="Pencarian Nama Produk" required />
<input type='submit' value='Cari' class='button-class' />
</form>
<div class='clr'></div>
<hr />
<?php
	echo"<b><h2>Pencarian $cari : $jum_produk</h2></b>";
?>
<table class='table-data' width='100%' align="center" cellpadding="10" cellspacing="0" border='0'>
<tr class='table-data-header'>
	<th id='table-data-header-left'>No</th><th>Nama</th><th>Stok</th><th>Harga</th><th></th><th id='table-data-header-right'></th>
</tr>
<?php
$produk=0;
$q_produk = mysql_query("select*from t_produk natural join t_merk where nama_produk like ('%$cari%') and stat_produk='1' order by nama_merk,nama_produk");
while($d_produk = mysql_fetch_array($q_produk)){
	$produk++;
	$nama_merk = $d_produk['nama_merk'];
	$kode_produk = $d_produk['kode_produk'];
	$nama_produk = $d_produk['nama_produk'];
	$stok_produk = $d_produk['stok_produk'];
	$harga_produk = "Rp.".number_format($d_produk['harga_produk'],0,',','.');
	echo"
	<tr>
		<td valign='middle' align='center'>$produk</td>
		<td valign='middle' align='center'><a href='?m=14&k=$kode_produk'>$nama_merk<br>$nama_produk</a></td>
		<td valign='middle' align='center'>$stok_produk</td>
		<td valign='middle' align='center'>$harga_produk</td>
		<td valign='middle' align='center' id='td-data-aksi-green'><a href='?m=13&k=$kode_produk' style='display:block'><img src='asset/icon/edit.png' width='25px' height='25px'></a></td>
		<td valign='middle' align='center' id='td-data-aksi-red'><a href='proses/produk/delete_produk.php?id=$kode_produk' onclick='return confirm (\"Hapus Produk $nama_merk $nama_produk\")' style='display:block'><img src='asset/icon/delete.png' width='25px' height='25px'></a></td>
	</tr>
	";
}
?>
<tr>
	<tr><th class='table-data-footer' colspan="6"></th></tr>
</tr>
</table>
<?php } ?>