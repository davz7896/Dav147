<?php
$jum_produk = mysql_num_rows(mysql_query("select*from t_produk where stat_produk='1'"));
$jum_hal = ceil($jum_produk / 10);
if($p==1){
	$limit = 0;
}else{
	$limit = ( $p * 10 ) - 10;
}
?>
<form method="post" action="?m=16" style='float:right; height:50px; line-height:30px; margin-right:30px'>
<input type='text' name='cari' class='input-field' placeholder="Pencarian Nama Produk" required />
<input type='submit' value='Cari' class='button-class' />
</form>
<div class='clr'></div>
<hr /><br />
<table class='table-data' width='100%' align="center" cellpadding="10" cellspacing="0" border='0'>
<tr class='table-data-header'>
	<th id='table-data-header-left'>No</th><th>Nama</th><th>Stok</th><th>Harga</th><th></th><th id='table-data-header-right'></th>
</tr>
<?php
$produk=$limit;
$q_produk = mysql_query("select*from t_produk natural join t_merk where stat_produk='1' order by nama_merk,nama_produk limit $limit,10");
while($d_produk = mysql_fetch_array($q_produk)){
	$produk++;
	$nama_merk = $d_produk['nama_merk'];
	$kode_produk = $d_produk['kode_produk'];
	$nama_produk = $d_produk['nama_produk'];
	$stok_produk = $d_produk['stok_produk'];
	$harga_produk = "Rp.".number_format($d_produk['harga_produk'],0,',','.');
	echo"
	<tr>
		<td valign='middle' align='center'>$produk</td>
		<td valign='middle' align='center'><a href='?m=14&k=$kode_produk'>$nama_merk<br>$nama_produk</a></td>
		<td valign='middle' align='center'>$stok_produk</td>
		<td valign='middle' align='center'>$harga_produk</td>
		<td valign='middle' align='center' id='td-data-aksi-green'><a href='?m=13&k=$kode_produk' style='display:block'><img src='asset/icon/edit.png' width='25px' height='25px'></a></td>
		<td valign='middle' id='td-data-aksi-red' align='center'><a href='proses/produk/delete_produk.php?id=$kode_produk' onclick='return confirm (\"Hapus Produk $nama_merk $nama_produk\")' style='display:block'><img src='asset/icon/delete.png' width='25px' height='25px'></a></td>
	</tr>
	";
}
?>
<tr>
	<tr><th class='table-data-footer' colspan="6"></th></tr>
</tr>
</table>
<br /><div class='clr'></div><br />
<div id='paging-left'>
<b>Halaman : </b>
<select class='inp-pad' onchange="direct_page(this.value)">
<?php
for($h=1;$h<=$jum_hal;$h++){
	if($h==$p){
		echo"<option value='?m=$m&p=$h' selected>$h</option>";
	}else{
		echo"<option value='?m=$m&p=$h'>$h</option>";
	}
}
?>
</select>
</div>
<div id='paging-right'>
<?php
if($jum_hal<=1){
}else if($p==$jum_hal){
	$min_p = $p - 1;
	echo"<a href='?m=$m&p=$min_p' id='prev-paging'><img src='asset/icon/prev.png' /></a>";
}else if($p==1){
	$plus_p = $p + 1;
	echo"<a href='?m=$m&p=$plus_p' id='next-paging'><img src='asset/icon/next.png' /></a>";
}else{
	$plus_p = $p + 1;
	$min_p = $p - 1;
	echo"<a href='?m=$m&p=$min_p' id='prev-paging'><img src='asset/icon/prev.png' /></a>";
	echo"<a href='?m=$m&p=$plus_p' id='next-paging'><img src='asset/icon/next.png' /></a>";
}
?>
</div>
<div class='clr'></div>