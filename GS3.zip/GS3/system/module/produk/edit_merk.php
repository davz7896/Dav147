<?php
if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, anda tidak punya hak untuk halaman ini</h2></b></center>";
}else{
?>
<?php
$rows_edit_merk = mysql_num_rows(mysql_query("select*from t_merk where kode_merk='$k' and stat_merk='1'"));
if($rows_edit_merk==0){
	header("location:?m=404");
}else{
$q_edit_merk = mysql_query("select*from t_merk where kode_merk='$k'");
$d_edit_merk = mysql_fetch_array($q_edit_merk);

$img_edit_merk = $d_edit_merk['gambar_merk'];
$nama_merk = $d_edit_merk['nama_merk'];
?>
<form method="post" action="proses/produk/edit_merk.php" enctype="multipart/form-data">
<?php echo"<img src='asset/produk/merk/$img_edit_merk' width='100px' height='100px'> <br><div class='clr'></div><br>"; ?>
<table cellpadding="5">
<tr>
	<td><label for='kd-add-merk'>Kode</label></td>
    <td><input type='text' name='kode' class='input-field' id='kd-add-merk' readonly <?php echo"value='$k'"; ?> style='width:200px' /></td>
</tr>
<tr>
	<td><label for='cimage'>Gambar</label><input type='checkbox' name='vimage' value='1' id='cimage' /></td>
    <td><input type='file' name='gambar' /></td>
</tr>
<tr>
	<td><label for='nama-add-merk'>Nama</label></td>
    <td><input type='text' name='nama' class='input-field' required id='nama-add-merk' <?php echo"value='$nama_merk'"; ?> /></td>
</tr>
<tr>
	<td></td><td><input type='submit' value='Simpan' class='button-class' /></td>
</tr>
</table>
</form>
<br /><hr /><br />
<table class='table-data' width='100%' align="center" cellpadding="10" cellspacing="0" border='0'>
<tr class='table-data-header'>
	<th id='table-data-header-left'>No</th><th>Gambar</th><th>Nama</th><th></th><th id='table-data-header-right'></th>
</tr>
<?php
$q_merk = mysql_query("select*from t_merk where stat_merk='1' order by nama_merk");
$m=0;
while($d_merk = mysql_fetch_array($q_merk)){
	$m++;
	$img_merk = $d_merk['gambar_merk'];
	$kode_merk = $d_merk['kode_merk'];
	$nama_merk = $d_merk['nama_merk'];
	echo"
	<tr>
		<td valign='middle' align='center'>$m</td>
		<td valign='middle' align='center'><img src='asset/produk/merk/$img_merk' width='50px' height='50px'></td>
		<td valign='middle' align='center'>$nama_merk</td>
		<td valign='middle' align='center' id='td-data-aksi-green'>
			<a href='?m=11&k=$kode_merk' style='display:block'><img src='asset/icon/edit.png' width='25px' height='25px'></a>
		</td>
		<td valign='middle' align='center' id='td-data-aksi-red'>
			<a href='proses/produk/delete_merk.php?id=$kode_merk' onclick='return confirm (\"Hapus Merk $nama_merk\")' style='display:block'><img src='asset/icon/delete.png' width='25px' height='25px'></a>
		</td>
	</tr>
	";
}
?>
<tr>
	<tr><th class='table-data-footer' colspan="5"></th></tr>
</tr>
</table>
<?php
}
}
?>