<?php
$rows_edit_produk = mysql_num_rows(mysql_query("select*from t_produk where kode_produk='$k' and stat_produk='1'"));
if($rows_edit_produk==0){
	header("location:?m=404");
}else{

$d_view_produk = mysql_fetch_array(mysql_query("select*from t_produk natural join t_merk where kode_produk='$k'"));

$kode_merk_e = $d_view_produk['kode_merk'];
$nama_merk = $d_view_produk['nama_merk'];
$gambar_produk = $d_view_produk['gambar_produk'];
$nama_produk = $d_view_produk['nama_produk'];
$stok_produk = $d_view_produk['stok_produk'];
$harga_produk = $d_view_produk['harga_produk'];
$harga_produk_view = "Rp.".number_format($harga_produk,0,',','.');
$dp_produk = $d_view_produk['uang_muka_produk'];
$dp_produk_view = "Rp.".number_format($dp_produk,0,',','.');
$bunga_produk = $d_view_produk['bunga_produk'];
$desk_produk = $d_view_produk['desk_produk'];

$hasil_bunga = ($bunga_produk/100) * $harga_produk;
$view_bunga = "Rp.".number_format($hasil_bunga,0,',','.');

$bagi_10 = ( $harga_produk - $dp_produk ) / 10;
$hasil_10 = "Rp.".number_format($bagi_10 + $hasil_bunga,0,',','.');

$bagi_16 = ( $harga_produk - $dp_produk ) / 16;
$hasil_16 = "Rp.".number_format($bagi_16 + $hasil_bunga,0,',','.');
 
$bagi_22 = ( $harga_produk - $dp_produk ) / 22;
$hasil_22 = "Rp.".number_format($bagi_22 + $hasil_bunga,0,',','.');

$bagi_28 = ( $harga_produk - $dp_produk ) / 28;
$hasil_28 = "Rp.".number_format($bagi_28 + $hasil_bunga,0,',','.');

$bagi_34 = ( $harga_produk - $dp_produk ) / 34;
$hasil_34 = "Rp.".number_format($bagi_34 + $hasil_bunga,0,',','.');


echo"
<div id='div-cetak'>
<table cellpadding='5'>
<tr>
	<td rowspan='6' style='border:1px solid #000'><img src='asset/produk/produk/$gambar_produk' width='250px' height='250px'></td>
	<td rowspan='6' width='20'></td>
	<td><b>Merk</b></td><td><b>:</b></td><td>$nama_merk</td>
</tr>
<tr>
	<td><b>Nama Produk</b></td><td><b>:</b></td><td>$nama_produk</td>
</tr>
<tr>
	<td><b>Stok</b></td><td><b>:</b></td><td>$stok_produk</td>
</tr>
<tr>
	<td><b>Harga</b></td><td><b>:</b></td><td>$harga_produk_view</td>
</tr>
<tr>
	<td><b>Bunga</b></td><td><b>:</b></td><td>$bunga_produk %</td>
</tr>
<tr>
	<td valign='top'><b>Deskripsi</b></td><td valign='top'><b>:</b></td><td valign='top' align='justify'>$desk_produk</td>
</tr>
</table>
</div>
<br><br>
<center><a class='no-print' href=\"javascript:printDiv('div-cetak');\"><input type='button' value='Cetak' class='button-class'/></a></center>
";
}
?>
