<div>
<center>
<?php
$gs = date("d");
$bs = date("n");
$ts = date("Y");
?>
<select id='awal-tgl' class='inp-pad'>
<?php
for($ag=1;$ag<=31;$ag++){
	if($ag==$gs){
		echo"<option value='$ag' selected>$ag</option>";
	}else{
		echo"<option value='$ag'>$ag</option>";
	}
}
?>
</select>
<select id='awal-bulan' class='inp-pad'>
<?php
for($ab=1;$ab<=12;$ab++){
	if($ab==$bs){
		echo"<option value='$ab' selected>$ab</option>";
	}else{
		echo"<option value='$ab'>$ab</option>";
	}
}
?>
</select>
<select id='awal-tahun' class='inp-pad'>
<?php
for($at=2010;$at<=2020;$at++){
	if($at==$ts){
		echo"<option value='$at' selected>$at</option>";
	}else{
		echo"<option value='$at'>$at</option>";
	}
}
?>
</select>
sampai
<select id='batas-tgl' class='inp-pad'>
<?php
for($bg=1;$bg<=31;$bg++){
	if($bg==$gs){
		echo"<option value='$bg' selected>$bg</option>";
	}else{
		echo"<option value='$bg'>$bg</option>";
	}
}
?>
</select>
<select id='batas-bulan' class='inp-pad'>
<?php
for($bb=1;$bb<=12;$bb++){
	if($bb==$bs){
		echo"<option value='$bb' selected>$bb</option>";
	}else{
		echo"<option value='$bb'>$bb</option>";
	}
}
?>
</select>
<select id='batas-tahun' class='inp-pad'>
<?php
for($bt=2010;$bt<=2020;$bt++){
	if($bt==$ts){
		echo"<option value='$bt' selected>$bt</option>";
	}else{
		echo"<option value='$bt'>$bt</option>";
	}
}
?>
</select>
<input type='button' class='button-class' value="Tampilkan" onclick="tampil_laporan_pelanggan()">
</center>
</div>
<br><hr><br>
<div id='hasil-tampil-laporan-pelanggan'></div>