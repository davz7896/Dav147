<?php
echo"
<div id='div-cetak'>
<div style='border:1px solid #000; padding:10px'>
<div style='text-align:center;line-height:30px'>
<b style='font-size:20px'>Laporan Produk</b><br>
<b>$nama_perusahaan</b> <br>
$alamat_perusahaan
</div>
<hr>
";
?>
<div style='padding:10px'>
<?php
function getReportJumMerk(){
	$rows_report_merk = mysql_num_rows(mysql_query("select*from t_merk where stat_merk='1'"));
	echo"$rows_report_merk";
}

function getReportJumProduk(){
	$rows_report_produk = mysql_num_rows(mysql_query("select*from t_produk where stat_produk='1'"));
	echo"$rows_report_produk";
}

function getReportJumProdukTersedia(){
	$rows_report_produk_tersedia = mysql_num_rows(mysql_query("select*from t_produk where stat_produk='1' and stok_produk>0"));
	echo"$rows_report_produk_tersedia";
}

function getReportJumProdukHabis(){
	$rows_report_produk_habis = mysql_num_rows(mysql_query("select*from t_produk where stat_produk='1' and stok_produk<=0"));
	echo"$rows_report_produk_habis";
}

function getReportProdukPerMerk(){
	$query_merk = mysql_query("select*from t_merk where stat_merk='1'");
	echo"<table>";
	while($data_merk = mysql_fetch_array($query_merk)){
		$kode_merk = $data_merk['kode_merk'];
		$nama_merk = $data_merk['nama_merk'];
		$jum_produk = mysql_num_rows(mysql_query("select*from t_produk where kode_merk='$kode_merk' and stat_produk='1'"));
		echo"<tr><td>$nama_merk</td><td>:</td><td>$jum_produk</td></tr>";
	}
	echo"</table>";
}

?>
<table cellpadding="5" cellspacing="0" width="100%">
<tr>
	<td width='200px'>Perusahaan</td>
    <td width="15px">:</td>
    <td><?php getReportJumMerk(); ?></td>
</tr>
<tr>
	<td>Kavling</td>
    <td>:</td>
    <td><?php getReportJumProduk(); ?></td>
</tr>
<tr>
	<td>Kavling Tersedia</td>
    <td>:</td>
    <td><?php getReportJumProdukTersedia(); ?></td>
</tr>
<tr>
	<td>Kavlin habis stok</td>
    <td>:</td>
    <td><?php getReportJumProdukHabis(); ?></td>
</tr>
<tr>
	<td valign="top">Rincian perusahaan per-PT</td>
    <td valign="top">:</td>
    <td><?php getReportProdukPerMerk(); ?></td>
</tr>
<tr>
	<td colspan="3" align="right">Surabaya, <?php getTanggal(); ?></td>
</tr>
</table>
</div>
</div>
</div>
<br /><div class='clr'></div><br />
<center><a class='no-print' href="javascript:printDiv('div-cetak');"><input type='button' value='Cetak' class='button-class'/></a></center>