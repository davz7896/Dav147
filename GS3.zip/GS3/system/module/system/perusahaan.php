<?php
if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, and tidak punya hak untuk halaman ini</h2></b></center>";
}else{
$data_perusahaan = mysql_fetch_array(mysql_query("select*from t_perusahaan where kode_perusahaan='si_kredit'"));

$nama_perusahaan = $data_perusahaan['nama_perusahaan'];
$alamat_perusahaan = $data_perusahaan['alamat_perusahaan'];
$telp_perusahaan = $data_perusahaan['telp_perusahaan'];
$mail_perusahaan = $data_perusahaan['mail_perusahaan'];
$web_perusahaan = $data_perusahaan['web_perusahaan'];
?>
<form method="post" action="proses/system/perusahaan.php" enctype="multipart/form-data">
<table cellpadding="5" border='0'>
<tr>
	<td><label for='nama-per'>Nama</label></td>
	<td width="10"></td>
    <td><input type='text' name='nama' class='input-field' required id='nama-per' <?php echo"value='$nama_perusahaan'"; ?>></td>
</tr>
<tr>
	<td><label for='alamat-per'>Alamat</label></td>
    <td width="10"></td>
    <td><input type='text' name='alamat' class='input-field' required id='alamat-per' <?php echo"value='$alamat_perusahaan'"; ?>></td>
</tr>
<tr>
	<td><label for='telp-per'>Telepon</label></td>
    <td width="10"></td>
    <td><input type='number' name='telp' class='input-field' required id='telp-per' <?php echo"value='$telp_perusahaan'"; ?>></td>
</tr>
<tr>
	<td><label for='mail-per'>E-mail</label></td>
    <td width="10"></td>
    <td><input type='email' name='mail' class='input-field' required id='mail-per' <?php echo"value='$mail_perusahaan'"; ?>></td>
</tr>
<tr>
	<td><label for='web-per'>Website</label></td>
    <td width="10"></td>
    <td><input type='text' name='web' class='input-field' required id='web-per' <?php echo"value='$web_perusahaan'"; ?>></td>
</tr>
<tr>
	<td></td><td width="10"></td><td><input type='submit' value='Simpan' class='button-class'></td>
</tr>
</table>
</form>
<?php } ?>