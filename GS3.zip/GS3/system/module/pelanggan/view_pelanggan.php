<style>
.display-berkas-plgn{
	width:200px;
	height:250px;
	float:left;
	margin-right:25px;
	padding:5px;
	border:1px solid #CCC;
}
</style>
<?php
$rows_data_pelanggan = mysql_num_rows(mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk where kode_pelanggan='$k' and stat_pelanggan='1'"));
if($rows_data_pelanggan==0){
	header("location:?m=404");
}else{
$q_plgn = mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk natural join t_admin where kode_pelanggan='$k' and stat_pelanggan='1' and stat_beli='1'");
$d_plgn = mysql_fetch_array($q_plgn);
	$kode_plgn = $d_plgn['kode_pelanggan'];
	$nama_plgn = $d_plgn['nama_pelanggan'];
	$sisa_pembayaran_plgn_ags = $d_plgn['sisa_pembayaran'];
	$sisa_pembayaran_plgn = "Rp.".number_format($d_plgn['sisa_pembayaran'],0,",",".");
	$telp_plgn = $d_plgn['telp_pelanggan'];
	$alamat_plgn = $d_plgn['alamat_pelanggan'];
	$no_ktp_plgn = $d_plgn['no_ktp_pelanggan'];
	$kode_produk_plgn = $d_plgn['kode_produk'];
	$merk_plgn = $d_plgn['nama_merk'];
	$produk_plgn = $d_plgn['nama_produk'];
	$stat_cicilan_plgn = $d_plgn['stat_cicilan'];
	$ktp_plgn = $d_plgn['berkas_ktp'];
	$kk_plgn = $d_plgn['berkas_kk'];
	$slip_plgn = $d_plgn['berkas_slip'];
	$dp_plgn = $d_plgn['uang_muka_pembelian'];
	$dp_produk_plgn = $d_plgn['uang_muka_produk'];
	$harga_produk_plgn = $d_plgn['harga_produk'];
	$tgl_plgn = $d_plgn['tgl_pelanggan'];
	$batas_pembayaran_pelanggan = $d_plgn['batas_bayar'];
	$plode_tgl_plgn = explode("-",$tgl_plgn);
	$tanggal_plgn = $plode_tgl_plgn[2];
	$bulan_plgn = $plode_tgl_plgn[1];
	$tahun_plgn = $plode_tgl_plgn[0];
	$nama_admin_plgn = $d_plgn['nama_admin'];
	$bunga_produk_plgn = $d_plgn['bunga_produk'];
	$harga_produk_plgn = $d_plgn['harga_produk'];
	
	$hasil_bunga_plgn = ($bunga_produk_plgn/100) * $harga_produk_plgn;
	
	$bagi_cil = ( $harga_produk_plgn - $dp_produk_plgn ) / $stat_cicilan_plgn;
	$hasil_cil = "Rp.".number_format($bagi_cil + $hasil_bunga_plgn,0,',','.');
	
	$rows_angsuran_plgn = mysql_num_rows(mysql_query("select*from t_angsuran where kode_pelanggan='$k' and stat_angsuran='1'"));
	
	if($rows_angsuran_plgn==$stat_cicilan_plgn){
			if($sisa_pembayaran_plgn_ags<=0){
				$stat_angsuran_plgn = "Lunas";
			}else{
			if($dp_plgn==$harga_produk_plgn){
				$stat_angsuran_plgn = "Lunas";
			}else{
				$stat_angsuran_plgn = "Masa Angsuran";
			}

			}
		}else{
			$stat_angsuran_plgn = "Masa Angsuran";
		}
	
	
	if(strcmp($ktp_plgn,"kosong")==0){
		$ket_ktp = "KTP tidak ada";
		$display_ktp = "";
	}else{
		$ket_ktp = "KTP ada";
		$display_ktp = "<img src='asset/berkas/ktp/$ktp_plgn' class='display-berkas-plgn' title='KTP Pelanggan'>";
	}
	
	if(strcmp($kk_plgn,"kosong")==0){
		$ket_kk = "KK tidak ada";
		$display_kk = "";
	}else{
		$ket_kk = "KK ada";
		$display_kk = "<img src='asset/berkas/kk/$kk_plgn' class='display-berkas-plgn' title='KK Pelanggan'>";
	}
	
	if(strcmp($slip_plgn,"kosong")==0){
		$ket_slip = "Slip gaji tidak ada";
		$display_slip = "";
	}else{
		$ket_slip = "Slip gaji ada";
		$display_slip = "<img src='asset/berkas/slip/$slip_plgn' class='display-berkas-plgn' title='Slip gaji Pelanggan'>";
	}
	
	echo"
	<div id='form-data-pelanggan'>
	";
	if(isset($_GET['d'])){
		$d = $_GET['d'];
		if($d==1){
			$dp_hasil_bayar = $_GET['n'];
			$view_dp_hasil_bayar = "Rp.".number_format($dp_hasil_bayar,"0",",",".");
			$tgl_skrg = date("d-n-Y");	
	echo"
	<div id='div-cetak-dp' style='display:none'>
	<div style='border:1px solid #000;padding:10px'>
	<center>
		<b>Tanda Bukti Pembayaran <br>
		$nama_perusahaan</b><br><hr><br>
	<table cellpadding='5' width='100%' border='0'>
		<tr>
			<td><b>Kode</b></td>
			<td><b>:</b></td>
			<td>$k</td>
		</tr>
		<tr>
			<td><b>Nama</b></td>
			<td><b>:</b></td>
			<td>$nama_plgn</td>
		</tr>
		<tr>
			<td valign='top'><b>Alamat</b></td>
			<td valign='top'><b>:</b></td>
			<td>$alamat_plgn</td>
		</tr>
		<tr>
			<td><b>Produk</b></td>
			<td><b>:</b></td>
			<td>$merk_plgn $produk_plgn</td>
		</tr>
		<tr>
			<td><b>Keterangan</b></td>
			<td><b>:</b></td>
			<td>Pembayaran Uang Muka ( DP ) - $view_dp_hasil_bayar</td>
		</tr>
		<tr>
			<td><b>Pegawai</b></td>
			<td><b>:</b></td>
			<td>$nama_admin_plgn</td>
		</tr>
		<tr>
			<td colspan='3' align='right'>Cirebon, $tgl_skrg</td>
		</tr>
	</table>
	</div>
	</div>
	";
	echo"
	<b>Terima kasih telah melakukan pembayaran</b> 
	<a class='no-print' href=\"javascript:printDiv('div-cetak-dp');\"><input type='button' value='Cetak Tanda Bukti Pembayaran' class='button-class'/></a>
	<br><br><hr>
	";

		}else{
			echo"<b>Maaf, proses pembayaran gagal</b>"; 
		}
	}else{
		$d = "";
	}
	echo"
	</div>
	";
	
	
	echo"
	<div id='div-cetak' style='display:none'>
	<div style='border:1px solid #000;padding:10px'>
	<center>
		<b>Tanda Bukti Pembelian <br>
		$nama_perusahaan</b><br><hr><br>
	<table cellpadding='5' width='100%' border='0'>
		<tr>
			<td width='100px'><b>Kode</b></td>
			<td><b>:</b></td>
			<td>$k</td>
		</tr>
		<tr>
			<td><b>Nama</b></td>
			<td><b>:</b></td>
			<td>$nama_plgn</td>
		</tr>
		<tr>
			<td valign='top'><b>Alamat</b></td>
			<td valign='top'><b>:</b></td>
			<td>$alamat_plgn</td>
		</tr>
		<tr>
			<td><b>Produk</b></td>
			<td><b>:</b></td>
			<td>$merk_plgn $produk_plgn</td>
		</tr>
		<tr>
			<td><b>Pegawai</b></td>
			<td><b>:</b></td>
			<td>$nama_admin_plgn</td>
		</tr>
		<tr>
			<td colspan='3' align='right'>Cirebon, $tanggal_plgn-$bulan_plgn-$tahun_plgn</td>
		</tr>
	</table>
	</div>
	</div>
	";
	
	echo"
	<table cellpadding='5'>
	<tr>
		<td><b>Kode</b></td>
		<td>:</td>
		<td>$k</td>
	</tr>
	<tr>
		<td><b>Nama</b></td>
		<td>:</td>
		<td>$nama_plgn</td>
	</tr>
	<tr>
		<td><b>Telepon / HP</b></td>
		<td>:</td>
		<td>$telp_plgn</td>
	</tr>
	<tr>
		<td valign='top'><b>Alamat</b></td>
		<td valign='top'>:</td>
		<td>$alamat_plgn</td>
	</tr>
	<tr>
		<td><b>No.KTP</b></td>
		<td>:</td>
		<td>$no_ktp_plgn</td>
	</tr>
	<tr>
		<td><b>Produk</b></td>
		<td>:</td>
		<td><a href='?m=14&k=$kode_produk_plgn'>$merk_plgn $produk_plgn</a></td>
	</tr>
	<tr>
		<td><b>Cicilan</b></td>
		<td>:</td>
		<td>$stat_cicilan_plgn"."x"."</td>
	</tr>
	<tr>
		<td><b>Sisa Pembayaran</b></td>
		<td>:</td>
		<td>$sisa_pembayaran_plgn</td>
	</tr>
	<tr>
		<td><b>Tanggal</b></td>
		<td>:</td>
		<td>$tanggal_plgn-$bulan_plgn-$tahun_plgn</td>
	</tr>
	<tr>
		<td><b>Batas Pembayaran</b></td>
		<td>:</td>
		<td>$batas_pembayaran_pelanggan</td>
	</tr>
	<tr>
		<td><b>Status</b></td>
		<td>:</td>
		<td>$stat_angsuran_plgn</td>
	</tr>
	<tr>
		<td valign='top'><b>Keterangan</b></td>
		<td valign='top'>:</td>
		<td>$ket_ktp <br> $ket_kk <br> $ket_slip</td>
	</tr>
	<tr>
		<td colspan='3'>&nbsp;</td>
	</tr>
	";
	echo"
	<tr>
		<td></td><td></td>
		<td>
		<input type='button' onclick='direct_page(\"?m=21&k=$k\")' value='Edit Data' class='button-class'>
		";
		if($rows_angsuran_plgn==$stat_cicilan_plgn){
			if($sisa_pembayaran_plgn_ags==0){
			}else{
				if($dp_plgn==$harga_produk_plgn){
				}else{
			echo"<input type='button' onclick='direct_page(\"?m=24&k=$k\")' value='Bayar Angsuran' class='button-class'> ";
				}
			}
		}else{
			echo"<input type='button' onclick='direct_page(\"?m=24&k=$k\")' value='Bayar Angsuran' class='button-class'> ";
		}
	

		
		echo"
			<a class='no-print' href=\"javascript:printDiv('div-cetak');\"><input type='button' value='Cetak Tanda Bukti' class='button-class'/></a>
		</td>
	</tr>
	";
	echo"
	</table>
	";
	?>
    <br /><hr /><br />
    <?php
	echo"
	<center>
	<h2>Berkas Pelanggan</h2>
	<br>
	<table>
	<tr>
	<td align='center'>
	$display_ktp $display_kk $display_slip
	<div class='clr'></div>
	</td>
	</tr>
	</table>
	</center>
	";
	?>
    <br /><hr /><br />
    <center><h2>Angsuran</h2></center>
    <br />
    <?php
	$ags = mysql_num_rows(mysql_query("select*from t_angsuran where kode_pelanggan='$k' and stat_angsuran='1'"));
	if($ags==0){
			echo"<center><b><h2>Data angsuran kosong</h2></b></center>";
	}else{

	?>
    <table class='table-data' width='100%' align="center" cellpadding="10" cellspacing="0" border='0'>
    <tr class='table-data-header'>
        <th width='100px' id='table-data-header-left'>Angsuran ke</th><th>Tanggal</th><th>Pegawai</th><th>Status</th><th>Denda</th><th id='table-data-header-right'></th>
    </tr>
    <tr>
    <?php
	$q_ags_plgn = mysql_query("select*from t_angsuran natural join t_admin where kode_pelanggan='$k' order by kode_angsuran desc");
	while($d_ags_plgn = mysql_fetch_array($q_ags_plgn)){
		$ags--;
		$urut_ags = $ags+1;
		$kode_ags = $d_ags_plgn['kode_angsuran'];
		$tanggal_ags = $d_ags_plgn['tgl_angsuran'];
		$denda_ags_view = "Rp.".number_format($d_ags_plgn['denda_angsuran'],0,",",".");
		$plode_tanggal_ags = explode("-",$tanggal_ags);
		$tgl_ags = $plode_tanggal_ags[2];
		$bulan_ags = $plode_tanggal_ags[1];
		$th_ags = $plode_tanggal_ags[0];
		$nama_admin_ags = $d_ags_plgn['nama_admin'];
		$stat_ags = $d_ags_plgn['stat_bayar_angsuran'];
		
		if($stat_ags==1){
			$ket_stat = "Tepat Waktu";
		}else{
			$ket_stat = "Terlambat";
		}
		
		echo"
		<tr>
			<td valign='middle' align='center'>$urut_ags</td>
			<td valign='middle' align='right'>$tgl_ags-$bulan_ags-$th_ags</td>
			<td valign='middle' align='center'>$nama_admin_ags</td>
			<td valign='middle' align='center'>$ket_stat</td>
			<td valign='middle' align='center'>$denda_ags_view</td>
			<td valign='middle' align='center'><input type='button' value='Lihat' onclick='show_angsuran($kode_ags,$urut_ags)' class='button-class'></td>
		</tr>
		";
	}
	?>
	<tr><th class='table-data-footer' colspan="6"></th></tr>
	</tr>
    </table>
  
  	<div id='laporan-ags-plgn' style='display:none'>  
    <?php
	echo"
	<center><h2>Laporan Angsuran</h2></center>
	<br><hr><br>
	<table>
	<tr>
		<td>Nama</td>
		<td>:</td>
		<td>$nama_plgn</td>
	</tr>
	<tr>
		<td>Alamat</td>
		<td>:</td>
		<td>$alamat_plgn</td>
	</tr>
	<tr>
		<td>Produk</td>
		<td>:</td>
		<td>$merk_plgn $produk_plgn</td>
	</tr>
	<tr>
		<td>Sisa Pembayaran</td>
		<td>:</td>
		<td>$sisa_pembayaran_plgn</td>
	</tr>
	<tr>
		<td>Keterangan</td>
		<td>:</td>
		<td>$stat_angsuran_plgn</td>
	</tr>
	</table>
	<br><br>
	";
	?>    
    <table width='100%' align="center" cellpadding="10" cellspacing="0" border='1'>
    <tr>
        <th width='100px'>Angsuran ke</th><th>Tanggal</th><th>Pegawai</th><th>Status</th><th>Denda</th>
    </tr>
    <tr>
    <?php
	$ags = mysql_num_rows(mysql_query("select*from t_angsuran where kode_pelanggan='$k' and stat_angsuran='1'"));
	$q_ags_plgn = mysql_query("select*from t_angsuran natural join t_admin where kode_pelanggan='$k' order by kode_angsuran desc");
	while($d_ags_plgn = mysql_fetch_array($q_ags_plgn)){
		$ags--;
		$urut_ags = $ags+1;
		$kode_ags = $d_ags_plgn['kode_angsuran'];
		$tanggal_ags = $d_ags_plgn['tgl_angsuran'];
		$denda_ags_view = "Rp.".number_format($d_ags_plgn['denda_angsuran'],0,",",".");
		$plode_tanggal_ags = explode("-",$tanggal_ags);
		$tgl_ags = $plode_tanggal_ags[2];
		$bulan_ags = $plode_tanggal_ags[1];
		$th_ags = $plode_tanggal_ags[0];
		$nama_admin_ags = $d_ags_plgn['nama_admin'];
		$stat_ags = $d_ags_plgn['stat_bayar_angsuran'];
		
		if($stat_ags==1){
			$ket_stat = "Tepat Waktu";
		}else{
			$ket_stat = "Terlambat";
		}
		
		echo"
		<tr>
			<td valign='middle' align='center'>$urut_ags</td>
			<td valign='middle' align='right'>$tgl_ags-$bulan_ags-$th_ags</td>
			<td valign='middle' align='center'>$nama_admin_ags</td>
			<td valign='middle' align='center'>$ket_stat</td>
			<td valign='middle' align='center'>$denda_ags_view</td>
		</tr>
		";
	}
	?>
	</tr>
    </table>
    <br />
    </div>
    <br />
    <center><input type='button' value='Cetak' onclick="javascript:printDiv('laporan-ags-plgn')" class='button-class'></center>
    <?php
	}
}
?>