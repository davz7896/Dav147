<?php
$rows_pelanggan = mysql_num_rows(mysql_query("select*from t_pelanggan where kode_pelanggan='$k' and stat_pelanggan='1'"));
if($rows_pelanggan==0){
	header("location:?m=404");
}else{
	$data_produk_new_buy_plgn = mysql_fetch_array(mysql_query("select*from t_pembelian where kode_pelanggan='$k'"));
	$stat_pilih_produk_new = $data_produk_new_buy_plgn['stat_beli'];
	if($stat_pilih_produk_new==1){
		header("location:?m=404");
	}else{
		$data_pemeblian_plgn = mysql_fetch_array(mysql_query("select*from t_pelanggan where kode_pelanggan='$k'"));
		$nama_pembelian_plgn = $data_pemeblian_plgn['nama_pelanggan'];
?>
<form method="post" action="proses/pelanggan/pembelian.php">
<table width="100%" border='0'>
<tr>
<td>
<table cellpadding="5">
<tr>
	<td><label for='field-kode-plgn'>Kode</label></td>
    <td><input type='text' name='kode' class='input-field' id='field-kode-plgn' <?php echo"value='$k'"; ?> /></td>
</tr>
<tr>
	<td><label for='field-nama-plgn'>Nama</label></td>
    <td><input type='text' name='nama' class='input-field' id='field-nama-plgn' <?php echo"value='$nama_pembelian_plgn'"; ?> readonly /></td>
</tr>
<tr>
	<td><label>Perusahaan</label></td>
    <td>
    	<select class='inp-pad' onChange="show_produk_buy(this.value)" style='float:left'>
        <option value='0'>-- Pilih PT --</option>
        <?php
		$q_buy_merk = mysql_query("select*from t_merk where stat_merk='1' order by nama_merk");
		while($d_buy_merk = mysql_fetch_array($q_buy_merk)){
			$kode_buy_merk = $d_buy_merk['kode_merk'];
			$nama_buy_merk = $d_buy_merk['nama_merk'];
			$rows_produk_buy_merk = mysql_num_rows(mysql_query("select*from t_produk where kode_merk='$kode_buy_merk'"));
			if($rows_produk_buy_merk==0){
			}else{
				echo"<option value='$kode_buy_merk'>$nama_buy_merk</option>";
			}
		}
		?>
        </select>
    </td>
</tr>
<tr>
	<td><label>Kavling</label></td>
    <td>
    	<select name='produk' class='inp-pad' onchange="tampilkan_produk_pilihan(this.value)" id='pilihan-beli-produk' style='float:left'>
        <option value='0'>-- Pilih Kavling --</option>
        </select>
        <div id='load-ajax-field-beli-produk' style='float:left;margin-top:3px;margin-left:10px;height:25px'></div>
    </td>
</tr>
<tr>
	<td><label for='field-dp-plgn'>Uang Muka ( DP )</label></td>
    <td><input type='number' name='dp' class='input-field' id='field-dp-plgn' onkeyup="tampilkan_dp_pelanggan(this.value)" placeholder='Uang Muka ( DP )' required style='float:left;width:150px'/>
     <div id='hasil-field-dp' style='float:left;margin-top:3px;margin-left:10px;height:25px'></div>
    </td>
</tr>
<tr>
	<td><label>Cicilan</label></td>
    <td>
    <div id='hasil-bayar-dp-plgn'>
		<select name='cicilan' class='inp-pad' onchange="tampilkan_cicilan_pilihan(this.value)" id='pilihan-cicilan-produk' style='float:left'>
        	<option value='0'>-- Pilih Cicilan --</option>
            <option value='10'>10x</option>
            <option value='16'>16x</option>
            <option value='22'>22x</option>
            <option value='28'>28x</option>
            <option value='34'>36x</option>
        </select>
        <div id='hasil-field-cicilan-produk' style='float:left;margin-top:3px;margin-left:10px;height:25px'></div>
    </div>
    </td>
</tr>
<tr>
	<td></td><td><input type='submit' value='Simpan' class='button-class' id='submit-pembelian-plgn' /></td>
</tr>
</table>
</td>
<td id='hasil-data-ajax-field-beli-produk' width='200px' height="350px">
</td>
</tr>
</table>
</form>
<br /><hr /><br />
<?php }} ?>