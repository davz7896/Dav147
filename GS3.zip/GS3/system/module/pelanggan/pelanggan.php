<?php
$jum_pelanggan = mysql_num_rows(mysql_query("select*from t_pelanggan where stat_pelanggan='1'"));
$jum_hal = ceil($jum_pelanggan / 10);
if($p==1){
	$limit = 0;
}else{
	$limit = ( $p * 10 ) - 10;
}
?>
<form method="post" action="?m=23" style='float:right; height:50px; line-height:30px; margin-right:30px'>
<input type='text' name='cari' class='input-field' placeholder="Pencarian Pelanggan" required />
<input type='submit' value='Cari' class='button-class' />
</form>
<div class='clr'></div>
<hr /><br />
<table class='table-data' width='100%' align="center" cellpadding="10" cellspacing="0" border='0'>
<tr class='table-data-header'>
	<th id='table-data-header-left'>No</th><th>Nama</th><th>Kavling</th><th>Kontak</th><th>Keterangan</th><th id='table-data-header-right'></th>
</tr>
<?php
$plgn = $limit;
$q_plgn = mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk where stat_pelanggan='1' and stat_beli='1' order by nama_pelanggan limit $limit,10");
while($d_plgn = mysql_fetch_array($q_plgn)){
	$plgn++;
	$kode_plgn = $d_plgn['kode_pelanggan'];
	$nama_plgn = $d_plgn['nama_pelanggan'];
	$telp_plgn = $d_plgn['telp_pelanggan'];
	$alamat_plgn = $d_plgn['alamat_pelanggan'];
	$kode_produk_plgn = $d_plgn['kode_produk'];
	$merk_plgn = $d_plgn['nama_merk'];
	$produk_plgn = $d_plgn['nama_produk'];
	$ktp_plgn = $d_plgn['berkas_ktp'];
	$kk_plgn = $d_plgn['berkas_kk'];
	$slip_plgn = $d_plgn['berkas_slip'];
	$dp_plgn = $d_plgn['uang_muka_pembelian'];
	$dp_produk_plgn = $d_plgn['uang_muka_produk'];
		
	if(strcmp($ktp_plgn,"kosong")==0){
		$ket_ktp = "KTP tidak ada";
	}else{
		$ket_ktp = "KTP ada";
	}
	
	if(strcmp($kk_plgn,"kosong")==0){
		$ket_kk = "<br> KK tidak ada";
	}else{
		$ket_kk = "KK ada";
	}
	
	if(strcmp($slip_plgn,"kosong")==0){
		$ket_slip = "<br> Slip gaji tidak ada";
	}else{
		$ket_slip = "Slip gaji ada";
	}
		
	echo"
	<tr>
		<td valign='middle' align='center'>$plgn</td>
		<td valign='middle' align='center'><a href='?m=20&k=$kode_plgn'>$nama_plgn</a></td>
		<td valign='middle' align='center'><a href='?m=14&k=$kode_produk_plgn'>$merk_plgn<br>$produk_plgn</a></td>
		<td valign='middle' width='200px' align='justify'>
			<b>Alamat :</b> <br>
			$alamat_plgn <br>
			<b>Telepon / HP :</b> <br>
			$telp_plgn <br>
		</td>
		<td valign='middle' align='justify'>$ket_ktp $ket_kk $ket_slip</td>
		<td valign='middle' align='center' id='td-data-aksi-red'><a href='proses/pelanggan/delete_pelanggan.php?id=$kode_plgn' onclick='return confirm (\"Hapus Pelanggan $nama_plgn\")' style='display:block'><img src='asset/icon/delete.png' width='25px' height='25px'></a></td>
	</tr>
	";
}
?>
<tr>
	<tr><th class='table-data-footer' colspan="6"></th></tr>
</tr>
</table>
<br /><div class='clr'></div><br />
<div id='paging-left'>
<b>Halaman : </b>
<select class='inp-pad' onchange="direct_page(this.value)">
<?php
for($h=1;$h<=$jum_hal;$h++){
	if($h==$p){
		echo"<option value='?m=$m&p=$h' selected>$h</option>";
	}else{
		echo"<option value='?m=$m&p=$h'>$h</option>";
	}
}
?>
</select>
</div>
<div id='paging-right'>
<?php
if($jum_hal<=1){
}else if($p==$jum_hal){
	$min_p = $p - 1;
	echo"<a href='?m=$m&p=$min_p' id='prev-paging'><img src='asset/icon/prev.png' /></a>";
}else if($p==1){
	$plus_p = $p + 1;
	echo"<a href='?m=$m&p=$plus_p' id='next-paging'><img src='asset/icon/next.png' /></a>";
}else{
	$plus_p = $p + 1;
	$min_p = $p - 1;
	echo"<a href='?m=$m&p=$min_p' id='prev-paging'><img src='asset/icon/prev.png' /></a>";
	echo"<a href='?m=$m&p=$plus_p' id='next-paging'><img src='asset/icon/next.png' /></a>";
}
?>
</div>
<div class='clr'></div>