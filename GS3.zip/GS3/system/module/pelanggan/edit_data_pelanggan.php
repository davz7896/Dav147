<?php
$rows_data_pelanggan = mysql_num_rows(mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk where kode_pelanggan='$k' and stat_pelanggan='1'"));
if($rows_data_pelanggan==0){
	header("location:?m=404");
}else{
$data_edit_plgn = mysql_fetch_array(mysql_query("select*from t_pelanggan where kode_pelanggan='$k'"));
$nama_plgn = $data_edit_plgn['nama_pelanggan'];
$telp_plgn = $data_edit_plgn['telp_pelanggan'];
$alamat_plgn = $data_edit_plgn['alamat_pelanggan'];
$no_ktp_plgn = $data_edit_plgn['no_ktp_pelanggan'];
$ktp_plgn = $data_edit_plgn['berkas_ktp'];
$kk_plgn = $data_edit_plgn['berkas_kk'];
$slip_plgn = $data_edit_plgn['berkas_slip'];
;
?>
<form method="post" action="proses/pelanggan/edit_data_pelanggan.php" enctype="multipart/form-data">
<table cellpadding="5">
<tr>
	<td><label for='field-kode-plgn'>Kode</label></td>
    <td><input type='text' name='kode' class='input-field' id='field-kode-plgn' <?php echo"value='$k'"; ?> readonly /></td>
</tr>
<tr>
	<td><label for='field-nama-plgn'>Nama</label></td>
    <td><input type='text' name='nama' class='input-field' id='field-nama-plgn' <?php echo"value='$nama_plgn'"; ?> required /></td>
</tr>
<tr>
	<td><label for='field-telp-plgn'>Telepon / HP</label></td>
    <td><input type='number' name='telp' class='input-field' id='field-telp-plgn' <?php echo"value='$telp_plgn'"; ?> required /></td>
</tr>
<tr>
	<td valign="top"><label for='field-alamat-plgn'>Alamat</label></td>
    <td><textarea name='alamat' id='field-alamat-plgn' class='input-field' style='width:400px;height:100px'><?php echo"$alamat_plgn"; ?></textarea></td>
</tr>
<tr>
	<td><label for='field-no-ktp-plgn'>No KTP</label></td>
    <td><input type='number' name='no_ktp' class='input-field' id='field-no-ktp-plgn' <?php echo"value='$no_ktp_plgn'"; ?> required /></td>
</tr>
<tr>
	<td valign="top"><label>Berkas</label></td>
    <td>
    <table>
    <?php
    if(strcmp($ktp_plgn,"kosong")==0){
		$ket_ktp = "KTP tidak ada";
	}else{
		$ket_ktp = "KTP ada";
	}
	
	if(strcmp($kk_plgn,"kosong")==0){
		$ket_kk = "KK tidak ada";
	}else{
		$ket_kk = "KK ada";
	}
	
	if(strcmp($slip_plgn,"kosong")==0){
		$ket_slip = "Slip gaji tidak ada";
	}else{
		$ket_slip = "Slip gaji ada";
	}
    ?>
    	<tr>
	        <td><label for='value-ktp-plgn'>KTP <?php echo"( $ket_ktp )"; ?></label></td><td><input type='file' name='ktp_value' id='value-ktp-plgn' /></td>
            <td><input type='checkbox' name='kosong_ktp' id='kosong-ktp' /><label for='kosong-ktp'>Kosongkan</label></td>
         </tr>
         <tr>
	        <td><label for='value-kk-plgn'>KK <?php echo"( $ket_kk )"; ?></label></td><td><input type='file' name='kk_value' id='value-kk-plgn' /></td>
			<td><input type='checkbox' name='kosong_kk' id='kosong-kk' /><label for='kosong-kk'>Kosongkan</label></td>
         </tr>
         <tr>
	        <td><label for='value-slip-plgn'>Slip Gaji <?php echo"( $ket_slip )" ?></label></td><td><input type='file' name='slip_value' id='value-slip-plgn' /></td>
			<td><input type='checkbox' name='kosong_slip' id='kosong-slip' /><label for='kosong-slip'>Kosongkan</label></td>
         </tr>
    </table>
    </td>
</tr>
<tr>
	<td></td><td><input type='submit' value='Simpan'  class='button-class' /></td>
</tr>
</table>
</form>
<hr />
<?php } ?>