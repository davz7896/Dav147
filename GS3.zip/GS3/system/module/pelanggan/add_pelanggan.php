<?php
$rows_kode_plgn = mysql_num_rows(mysql_query("select*from t_pelanggan"));
$jum_kode_plgn = $rows_kode_plgn+1;
$kode_plgn_baru = "PLGN0".$jum_kode_plgn;
?>
<form method="post" action="proses/pelanggan/add_pelanggan.php" enctype="multipart/form-data">
<table cellpadding="5">
<tr>
	<td><label for='field-kode-plgn'>Kode</label></td>
    <td><input type='text' name='kode' class='input-field' id='field-kode-plgn' <?php echo"value='$kode_plgn_baru'"; ?> readonly /></td>
</tr>
<tr>
	<td><label for='field-nama-plgn'>Nama</label></td>
    <td><input type='text' name='nama' class='input-field' id='field-nama-plgn' placeholder='Nama Pelanggan' required /></td>
</tr>
<tr>
	<td><label for='field-telp-plgn'>Telepon / HP</label></td>
    <td><input type='number' name='telp' class='input-field' id='field-telp-plgn' placeholder='Telepon / HP' required /></td>
</tr>
<tr>
	<td valign="top"><label for='field-alamat-plgn'>Alamat</label></td>
    <td><textarea name='alamat' id='field-alamat-plgn' class='input-field' plaholder='Alamat' style='width:400px;height:100px'></textarea></td>
</tr>
<tr>
	<td><label for='field-no-ktp-plgn'>No KTP</label></td>
    <td><input type='number' name='no_ktp' class='input-field' id='field-no-ktp-plgn' placeholder='No KTP' required /></td>
</tr>
<tr>
	<td valign="top"><label>Berkas</label></td>
    <td>
    <table>
    	<tr>
	        <td><label for='value-ktp-plgn'>KTP</label></td><td><input type='file' name='ktp_value' id='value-ktp-plgn' /></td>
         </tr>
         <tr>
	        <td><label for='value-kk-plgn'>KK</label></td><td><input type='file' name='kk_value' id='value-kk-plgn' /></td>
         </tr>
         <tr>
	        <td><label for='value-slip-plgn'>Slip Gaji</label></td><td><input type='file' name='slip_value' id='value-slip-plgn' /></td>
         </tr>
    </table>
    </td>
</tr>
<tr>
	<td></td><td><input type='submit' value='Tambah'  class='button-class' /></td>
</tr>
</table>
</form>
<hr />