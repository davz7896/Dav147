<?php
$rows_data_pelanggan = mysql_num_rows(mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk where kode_pelanggan='$k' and stat_pelanggan='1'"));
$rows_angsuran_plgn = mysql_num_rows(mysql_query("select*from t_angsuran where kode_pelanggan='$k' and stat_angsuran='1'"));
if($rows_data_pelanggan==0 && $rows_angsuran_plgn>0){
	header("location:?m=404");
}else{
$data_edit_pembelian_plgn = mysql_fetch_array(mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk where kode_pelanggan='$k'"));
$nama_plgn = $data_edit_pembelian_plgn['nama_pelanggan'];
$dp_plgn = $data_edit_pembelian_plgn['uang_muka_pembelian'];
$dp_plgn_view = "Rp.".number_format($dp_plgn,0,",",".");
$merk_plgn = $data_edit_pembelian_plgn['kode_merk'];
$produk_plgn = $data_edit_pembelian_plgn['kode_produk'];
$cicilan_plgn = $data_edit_pembelian_plgn['stat_cicilan'];


$d_view_produk = mysql_fetch_array(mysql_query("select*from t_produk natural join t_merk where kode_produk='$produk_plgn' and stok_produk>0 and stat_produk='1'"));

$kode_merk_e = $d_view_produk['kode_merk'];
$nama_merk = $d_view_produk['nama_merk'];
$gambar_produk = $d_view_produk['gambar_produk'];
$nama_produk = $d_view_produk['nama_produk'];
$stok_produk = $d_view_produk['stok_produk'];
$harga_produk = $d_view_produk['harga_produk'];
$harga_produk_view = "Rp.".number_format($harga_produk,0,',','.');
$dp_produk = $d_view_produk['uang_muka_produk'];
$dp_produk_view = "Rp.".number_format($dp_produk,0,',','.');
$bunga_produk = $d_view_produk['bunga_produk'];
$desk_produk = $d_view_produk['desk_produk'];

$hasil_bunga_edit = ($bunga_produk/100) * $harga_produk;
$view_bunga_edit = "Rp.".number_format($hasil_bunga,0,',','.');

$bagi_cicilan_edit = ( $harga_produk - $dp_plgn ) / 10;
$hasil_cicilan_edit = "Rp.".number_format($bagi_cicilan_edit + $hasil_bunga_edit,0,',','.');

?>
<form method="post" action="proses/pelanggan/edit_data_pembelian.php">
<table width="100%" border='0'>
<tr>
<td>
<table cellpadding="5">
<tr>
	<td><label for='field-kode-plgn'>Kode</label></td>
    <td><input type='text' name='kode' class='input-field' id='field-kode-plgn' <?php echo"value='$k'"; ?> readonly /></td>
</tr>
<tr>
	<td><label for='field-nama-plgn'>Nama</label></td>
    <td><input type='text' name='nama' class='input-field' id='field-nama-plgn' <?php echo"value='$nama_plgn'"; ?> readonly /></td>
</tr>
<tr>
	<td><label>Merk</label></td>
    <td>
    	<select class='inp-pad' onChange="show_produk_buy(this.value)" style='float:left'>
        <option value='0'>-- Pilih Merk --</option>
        <?php
		$q_buy_merk = mysql_query("select*from t_merk where stat_merk='1' order by nama_merk");
		while($d_buy_merk = mysql_fetch_array($q_buy_merk)){
			$kode_buy_merk = $d_buy_merk['kode_merk'];
			$nama_buy_merk = $d_buy_merk['nama_merk'];
			$rows_produk_buy_merk = mysql_num_rows(mysql_query("select*from t_produk where kode_merk='$kode_buy_merk'"));
			if($rows_produk_buy_merk==0){
			}else{
				
				if(strcmp($kode_buy_merk,"$merk_plgn")==0){
					$sem = "selected";
				}else{
					$sem = "";
				}
				
				echo"<option value='$kode_buy_merk' $sem>$nama_buy_merk</option>";
			}
		}
		?>
        </select>
    </td>
</tr>
<tr>
	<td><label>Produk</label></td>
    <td>
    	<select name='produk' class='inp-pad' onchange="tampilkan_produk_pilihan(this.value)" id='pilihan-beli-produk' style='float:left'>
        <option value='0'>-- Pilih Kavling --</option>
        <?php
        $q_buy_produk = mysql_query("select*from t_produk where stat_produk='1' and kode_merk='$merk_plgn' order by nama_produk");
		while($d_buy_produk = mysql_fetch_array($q_buy_produk)){
			$kode_buy_produk = $d_buy_produk['kode_produk'];
			$nama_buy_produk = $d_buy_produk['nama_produk'];
			$rows_produk_buy_produk = mysql_num_rows(mysql_query("select*from t_produk where kode_produk='$kode_buy_produk'"));
				if(strcmp($kode_buy_produk,"$produk_plgn")==0){
					$sep = "selected";
				}else{
					$sep = "";
				}
				
				echo"<option value='$kode_buy_produk' $sep>$nama_buy_produk</option>";
		}
        ?>
        </select>
        <div id='load-ajax-field-beli-produk' style='float:left;margin-top:3px;margin-left:10px;height:25px'></div>
    </td>
</tr>
<tr>
	<td><label for='field-dp-plgn'>Uang Muka ( DP )</label></td>
    <td><input type='number' name='dp' class='input-field' id='field-dp-plgn' onkeyup="tampilkan_dp_pelanggan(this.value)" placeholder='Uang Muka ( DP )' required style='float:left;width:150px' value='<?php echo"$dp_plgn"; ?>'/>
     <div id='hasil-field-dp' style='float:left;margin-top:3px;margin-left:10px;height:25px'><?php echo"$dp_plgn_view"; ?></div>
    </td>
</tr>
<tr>
	<td><label>Cicilan</label></td>
    <td>
    <div id='hasil-bayar-dp-plgn'>
		<select name='cicilan' class='inp-pad' onchange="tampilkan_cicilan_pilihan(this.value)" id='pilihan-cicilan-produk' style='float:left'>
        	<option value='0'>-- Pilih Cicilan --</option>
            <?php
			$label_cicilan = array("","10","16","22","28","36");
			for($c=1;$c<=5;$c++){
				if($label_cicilan[$c]==$cicilan_plgn){
					echo"<option value='$label_cicilan[$c]' selected>$label_cicilan[$c]</option>";
				}else{
					echo"<option value='$label_cicilan[$c]'>$label_cicilan[$c]</option>";
				}
			}
            ?>
        </select>
        <div id='hasil-field-cicilan-produk' style='float:left;margin-top:3px;margin-left:10px;height:25px'><?php echo"$hasil_cicilan_edit"; ?></div>
    </div>
    </td>
</tr>
<tr>
	<td></td><td><input type='submit' value='Simpan' class='button-class' /></td>
</tr>
</table>
</td>
<td id='hasil-data-ajax-field-beli-produk' width='300px' height="350px">
<div id='tampilan-hasil-pilihan-produk'>
<?php
echo"
<img src='asset/produk/produk/$gambar_produk' width='150px' height='150px'>
<br><br>
<b>Merk :</b><br>
$nama_merk <br>
<b>Nama :</b><br>
$nama_produk <br>
<b>Harga :</b><br>
$harga_produk_view <br>
<div id='bunga-pilihan-pembelian' style='display:none'>$bunga_produk</div>
<div id='dp-pilihan-pembelian' style='display:none'>$dp_produk</div>
<div id='harga-pilihan-pembelian' style='display:none'>$harga_produk</div>
";
?>
</div>
</td>
</tr>
</table>
</form>
<br /><hr /><br />
<?php } ?>