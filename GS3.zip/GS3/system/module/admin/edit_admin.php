<?php
if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, anda tidak punya hak untuk halaman ini</h2></b></center>";
}else{
$rows_admin_edit = mysql_num_rows(mysql_query("select*from t_admin where id_admin='$k' and stat_admin='1'"));
if($rows_admin_edit==0){
	header("location:?m=404");
}else{
	$q_edit_admin = mysql_query("select*from t_admin where id_admin='$k'");
	$d_edit_admin = mysql_fetch_array($q_edit_admin);
	$username_edit_admin = $d_edit_admin['username_admin'];
	$nama_edit_admin = $d_edit_admin['nama_admin'];
	$level_edit_admin = $d_edit_admin['level_admin'];
?>
<form method="post" action="proses/admin/edit_admin.php">
<?php echo"<input type='hidden' name='id_admin' value='$k'>"; ?>
<table cellpadding="5">
<tr>
	<td><label for='field-username-admin'>Username</label></td>
    <td>
    	<input type='text' name='username' onkeyup="cek_username(this.value)" onchange="validasi_username(this.value)" class='input-field' id='field-username-admin' <?php echo"value='$username_edit_admin'"; ?> required style='float:left'>
        <div id='hasil-script-username' style='float:left; margin-left:10px'></div>
    </td>
</tr>
<tr>
	<td><label for='field-pass-admin'>Password</label></td>
    <td>
    <input type='password' name='pass' onkeyup="cek_password(this.value,this.value.length)" class='input-field' id='field-pass-admin' placeholder="Password" style='float:left'>
    <div id='hasil-script-pass' style='float:left; margin-left:10px'></div>
    </td>
</tr>
<tr>
	<td><label for='field-pass-confirm-admin'>Konfirmasi Password</label></td>
    <td><input type='password' name='konfirm' class='input-field' id='field-pass-confirm-admin' onchange="confirm_password()" placeholder="Konfirmasi Password" style='float:left'>
    <div id='hasil-script-confirm-pass' style='float:left; margin-left:10px'></div>
    </td>
</tr>
<tr>
	<td><label for='field-nama-admin'>Nama</label></td>
    <td><input type='text' name='nama' class='input-field' id='field-nama-admin' <?php echo"value='$nama_edit_admin'"; ?> required></td>
</tr>
<tr>
	<td><label>Level</label></td>
    <td>
    	<select name='level' class='input-field' id='field-level-admin' style='width:100px'>
        <?php
		$label_level_admin = array("","admin","user");
		for($l=1;$l<=2;$l++){
			
			if(strcmp($label_level_admin[$l],"$level_edit_admin")==0){
				$sela = "selected";
			}else{
				$sela = "";
			}
			
			echo"<option value='$label_level_admin[$l]' $sela>$label_level_admin[$l]</option>";
		}
		?>
        </select>
    </td>
</tr>
<tr>
	<td></td><td><input type='submit' value='Simpan' id='button-admin' class='button-class'></td>
</tr>
</table>
</form>
<br /><hr /><br />
<table class='table-data' width='100%' align="center" cellpadding="10" cellspacing="0" border='0'>
<tr class='table-data-header'>
	<th id='table-data-header-left'>No</th><th>Nama</th><th>Username</th><th>Level</th><th></th><th id='table-data-header-right'></th>
</tr>
<?php
$adm = 0;
$q_admin = mysql_query("select*from t_admin where stat_admin='1' order by nama_admin");
while($d_admin = mysql_fetch_array($q_admin)){
	$adm++;
	$id_admin = $d_admin['id_admin'];
	$username_admin = $d_admin['username_admin'];
	$nama_admin = $d_admin['nama_admin'];
	$level_admin = $d_admin['level_admin'];
	echo"
	<tr>
		<td valign='middle' align='center'>$adm</td>
		<td valign='middle' align='center'>$nama_admin</td>
		<td valign='middle' align='center'>$username_admin</td>
		<td valign='middle' align='center'>$level_admin</td>
		<td valign='middle' align='center' id='td-data-aksi-green'>
			<a href='?m=17&k=$id_admin' style='display:block'><img src='asset/icon/edit.png' width='25px' height='25px'></a>
		</td>
		<td valign='middle' align='center' id='td-data-aksi-red'>
			<a href='proses/admin/delete_admin.php?id=$id_admin' onclick='return confirm (\"Hapus Admin $nama_admin\")' style='display:block'><img src='asset/icon/delete.png' width='25px' height='25px'></a>
		</td>
	</tr>
	";
}
?>
<tr>
	<tr><th class='table-data-footer' colspan="6"></th></tr>
</tr>
</table>
<?php } } ?>