<?php
$jum_angsuran = mysql_num_rows(mysql_query("select*from t_angsuran"));
$jum_hal = ceil($jum_angsuran / 10);
if($p==1){
	$limit = 0;
}else{
	$limit = ( $p * 10 ) - 10;
}
?>
<form method="post" action="?m=23" style='float:right; height:50px; line-height:30px; margin-right:30px'>
<input type='text' name='cari' class='input-field' placeholder="Cari Pelanggan Untuk Pembayaran Angsuran" required />
<input type='submit' value='Cari' class='button-class' />
</form>
<div class='clr'></div>
<hr /><br />
<?php
	
	?>
    <table class='table-data' width='100%' align="center" cellpadding="10" cellspacing="0" border='0'>
    <tr class='table-data-header'>
        <th width='100px' id='table-data-header-left'>No</th><th>Pelanggan</th><th>Tanggal</th><th>Pegawai</th><th>Status</th><th id='table-data-header-right'>Denda</th>
    </tr>
    <tr>
    <?php
	$ags = $limit;
	$q_ags_plgn = mysql_query("select*from t_angsuran natural join t_admin order by kode_angsuran desc limit $limit,10");
	while($d_ags_plgn = mysql_fetch_array($q_ags_plgn)){
		$ags++;
		$kode_pelanggan_ags = $d_ags_plgn['kode_pelanggan'];
		$d_plgn_ags = mysql_fetch_array(mysql_query("select*from t_pelanggan where kode_pelanggan='$kode_pelanggan_ags'"));
		$pelanggan_ags = $d_plgn_ags['nama_pelanggan'];
		$kode_ags = $d_ags_plgn['kode_angsuran'];
		$tanggal_ags = $d_ags_plgn['tgl_angsuran'];
		$denda_ags = "Rp.".number_format($d_ags_plgn['denda_angsuran'],0,",",".");
		$plode_tanggal_ags = explode("-",$tanggal_ags);
		$tgl_ags = $plode_tanggal_ags[2];
		$bulan_ags = $plode_tanggal_ags[1];
		$th_ags = $plode_tanggal_ags[0];
		$nama_admin_ags = $d_ags_plgn['nama_admin'];
		$stat_ags = $d_ags_plgn['stat_bayar_angsuran'];
		
		if($stat_ags==1){
			$ket_stat = "Tepat Waktu";
		}else{
			$ket_stat = "Terlambat";
		}
		
		echo"
		<tr>
			<td valign='middle' align='center'>$ags</td>
			<td valign='middle' align='center'><a href='?m=20&k=$kode_pelanggan_ags'>$pelanggan_ags</a></td>
			<td valign='middle' align='right'>$tgl_ags-$bulan_ags-$th_ags</td>
			<td valign='middle' align='center'>$nama_admin_ags</td>
			<td valign='middle' align='center'>$ket_stat</td>
			<td>$denda_ags</td>
		</tr>
		";
	}
	?>
	<tr><th class='table-data-footer' colspan="6"></th></tr>
	</tr>
    </table>
    <br /><div class='clr'></div><br />
<div id='paging-left'>
<b>Halaman : </b>
<select class='inp-pad' onchange="direct_page(this.value)">
<?php
for($h=1;$h<=$jum_hal;$h++){
	if($h==$p){
		echo"<option value='?m=$m&p=$h' selected>$h</option>";
	}else{
		echo"<option value='?m=$m&p=$h'>$h</option>";
	}
}
?>
</select>
</div>
<div id='paging-right'>
<?php
if($jum_hal<=1){
}else if($p==$jum_hal){
	$min_p = $p - 1;
	echo"<a href='?m=$m&p=$min_p' id='prev-paging'><img src='asset/icon/prev.png' /></a>";
}else if($p==1){
	$plus_p = $p + 1;
	echo"<a href='?m=$m&p=$plus_p' id='next-paging'><img src='asset/icon/next.png' /></a>";
}else{
	$plus_p = $p + 1;
	$min_p = $p - 1;
	echo"<a href='?m=$m&p=$min_p' id='prev-paging'><img src='asset/icon/prev.png' /></a>";
	echo"<a href='?m=$m&p=$plus_p' id='next-paging'><img src='asset/icon/next.png' /></a>";
}
?>
</div>
<div class='clr'></div>