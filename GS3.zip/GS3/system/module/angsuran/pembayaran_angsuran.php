<?php
$rows_data_pelanggan = mysql_num_rows(mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk where kode_pelanggan='$k' and stat_pelanggan='1'"));
$rows_angsuran_plgn = mysql_num_rows(mysql_query("select*from t_angsuran where kode_pelanggan='$k' and stat_angsuran='1'"));
if($rows_data_pelanggan==0 && $rows_angsuran_plgn>0){
	header("location:?m=404");
}else{
$data_angsuran_plgn = mysql_fetch_array(mysql_query("select*from t_pelanggan natural join t_pembelian natural join t_produk natural join t_merk where kode_pelanggan='$k'"));
$nama_plgn = $data_angsuran_plgn['nama_pelanggan'];
$merk_plgn = $data_angsuran_plgn['nama_merk'];
$produk_plgn = $data_angsuran_plgn['nama_produk'];
$stat_cicilan_plgn = $data_angsuran_plgn['stat_cicilan'];
$jum_angsuran = $rows_angsuran_plgn+1;
$dp_produk_plgn = $data_angsuran_plgn['uang_muka_pembelian'];
$hasil_cicilan_plgn = $data_angsuran_plgn['hasil_cicilan'];
$bunga_produk_plgn = $data_angsuran_plgn['bunga_produk'];
$harga_produk_plgn = $data_angsuran_plgn['harga_produk'];
$sisa_angsuran = $data_angsuran_plgn['sisa_pembayaran'];

$rows_angsuran_plgn = mysql_num_rows(mysql_query("select*from t_angsuran where kode_pelanggan='$k' and stat_angsuran='1'"));

if($rows_angsuran_plgn==$stat_cicilan_plgn){
			if($sisa_angsuran<=0){
				header("location:?m=20&k=$k");
			}else{
			if($dp_plgn==$harga_produk_plgn){
				header("location:?m=20&k=$k");
			}else{
				$stat_angsuran_plgn = "Masa Angsuran";
			}

			}
		}else{
			$stat_angsuran_plgn = "Masa Angsuran";
		}

$hasil_bunga_plgn = ($bunga_produk_plgn/100) * ($harga_produk_plgn-$dp_produk_plgn);
$bagi_cil = ($harga_produk_plgn-$dp_produk_plgn) / $stat_cicilan_plgn;
$hasil_cil = "Rp.".number_format($hasil_cicilan_plgn,0,',','.');
$hasil_cicilan = $bagi_cil + $hasil_bunga_plgn;

$batas_bayar_plgn = $data_angsuran_plgn['batas_bayar'];
$plode_batas_bayar = explode("-",$batas_bayar_plgn); 
$tgl_batas_bayar = $plode_batas_bayar[0];
$bulan_batas_bayar = $plode_batas_bayar[1];
$th_batas_bayar = $plode_batas_bayar[2];

$tgl_skrg_ags = date("d");
$bulan_skrg_ags = date("n");
$th_skrg_ags = date("Y");

if($th_skrg_ags>=$th_batas_bayar && $bulan_skrg_ags>=$bulan_batas_bayar && $tgl_skrg_ags>$tgl_batas_bayar){
	if($th_skrg_ags>$th_batas_bayar){
		if($th_batas_bayar % 4 == 0){
			$penambahan_waktu = 366;
		}else{
			$penambahan_waktu = 365;
		}
	}else{
		$penambahan_waktu = 0;
	}
	$awal_waktu_denda = date("z",strtotime($batas_bayar_plgn))+1;
	$akhir_waktu_denda = date("z",strtotime($tgl_skrg_ags-$bulan_skrg_ags-$th_skrg_ags))+1;
	$denda_plgn = ( $akhir_waktu_denda - ( $awal_waktu_denda + $penambahan_waktu ) ) * (0.5 / 100 ) * $hasil_cicilan;
	$view_denda_plgn = "Rp.".number_format($denda_plgn,0,",",".");
	
	if(($akhir_waktu_denda - ($awal_waktu_denda + $penambahan_waktu))>90){
		echo"
		<script type='text/javascript'>
		alert('Blacklist');
		document.location='?m=20&k=$k';
		</script>
		";
	}else{
		$ket_bayar = "Terlambat";
	}
}else{
	$ket_bayar = "Tepat Waktu";
	$denda_plgn = 0;
	$view_denda_plgn = "Rp.".number_format($denda_plgn,0,",",".");
}
?>
<h3>
<?php echo"Angsuran ke $jum_angsuran ( $hasil_cil ) , dengan status : $ket_bayar untuk"; ?>
</h3>
<form method="post" action="proses/angsuran/add_angsuran.php">
<?php echo"<input type='hidden' name='bayaran' value='$hasil_cicilan_plgn'>"; ?>
<table cellpadding="5">
<tr>
	<td width='150px'><label for='kode-plgn-ags'>Kode Pelanggan</label></td>
    <td><input type='text' name='kode' class='input-field' id='kode-plgn-ags' <?php echo"value='$k'"; ?> readonly /></td>
</tr>
<tr>
	<td><label for='nama-plgn-ags'>Nama Pelanggan</label></td>
    <td><input type='text' name='nama' class='input-field' id='nama-plgn-ags' <?php echo"value='$nama_plgn'"; ?> readonly /></td>
</tr>
<tr>
	<td><label for='produk-plgn-ags'>Nama Produk</label></td>
    <td>
    	<input type='text' name='produk' class='input-field' id='nama-plgn-ags' <?php echo"value='$merk_plgn $produk_plgn'"; ?> readonly />
    </td>
</tr>
<tr>
	<td><label for='denda-plgn-ags'>Denda</label></td>
    <td>
    	<input type='hidden' name='denda' <?php echo"value='$denda_plgn'"; ?>/>
        <?php echo"$view_denda_plgn"; ?>
    </td>
</tr>
<tr>
	<td></td>
    <td>
    	<input type='submit' value='Kirim' class='button-class'/>
        <input type='button' value='Batal' class='button-class' onclick="direct_page('<?php echo"?m=20&k=$k"; ?>')" />
    </td>
</tr>
</table>
</form>
<?php } ?>