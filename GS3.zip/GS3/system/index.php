<?php
session_start();

include("plugin/php/config.php");
include("plugin/php/mydata.php");
include("plugin/php/variable_data.php");
include("plugin/php/fungsi_program.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href='plugin/css/style2.css' rel='stylesheet' type='text/css' />
<link href='plugin/css/style.java.css' rel='stylesheet' type='text/css' />
<link href='plugin/css/style.content.css' rel='stylesheet' type='text/css' />
<link href='asset/icon/favicon.png' rel='icon' type='icon/png' />
<title>
<?php getTitle($m); ?>
 | Aplikasi Pembelian Rumah Milineal Regency
</title>
<script src='plugin/javascript/jquery.js' type='text/javascript'></script>
<script src='plugin/javascript/accounting.js' type='text/javascript'></script>
<script src='plugin/javascript/ajax.web.js' type='text/javascript'></script>
<script src='plugin/javascript/javascript.content.js' type='text/javascript'></script>
</head>

<body onload="jum_data_notif()">
<textarea id='printing-css' style='display:none;'>
.no-print{display:none} 
#div-cetak-dp{display:block;} 
#div-cetak{display:block} 
#print-data-angsuran{border:1px solid #000;}
#laporan-ags-plgn{display:block)
</textarea>
<iframe id='printing-frame' name='print_frame' src='about:blank' style='display:none;'></iframe>
<div id='overlay'></div>
<div id='notif-lay' onclick="show_notif(), show_data_notif()"></div>
<div class='page'>
<div class='header'>
    <div class='banner'>
    <a href='?m=15'></a>
    </div>
    <div class='menu'>
    	<?php getMenu(); ?>
        <div class='tanggal-web'><?php getTanggal(); ?></div>
        <div class='clr'></div>

    </div>
</div>
<div class='content'>
<?php getJudul($m,$nama_perusahaan); ?>
<?php getHalaman($m,$p,$k,$data_level_admin,$nama_perusahaan,$alamat_perusahaan); ?>
</div>
<div class='footer'>
	<?php namaPerusahaan($nama_perusahaan); ?>
    <div class='data-footer'><?php footerData($alamat_perusahaan,$telp_perusahaan,$mail_perusahaan,$web_perusahaan); ?></div>
    <div class='clr'></div>
</div>
</div>
</body>
</html>