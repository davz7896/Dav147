<title>Redirect...</title>
<?php
session_start();
$admin = $_SESSION['admin'];
include("../../plugin/php/config.php");
include("../../plugin/php/fungsi_program.php");
include("../../plugin/php/admindata.php");

if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, anda tidak punya hak untuk proses ini</h2></b></center>";
	header("refresh:1; url=../../?m=2");
}else{

$merk = mysql_real_escape_string($_POST['merk']);
$kode_produk = mysql_real_escape_string($_POST['kode']);
$nama_produk = mysql_real_escape_string(str_replace("'","`",$_POST['nama']));
$stok_produk = mysql_real_escape_string($_POST['stok']);
$l_tanah = mysql_real_escape_string($_POST['l_tanah']);
$l_bangunan = mysql_real_escape_string($_POST['l_bangunan']);
$tipe = mysql_real_escape_string($_POST['tipe']);
$posisi = mysql_real_escape_string($_POST['posisi']);
$harga_produk = mysql_real_escape_string($_POST['harga']);
$dp_produk = mysql_real_escape_string($_POST['dp']);
$bunga_produk = mysql_real_escape_string($_POST['bunga']);
$desk_produk = str_replace("'","`",$_POST['desk']);

if(isset($_POST['vimage'])){

	$tmp = $_FILES['gambar']['tmp_name'];
	$source = $_FILES['gambar']['name'];
	$direct = "../../asset/produk/produk/$kode_produk-$source";
		
	//compress($tmp,$direct,30);
	
	$move = is_uploaded_file(move_uploaded_file($tmp,"$direct"));
	
	if($move==0){
	
		$sql = mysql_query("update t_produk set
		kode_merk='$merk', 
		gambar_produk='$kode_produk-$source',
		nama_produk='$nama_produk',
		l_tanah='$l_tanah',
		l_bangunan='$l_bangunan',
		tipe='$tipe',
		posisi='$posisi',
		harga_produk='$harga_produk',
		uang_muka_produk='0',
		bunga_produk='$bunga_produk',
		desk_produk='$desk_produk'
		where kode_produk='$kode_produk' and stat_produk='1'
		");
	}else{
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Kavling Gagal Di Edit</div>";
		header("refresh:1; url=../../?m=13&k=$kode_produk");
	}
}else{
	$sql = mysql_query("update t_produk set 
	kode_merk='$merk', 
	nama_produk='$nama_produk',
	l_tanah='$l_tanah',
	l_bangunan='$l_bangunan',
	tipe='$tipe',
	posisi='$posisi',
	stok_produk='$stok_produk',
	harga_produk='$harga_produk',
	uang_muka_produk='0',
	bunga_produk='$bunga_produk',
	desk_produk='$desk_produk'
	where kode_produk='$kode_produk' and stat_produk='1'
	");
}
if($sql){
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Kavling Berhasil Di Edit</div>";
	header("refresh:1; url=../../?m=13&k=$kode_produk");
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Kavling Gagal Di Edit</div>";
	header("refresh:1; url=../../?m=13&k=$kode_produk");
}
}
?>