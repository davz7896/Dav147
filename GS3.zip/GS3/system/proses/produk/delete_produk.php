<title>Redirect...</title>
<?php
session_start();
$admin = $_SESSION['admin'];
include("../../plugin/php/config.php");
include("../../plugin/php/admindata.php");
if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, anda tidak punya hak untuk proses ini</h2></b></center>";
	header("refresh:1; url=../../?m=2");
}else{

$id = mysql_real_escape_string($_GET['id']);

$data = mysql_fetch_array(mysql_query("select*from t_produk natural join t_merk where kode_produk='$id'"));
$merk = $data['nama_merk'];
$nama = $data['nama_produk'];

$hapus = mysql_query("update t_produk set stat_produk='0' where kode_produk='$id'");

if($hapus){
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Produk $merk $nama Berhasil Di Hapus</div>";
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Produk $merk $nama Gagal Di Hapus</div>";
}

header("refresh:1; url=../../?m=2");
}
?>