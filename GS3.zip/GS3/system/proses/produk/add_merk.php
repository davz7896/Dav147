<title>Redirect...</title>
<?php
session_start();
$admin = $_SESSION['admin'];

include("../../plugin/php/config.php");
include("../../plugin/php/fungsi_program.php");
include("../../plugin/php/admindata.php");

if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, anda tidak punya hak untuk proses ini</h2></b></center>";
	header("refresh:1; url=../../?m=2");
}else{


$kode_merk = mysql_real_escape_string($_POST['kode']);
$nama_merk = mysql_real_escape_string(str_replace("'","`",$_POST['nama']));

$tmp = $_FILES['gambar']['tmp_name'];
$source = $_FILES['gambar']['name'];
$direct = "../../asset/produk/merk/$kode_merk-$source";
	
//compress($tmp,$direct,30);
	
$move = is_uploaded_file(move_uploaded_file($tmp,"$direct"));


if($move==0){

	$sql = mysql_query("insert into t_merk values ('$kode_merk','$kode_merk-$source','$nama_merk','1')");
		
	if($sql){
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Perumahan Baru Berhasil Di Tambah</div>";
		header("refresh:1; url=../../?m=11&k=$kode_merk");
	}else{
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Perumahan Gagal Di Tambah</div>";
		header("refresh:1; url=../../?m=7");
	}
	
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Perumahan Gagal Di Tambah</div>";
	header("refresh:1; url=../../?m=7");
}
}
?>