<title>Redirect...</title>
<?php
session_start();
$admin = $_SESSION['admin'];
include("../../plugin/php/config.php");
include("../../plugin/php/admindata.php");

if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, anda tidak punya hak untuk proses ini</h2></b></center>";
	header("refresh:1; url=../../?m=1");
}else{

$id_admin = mysql_real_escape_string($_POST['id_admin']);
$username = mysql_real_escape_string($_POST['username']);
$pass = mysql_real_escape_string(md5($_POST['pass']));
$konfirm = mysql_real_escape_string(md5($_POST['konfirm']));
$nama = mysql_real_escape_string(str_replace("'","`",$_POST['nama']));
$level = mysql_real_escape_string($_POST['level']);



$rows_admin = mysql_num_rows(mysql_query("select*from t_admin"));
$jum_admin = $rows_admin+1;


if(isset($pass)){
	if(!strcmp($pass,"$konfirm")==0){
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin Gagal Di Edit</div>";
		header("refresh:1; url=../../?m=17&k=$id_admin");
	}else{
		$sql = mysql_query("update t_admin set username_admin='$username',pass_admin='$pass',nama_admin='$nama',level_admin='$level' where id_admin='$id_admin'");
		if($sql){
			echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin Berhasil Di Edit</div>";
			header("refresh:1; url=../../?m=17&k=$id_admin");
		}else{
			echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin Gagal Di Edit</div>";
			header("refresh:1; url=../../?m=17&k=$id_admin");
		}

	}
}else{
	$sql = mysql_query("update t_admin set username_admin='$username',nama_admin='$nama',level_admin='$level' where id_admin='$id_admin'");
	if($sql){
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin Berhasil Di Edit</div>";
		header("refresh:1; url=../../?m=17&k=$id_admin");
	}else{
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Admin Gagal Di Edit</div>";
		header("refresh:1; url=../../?m=17&k=$id_admin");
	}
}

}
?>