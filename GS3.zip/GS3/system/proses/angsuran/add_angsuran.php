<title>Redirect...</title>
<?php
session_start();
$admin = $_SESSION['admin'];
include("../../plugin/php/config.php");

$kode = mysql_real_escape_string($_POST['kode']);
$bayaran = mysql_real_escape_string($_POST['bayaran']);
$denda = mysql_real_escape_string($_POST['denda']);

$tanggal = date("Y-m-d");

$data_batas = mysql_fetch_array(mysql_query("select*from t_pembelian where kode_pelanggan='$kode' and stat_beli='1'"));
$tgl_batas = $data_batas['batas_bayar'];
$pecah_batas = explode("-",$tgl_batas);
$bulan_skrg = $pecah_batas[1];
$th_skrg = $pecah_batas[2];

if($bulan_skrg==12){
	$th_value = $th_skrg + 1;
}else{
	$th_value = $th_skrg;
}

if($bulan_skrg==12){
	$bulan_value = 1;
}else{
	$bulan_value = $bulan_skrg + 1;
}

$data_bayar_plgn = mysql_fetch_array(mysql_query("select*from t_pembelian where kode_pelanggan='$kode' and stat_beli='1'"));
$batas_bayar_plgn = $data_bayar_plgn['batas_bayar'];

$plode_batas_bayar = explode("-",$batas_bayar_plgn); 
$tgl_batas_bayar = $plode_batas_bayar[0];
$bulan_batas_bayar = $plode_batas_bayar[1];
$th_batas_bayar = $plode_batas_bayar[2];

$tgl_skrg_ags = date("d");
$bulan_skrg_ags = date("m");
$th_skrg_ags = date("Y");

if($th_skrg_ags>=$th_batas_bayar && $bulan_skrg_ags>=$bulan_batas_bayar && $tgl_skrg_ags>$tgl_batas_bayar){
	$ket_bayar = 0;
}else{
	$ket_bayar = 1;
	$denda_plgn = $bayaran * (0.5 / 100) * $date;
}

$kurangi_sisa = mysql_query("update t_pembelian set sisa_pembayaran=sisa_pembayaran-$bayaran where kode_pelanggan='$kode'");
$beli = mysql_query("update t_pembelian set bayar_terakhir='$tgl_skrg_ags-$bulan_skrg_ags-$th_skrg_ags',batas_bayar='10-$bulan_value-$th_value' where kode_pelanggan='$kode'"); 
$sql = mysql_query("insert into t_angsuran values ('','$kode','$admin','$tanggal','$denda','$ket_bayar','1')");

if($sql && $beli && $kurangi_sisa){
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Terima Kasih, Pembayaran Berhasil</div>";
	header("refresh:1; url=../../?m=20&k=$kode");
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Maaf, Pembayaran Gagal</div>";
	header("refresh:1; url=../../?m=24&k=$kode");
}

?>