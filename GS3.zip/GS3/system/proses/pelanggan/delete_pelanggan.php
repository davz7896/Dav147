<title>Redirect...</title>
<?php
include("../../plugin/php/config.php");

$id = mysql_real_escape_string($_GET['id']);

$rows_angsuran = mysql_num_rows(mysql_query("select*from t_angsuran where kode_pelanggan='$id'"));
$data_pelanggan = mysql_fetch_array(mysql_query("select*from t_pelanggan where kode_pelanggan='$id'"));
$nama_pelanggan = $data_pelanggan['nama_pelanggan'];

if($rows_angsuran==0){
	$produk = mysql_query("update t_produk set stok_produk=stok_produk+1 where kode_produk='$kode'");
	$plgn = mysql_query("update t_pelanggan set stat_pelanggan='0' where kode_pelanggan='$id'");
	$beli = mysql_query("update t_pembelian set stat_beli='0' where kode_pelanggan='$id'");
	
	if($plgn && $beli && $produk){
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pelanggan $nama_pelanggan Berhasil Di Hapus</div>";
	}else{
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pelanggan $nama_pelanggan Gagal Di Hapus</div>";
	}
	
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pelanggan $nama_pelanggan Gagal Di Hapus</div>";
}

header("refresh:1; url=../../?m=3");
?>