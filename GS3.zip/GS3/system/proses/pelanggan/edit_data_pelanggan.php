<title>Redirect...</title>
<?php
include("../../plugin/php/config.php");

$kode = mysql_real_escape_string($_POST['kode']);
$nama = mysql_real_escape_string(str_replace("'","`",$_POST['nama']));
$telp = mysql_real_escape_string($_POST['telp']);
$alamat = mysql_real_escape_string(str_replace("'","`",$_POST['alamat']));
$no_ktp = mysql_real_escape_string($_POST['no_ktp']);

$data_edit_plgn = mysql_fetch_array(mysql_query("select*from t_pelanggan where kode_pelanggan='$kode'"));
$berkas_ktp_plgn = $data_edit_plgn['berkas_ktp'];
$berkas_kk_plgn = $data_edit_plgn['berkas_kk'];
$berkas_slip_plgn = $data_edit_plgn['berkas_slip'];

if(!isset($_POST['kosong_ktp'])){
if(!empty($_FILES['ktp_value']['name'])){
		$tmp_ktp = $_FILES['ktp_value']['tmp_name'];
		$nama_ktp = $_FILES['ktp_value']['name'];
		$dir_ktp = "../../asset/berkas/ktp/ktp-$kode-$nama_ktp";
		$move_ktp = is_uploaded_file(move_uploaded_file($tmp_ktp,"$dir_ktp"));
		if($move_ktp==0){
			$ktp_value = "ktp-$kode-$nama_ktp";
		}else{
			if(strcmp($berkas_ktp_plgn,"kosong")==0){
				$ktp_value = "kosong";
			}else{
				$ktp_value = "$berkas_ktp_plgn";
			}
		}
}else{
		if(strcmp($berkas_ktp_plgn,"kosong")==0){
			$ktp_value = "kosong";
		}else{
			$ktp_value = "$berkas_ktp_plgn";
		}
}
}else{
	$ktp_value = "kosong";
}

if(!isset($_POST['kosong_kk'])){

	if(!empty($_FILES['kk_value']['name'])){
			$tmp_kk = $_FILES['kk_value']['tmp_name'];
			$nama_kk = $_FILES['kk_value']['name'];
			$dir_kk = "../../asset/berkas/kk/kk-$kode-$nama_kk";
			$move_kk = is_uploaded_file(move_uploaded_file($tmp_kk,"$dir_kk"));
			if($move_kk==0){
				$kk_value = "kk-$kode-$nama_kk";
			}else{
				if(strcmp($berkas_kk_plgn,"kosong")==0){
					$kk_value = "kosong";
				}else{
					$kk_value = "$berkas_kk_plgn";
				}
			}
	}else{
			if(strcmp($berkas_kk_plgn,"kosong")==0){
				$kk_value = "kosong";
			}else{
				$kk_value = "$berkas_kk_plgn";
			}
	}
}else{
	$kk_value = "kosong";
}
if(!isset($_POST['kosong_slip'])){

if(!empty($_FILES['slip_value']['name'])){
		$tmp_slip = $_FILES['slip_value']['tmp_name'];
		$nama_slip = $_FILES['slip_value']['name'];
		$dir_slip = "../../asset/berkas/slip/slip-$kode-$nama_slip";
		$move_slip = is_uploaded_file(move_uploaded_file($tmp_slip,"$dir_slip"));
		if($move_slip==0){
			$slip_value = "slip-$kode-$nama_slip";
		}else{
			if(strcmp($berkas_slip_plgn,"kosong")==0){
				$slip_value = "kosong";
			}else{
				$slip_value = "$berkas_slip_plgn";
			}
		}
}else{
		if(strcmp($berkas_slip_plgn,"kosong")==0){
			$slip_value = "kosong";
		}else{
			$slip_value = "$berkas_slip_plgn";
		}
}
}else{
				$slip_value = "kosong";

}

$sql = mysql_query("
update t_pelanggan set
nama_pelanggan='$nama',
telp_pelanggan='$telp',
alamat_pelanggan='$alamat',
no_ktp_pelanggan='$no_ktp',
berkas_ktp='$ktp_value',
berkas_kk='$kk_value',
berkas_slip='$slip_value'
where kode_pelanggan='$kode'
");

if($sql){
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pelanggan Berhasil Di Edit</div>";
	header("refresh:1; url=../../?m=20&k=$kode");
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pelanggan Gagal Di Edit</div>";
	header("refresh:1; url=../../?m=20&k=$kode");
}

?>