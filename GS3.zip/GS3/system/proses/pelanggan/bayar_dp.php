<title>Redirect...</title>
<?php
include("../../plugin/php/config.php");

$kode = mysql_real_escape_string($_POST['kode']);
$dp = mysql_real_escape_string($_POST['dp']);

$sql = mysql_query("update t_pembelian natural join t_pelanggan set uang_muka_pembelian=uang_muka_pembelian+$dp where kode_pelanggan='$kode' and stat_pelanggan='1' and stat_beli='1'");

if($sql){
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pembayaran Berhasil</div>";
	header("refresh:1; url=../../?m=20&k=$kode&d=1&n=$dp");
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pembayaran Gagal</div>";
	header("refresh:1; url=../../?m=20&k=$kode&d=0");
}
?>