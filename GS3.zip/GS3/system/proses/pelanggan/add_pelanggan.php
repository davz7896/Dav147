<title>Redirect...</title>
<?php
session_start();
$admin = $_SESSION['admin'];
include("../../plugin/php/config.php");
include("../../plugin/php/admindata.php");

$tanggal = date("Y-m-d");

$kode = mysql_real_escape_string($_POST['kode']);
$nama = mysql_real_escape_string(str_replace("'","`",$_POST['nama']));
$telp = mysql_real_escape_string($_POST['telp']);
$alamat = mysql_real_escape_string(str_replace("'","`",$_POST['alamat']));
$no_ktp = mysql_real_escape_string($_POST['no_ktp']);

if(!empty($_FILES['ktp_value']['name'])){
	$tmp_ktp = $_FILES['ktp_value']['tmp_name'];
	$nama_ktp = $_FILES['ktp_value']['name'];
	$dir_ktp = "../../asset/berkas/ktp/ktp-$kode-$nama_ktp";
	$move_ktp = is_uploaded_file(move_uploaded_file($tmp_ktp,"$dir_ktp"));
	if($move_ktp==0){
		$ktp_value = "ktp-$kode-$nama_ktp";
	}else{
		$ktp_value = "kosong";
	}
}else{
	$ktp_value= "kosong";
}

if(!empty($_FILES['kk_value']['name'])){
	$tmp_kk = $_FILES['kk_value']['tmp_name'];
	$nama_kk = $_FILES['kk_value']['name'];
	$dir_kk = "../../asset/berkas/kk/kk-$kode-$nama_kk";
	$move_kk = is_uploaded_file(move_uploaded_file($tmp_kk,"$dir_kk"));
	if($move_kk==0){
		$kk_value = "kk-$kode-$nama_kk";
	}else{
		$kk_value = "kosong";
	}
}else{
	$kk_value= "kosong";
}

if(!empty($_FILES['slip_value']['name'])){
	$tmp_slip = $_FILES['slip_value']['tmp_name'];
	$nama_slip = $_FILES['slip_value']['name'];
	$dir_slip = "../../asset/berkas/slip/slip-$kode-$nama_slip";
	$move_slip = is_uploaded_file(move_uploaded_file($tmp_slip,"$dir_slip"));
	if($move_slip==0){
		$slip_value = "slip-$kode-$nama_slip";
	}else{
		$slip_value = "kosong";
	}
}else{
	$slip_value= "kosong";
}

$sql = mysql_query("insert into t_pelanggan values ('$kode','$admin','$tanggal','$nama','$telp','$alamat','$no_ktp','$ktp_value','$kk_value','$slip_value','1')");

if($sql){
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Customer Berhasil Di Tambah</div>";
	header("refresh:1; url=../../?m=19&k=$kode");
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Customer Gagal Di Tambah</div>";
	header("refresh:1; url=../../?m=18");
}

?>