<title>Redirect...</title>
<?php
include("../../plugin/php/config.php");

$kode = mysql_real_escape_string($_POST['kode']);
$produk = mysql_real_escape_string($_POST['produk']);
$dp = mysql_real_escape_string($_POST['dp']);
$sisaku = mysql_real_escape_string($_POST['sisaku']);



if(!isset($_POST['cicilan'])){
	$cicilan = 0;
}else{
	$cicilan = mysql_real_escape_string($_POST['cicilan']);
}

$hasil_sisa = $sisaku * $cicilan;

$data_produkku = mysql_fetch_array(mysql_query("select*from t_produk where kode_produk='$produk'"));
$harga_produkku = $data_produkku['harga_produk'];

$tgl_skrg = date("d");
$bulan_skrg = date("m");
$th_skrg = date("Y");

if($bulan_skrg==12){
	$th_value = $th_skrg + 1;
}else{
	$th_value = $th_skrg;
}

if($bulan_skrg==12){
	$bulan_value = 1;
}else{
	$bulan_value = $bulan_skrg + 1;S
}

if($dp<=$harga_produkku){
	$produk_query = mysql_query("update t_produk set stok_produk=stok_produk-1 where kode_produk='$produk'");
	
	$sql = mysql_query("update t_pembelian set kode_produk='$produk',uang_muka_pembelian='$dp',hasil_cicilan='$sisaku',sisa_pembayaran='$hasil_sisa',stat_cicilan='$cicilan',stat_beli='1',batas_bayar='$tgl_skrg-$bulan_value-$th_value' where kode_pelanggan='$kode' and stat_beli='0'");
	
	if($sql && $produk_query){
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pembelian Berhasil</div>";
		header("refresh:1; url=../../?m=20&k=$kode");
	}else{
		echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pembelian Gagal</div>";
		header("refresh:1; url=../../?m=19&k=$kode");
	}
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Pembelian Gagal</div>";
	header("refresh:1; url=../../?m=19&k=$kode");
}
?>