\<title>Redirect...</title>
<?php
include("../../plugin/php/config.php");

$kode = mysql_real_escape_string($_POST['kode']);
$produk = mysql_real_escape_string($_POST['produk']);
$cicilan = mysql_real_escape_string($_POST['cicilan']);
$dp = mysql_real_escape_string($_POST['dp']);

$data_edit = mysql_fetch_array(mysql_query("select*from t_pembelian where kode_pelanggan='$kode'"));
$kode_produk_edit = $data_edit['kode_produk'];


$sql = mysql_query("update t_pembelian set kode_produk='$produk',stat_cicilan='$cicilan',uang_muka_pembelian='$dp' where kode_pelanggan='$kode'");

if($sql){
	if(!strcmp($produk,"$kode_produk_edit")==0){
		$tambah_edit = mysql_query("update t_produk set stok_produk=stok_produk+1 where kode_produk='$kode_produk_edit'");
		$kurang_edit = mysql_query("update t_produk set stok_produk=stok_produk-1 where kode_produk='$produk'");
	}else{
	}
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Edit Pembelian Berhasil</div>";
	header("refresh:1; url=../../?m=20&k=$kode");
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Edit Pembelian Gagal</div>";
	header("refresh:1; url=../../?m=20&k=$kode");
}
?>