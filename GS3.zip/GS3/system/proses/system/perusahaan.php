<title>Redirect...</title>
<?php
session_start();
$admin = $_SESSION['admin'];

include("../../plugin/php/config.php");
include("../../plugin/php/fungsi_program.php");
include("../../plugin/php/admindata.php");

if(!strcmp($data_level_admin,"admin")==0){
	echo"<br><br><center><b><h2>Maaf, and tidak punya hak untuk proses ini</h2></b></center>";
	header("refresh:1; url=../../?m=1");
}else{

$nama = str_replace("'","`",$_POST['nama']);
$alamat = str_replace("'","`",$_POST['alamat']);
$telp = str_replace("'","`",$_POST['telp']);
$mail = str_replace("'","`",$_POST['mail']);
$web = str_replace("'","`",$_POST['web']);

/*
if((isset($_POST['bimagec'])) && (isset($_POST['gimagec']))){
	$tmp_g = $_FILES['gimage']['tmp_name'];
	$direct_g = "../../asset/image/foto-perusahaan.jpg";		
	compress($tmp_g,$direct_g,30);

	$tmp_b = $_FILES['bimage']['tmp_name'];
	$direct_b = "../../asset/image/banner-perusahaan.jpg";		
	$move = is_uploaded_file(move_uploaded_file($tmp_b,"$direct_b"));
}else if(isset($_POST['gimagec'])){
	$tmp_g = $_FILES['gimage']['tmp_name'];
	$direct_g = "../../asset/image/foto-perusahaan.jpg";		
	compress($tmp_g,$direct_g,30);
}else if(isset($_POST['bimagec'])){
	$tmp_b = $_FILES['bimage']['tmp_name'];
	$direct_b = "../../asset/image/banner-perusahaan.jpg";		
	$move = is_uploaded_file(move_uploaded_file($tmp_b,"$direct_b"));	
}else{
}
*/

$sql = mysql_query("update t_perusahaan set 
					nama_perusahaan='$nama',
					alamat_perusahaan='$alamat',
					telp_perusahaan='$telp',
					mail_perusahaan='$mail',
					web_perusahaan='$web'
					where kode_perusahaan='si_kredit'");
					
if($sql){
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Data Perusahaan Berhasil Di Edit</div>";
}else{
	echo"<div style='text-align:center;font-weight:bold;font-size:35px;margin-top:50px'>Data Perusahaan Gagal Di Edit</div>";
}

header("refresh:1; url=../../?m=15");
}
?>