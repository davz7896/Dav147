<?php
include("../../plugin/php/config.php");

$username = mysql_real_escape_string($_POST['username']);
$pass = mysql_real_escape_string(md5($_POST['pass']));

$query = mysql_query("select*from t_admin where username_admin='$username' and pass_admin='$pass' and stat_admin='1'");
$rows = mysql_num_rows($query);

if($rows==0){
	echo"Gagal";
}else{
	$data_admin = mysql_fetch_array($query);
	session_start();
	$_SESSION['admin'] = $data_admin['id_admin'];
	echo"Sukses";
}
?>