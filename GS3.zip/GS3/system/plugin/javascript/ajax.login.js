// JavaScript Document

function login(){
	username = document.getElementById("username").value;
	pass = document.getElementById("pass").value;
	
	url_login = "system/proses/system/login.php";	
		
	if(window.XMLHttpRequest){
		ajax_login = new XMLHttpRequest();
	}else{
		ajax_login = new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	ajax_login.onreadystatechange=function(){
		if(ajax_login.readyState==4 && ajax_login.status==200){
			if(ajax_login.responseText=="Sukses"){
				document.getElementById("place-of-load-ajax").innerHTML="";
				document.getElementById("login-alert").style.transition="1s";
				document.getElementById("login-alert").style.background="#090";
				document.getElementById("login-alert").innerHTML="Login "+ajax_login.responseText;
				document.location="system/";
			}else{
				document.getElementById("login-alert").style.transition="1s";
				document.getElementById("login-alert").style.background="#C00";
				document.getElementById("login-alert").innerHTML="Login "+ajax_login.responseText;
				document.getElementById("place-of-load-ajax").innerHTML="";
			}
		}else{
			document.getElementById("place-of-load-ajax").innerHTML="<img src='system/asset/image/loading.gif' width='20px' height='20px'/>";
		}
	}
	
	ajax_login.open("POST",url_login,true);
	ajax_login.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	ajax_login.send("username="+username+"&pass="+pass);
}