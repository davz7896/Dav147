// JavaScript Document


$(document).ready(function(){
	$(document).keydown(function(e){		
		if(e.which==118){
			document.location="?m=18";
		}else if(e.which==119){
			document.location="?m=4";
		}else if(e.which==120){
			document.location="?m=5";
		}else if(e.which==27){
			outlay();
		}
	});
});

function printDiv(elementId) {
    var a = document.getElementById('printing-css').value;
    var b = document.getElementById(elementId).innerHTML;
    window.frames["print_frame"].document.title = document.title;
    window.frames["print_frame"].document.body.innerHTML = '<style>' + a + '</style>' + b;
    window.frames["print_frame"].window.focus();
    window.frames["print_frame"].window.print();
}


function direct_page(page){
	document.location=page;
}

function outlay(){
	$("#overlay").hide(1);
}


function show_notif(){
	$("#overlay").show(1000);
	$("#overlay").html("<div class='notif-data'><div class='notif-title' onclick='outlay()'>Pemberitahuan</div><div id='notif-list'></div></div>");
}

function money_produk(harga){
	harga = document.getElementById("harga-produk").value;
	harga_tambah_tipe = accounting.formatMoney(harga, "Rp.", 0, ".", ",");
	document.getElementById("view-ajax-field-harga-produk").innerHTML=harga_tambah_tipe;
}

function next_page_hover(gambar){
	gambar="<img src='asset/icon/next_hover.png' />";
}

function cek_username(username){
	pola = /^[a-zA-Z0-9\_\-]{0,100}$/;
	
	if(!pola.test(username)){
		document.getElementById("hasil-script-username").innerHTML="<font color='red' style='line-height:30px'>Tidak Boleh Simbol</font>";
		document.getElementById("field-pass-admin").disabled="disabled";
		document.getElementById("field-pass-confirm-admin").disabled="disabled";
		document.getElementById("field-nama-admin").disabled="disabled";
		document.getElementById("field-level-admin").disabled="disabled";
		document.getElementById("button-admin").disabled="disabled";
	}else{
		document.getElementById("hasil-script-username").innerHTML="";
		document.getElementById("field-pass-admin").disabled="";
		document.getElementById("field-pass-confirm-admin").disabled="";
		document.getElementById("field-nama-admin").disabled="";
		document.getElementById("field-level-admin").disabled="";
		document.getElementById("button-admin").disabled="";		
	}
}

function cek_password(pass,panjang){
	pola = /^[a-zA-Z0-9\_\-]{0,100}$/;
	
	if(!pola.test(pass)){
		document.getElementById("hasil-script-pass").innerHTML="<font color='red' style='line-height:30px'>Tidak Boleh Simbol</font>";
		document.getElementById("field-pass-confirm-admin").disabled="disabled";
		document.getElementById("field-nama-admin").disabled="disabled";
		document.getElementById("field-level-admin").disabled="disabled";
		document.getElementById("button-admin").disabled="disabled";
	}else{
		document.getElementById("field-pass-confirm-admin").disabled="";
		document.getElementById("field-nama-admin").disabled="";
		document.getElementById("field-level-admin").disabled="";
		document.getElementById("button-admin").disabled="";
		
		pola_huruf = /^[a-zA-Z\_\-]{0,100}$/;
		pola_angka = /^[0-9]{0,100}$/;
		
		if(panjang<=5){
			document.getElementById("hasil-script-pass").innerHTML="<center><img src='asset/icon/weak-pass.png' height='20px' width='200px' style='margin-top:5px;border:1px solid #CCC'><center>";
		}else if(panjang<=7){
			document.getElementById("hasil-script-pass").innerHTML="<center><img src='asset/icon/enough-pass.png' height='20px' width='200px' style='margin-top:5px;border:1px solid #CCC'><center>";
		}else if(panjang>7){
			document.getElementById("hasil-script-pass").innerHTML="<center><img src='asset/icon/good-pass.png' height='20px' width='200px' style='margin-top:5px;border:1px solid #CCC'><center>";
		}
	}
}

function confirm_password(konfirm){
	konfirm = document.getElementById("field-pass-confirm-admin").value;
	pass = document.getElementById("field-pass-admin").value;
	if(konfirm==pass){
		document.getElementById("hasil-script-confirm-pass").innerHTML="<center><img src='asset/icon/check.png' width='20px' height='20px' style='margin-top:5px'><center>";
		document.getElementById("field-nama-admin").disabled="";
		document.getElementById("field-level-admin").disabled="";
		document.getElementById("button-admin").disabled="";
	}else{
		document.getElementById("hasil-script-confirm-pass").innerHTML="<center><img src='asset/icon/uncheck.png' width='20px' height='20px' style='margin-top:5px'><center>";
		document.getElementById("field-nama-admin").disabled="disabled";
		document.getElementById("field-level-admin").disabled="disabled";
		document.getElementById("button-admin").disabled="disabled";
	}
}

function tampilkan_cicilan_pilihan(pil){
	
	produk = document.getElementById("pilihan-beli-produk").value;
	
	if(pil==0 && produk==0){
		document.getElementById("hasil-field-cicilan-produk").innerHTML="Rp.0";
	}else{
	
	bunga = document.getElementById("bunga-pilihan-pembelian").innerHTML;
	dp = document.getElementById("field-dp-plgn").value;
	harga = document.getElementById("harga-pilihan-pembelian").innerHTML;
	
			hasil_bunga = ( bunga / 100 ) * harga;
			hasil_bagi = ( harga - dp) / pil;
			hasil_cicilan = hasil_bagi + hasil_bunga;
			view_cicilan = accounting.formatMoney(hasil_cicilan, "Rp.", 0, ".", ",");
			
			document.getElementById("hasil-field-cicilan-produk").innerHTML=view_cicilan+"<input type='hidden' name='sisaku' value='"+hasil_cicilan+"'>";
	}
}

function tampilkan_dp_pelanggan(nilai){
	view_dp = accounting.formatMoney(nilai, "Rp.", 0, ".", ",");
	document.getElementById("hasil-field-dp").innerHTML=view_dp;
	hargaku = document.getElementById("harga-pilihan-pembelian").innerHTML;		
}

function slide_down_me(divme){
	$(divme).slideDown("slow");
}

function tampil_dp_bayar_pelanggan(nilai){
	view_dp = accounting.formatMoney(nilai, "Rp.",0,".",",");
	document.getElementById("hasil-dp-bayar-data-pelanggan").innerHTML=view_dp;
}

function bayar_kurang_dp(kode){
	document.getElementById("form-data-pelanggan").innerHTML="<form method='post' action='proses/pelanggan/bayar_dp.php'><input type='hidden' name='kode' value='"+kode+"'><input type='number' id='dp-bayar-data-pelanggan' name='dp' placeholder='Uang Muka ( DP )' onkeyup='tampil_dp_bayar_pelanggan(this.value)' class='input-field' style='float:left; margin-right:10px'><div id='hasil-dp-bayar-data-pelanggan' style='float:left; margin-right:10px;line-height:30px'>Rp.0</div><input type='submit' class='button-class' value='Bayar'></center></form><div class='clr'></div><br><hr><br>";
}
