<?php
$data_admin = mysql_fetch_array(mysql_query("select*from t_admin where id_admin='$admin'"));

$data_username_admin = $data_admin['username_admin'];
$data_nama_admin = $data_admin['nama_admin'];
$data_level_admin = $data_admin['level_admin'];
?>