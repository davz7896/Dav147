<?php
$data_perusahaan = mysql_fetch_array(mysql_query("select*from t_perusahaan where kode_perusahaan='si_kredit'"));

$nama_perusahaan = $data_perusahaan['nama_perusahaan'];
$alamat_perusahaan = $data_perusahaan['alamat_perusahaan'];
$telp_perusahaan = $data_perusahaan['telp_perusahaan'];
$mail_perusahaan = $data_perusahaan['mail_perusahaan'];
$web_perusahaan = $data_perusahaan['web_perusahaan'];
?>