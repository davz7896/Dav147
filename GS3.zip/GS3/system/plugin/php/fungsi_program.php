<?php
function compress($url,$dir,$qty){
	$info = getimagesize($url);
	
	if($info['mime']=='image/jpeg'){
		$image = imagecreatefromjpeg($url);
		imagejpeg($image,$dir,$qty);
	}else if($info['mime']=='image/gif'){
		$image = imagecreatefromgif($url);
		imagegif($image,$dir,$qty);
	}else if($info['mime']=='image/png'){
		$image = imagecreatefrompng($url);
		imagepng($image,$dir,$qty);
	}
	
	return $dir;
}

function getTitle($m){
	include("plugin/php/title.php");
}

function getJudul($m,$nama_perusahaan){
	include("plugin/php/judul.php");
}

function getHalaman($m,$p,$k,$data_level_admin,$nama_perusahaan,$alamat_perusahaan){
	include("plugin/php/includes.php");
}

function getMenu(){
	include("plugin/php/menu.php");
}

function getTanggal(){
	$tgl_web = date("d - m - Y");
	echo"$tgl_web";
}

function namaPerusahaan($nama){
	echo"<div class='copy-footer'>&copy; $nama 2015</div>";
}

function footerData($alamat,$telp,$mail,$web){
	echo"
	Alamat : $alamat <br>
	Telp : $telp <br>
	E-mail : $mail <br>
	Web : $web
	";
}

?>