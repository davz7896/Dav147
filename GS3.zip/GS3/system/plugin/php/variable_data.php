<?php
if(!isset($_SESSION['admin'])){
	header("location:../");
}else{
	$admin = $_SESSION['admin'];
}

include("plugin/php/admindata.php");


if(!isset($_GET['m'])){
	$m = 1;
}else{
	$m = $_GET['m'];
}

if(!isset($_GET['k'])){
	$k = 0;
}else{
	$k = $_GET['k'];
}

if(!isset($_GET['p'])){
	$p = 1;
}else{
	$p = $_GET['p'];
}
?>