<?php ob_start(); ?>
<html>
<head>
	<title>Cetak PDF</title>
	<style>
		table {
			border-collapse:collapse;
			table-layout:fixed;width: 630px;
		}
		table td {
			word-wrap:break-word;
			width: 20%;
		}
		div.a {
        text-align: center;
}
	</style>
</head>
<body>
	<?php
	// Load file koneksi.php
	include "koneksi.php";

	if(isset($_GET['filter']) && ! empty($_GET['filter'])){ // Cek apakah user telah memilih filter
		$filter = $_GET['filter']; // Ambil data filder yang dipilih user

		if($filter == '1'){ // Jika filter nya 1 (per tanggal)
			$tgl = date('d-m-y', strtotime($_GET['tanggal']));
			echo '<div class="a">';
			echo '<h2><b> Laporan Penjualan Kavling</b></h2><br /><br />';
			echo '</div>';
			echo '<b>Tanggal '.$tgl.'</b><br /><br />';
			

			$query = "SELECT * FROM penjualan WHERE DATE(tgl_mulaiterjual)='".$_GET['tanggal']."'"; // Tampilkan data penjualan sesuai tanggal yang diinput oleh user pada filter
		}else if($filter == '2'){ // Jika filter nya 2 (per bulan)
			$nama_bulan = array('', 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');
			echo '<div class="a">';
			echo '<h2><b> Laporan Penjualan Kavling</b></h2><br /><br />';
			echo '</div>';
			echo '<b>Data Penjualan Bulan '.$nama_bulan[$_GET['bulan']].' '.$_GET['tahun'].'</b><br /><br />';

			$query = "SELECT * FROM penjualan WHERE MONTH(tgl_mulaiterjual)='".$_GET['bulan']."' AND YEAR(tgl_mulaiterjual)='".$_GET['tahun']."'"; // Tampilkan data transaksi sesuai bulan dan tahun yang diinput oleh user pada filter
		}else{ // Jika filter nya 3 (per tahun)
			echo '<div class="a">';
			echo '<h2><b> Laporan Penjualan Kavling</b></h2><br /><br />';
			echo '</div>';
			echo '<b>Data Penjualan Tahun '.$_GET['tahun'].'</b><br /><br />';

			$query = "SELECT * FROM penjualan WHERE YEAR(tgl_mulaiterjual)='".$_GET['tahun']."'"; // Tampilkan data penjualan sesuai tahun yang diinput oleh user pada filter
		}
	}else{ // Jika user tidak memilih filter
		echo '<b>Semua Data Penjualan </b><br /><br />';
		echo '<div class="a">';
	    echo '<h2><b> Laporan Penjualan Kavling</b></h2><br /><br />';
		echo '</div>';

		$query = "SELECT * FROM penjualan ORDER BY tgl_mulaiterjual"; // Tampilkan semua data penjualan diurutkan berdasarkan tanggal
	}
	?>
	<table class="table table-striped table-hover" id="dataTables-example" border="1">
	<thead>
	<tr>

		<th >Kode Transaksi</th>
        <th >Id Pelanggan</th>
        <th >Id Kavling</th>
        <th >No Kavling</th>
        <th >Tanggal Jual</th>
        <th >UTJ</th>
        <th >DP</th>
		<th >Angsuran</th>
        <th >Harga</th>
	</tr>
	</thead> 

	<tbody>
	<?php
	$sql = mysqli_query($connect, $query); // Eksekusi/Jalankan query dari variabel $query
	$row = mysqli_num_rows($sql); // Ambil jumlah data dari hasil eksekusi $sql

	if($row > 0){ // Jika jumlah data lebih dari 0 (Berarti jika data ada)
		while($data = mysqli_fetch_array($sql)){ // Ambil semua data dari hasil eksekusi $sql
			$tgl = date('d-m-Y', strtotime($data['tgl_mulaiterjual'])); // Ubah format tanggal jadi dd-mm-yyyy

			echo "<tr>";
			echo "<td  width='70'>".$data['kode_transaksi']."</td>";
            echo "<td  width='70'>".$data['id_pelanggan']."</td>";
            echo "<td  width='70'>".$data['id_kavling']."</td>";
            echo "<td  width='70'>".$data['no_kavling']."</td>";
            echo "<td  width='70'>".$data['tgl_mulaiterjual']."</td>";
            echo "<td  width='70'>".$data['utj']."</td>";
		echo "<td  width='70'>".$data['dp']."</td>";
		echo "<td  width='70'>".$data['angsuran']."</td>";
		echo "<td  width='70'>".$data['harga']."</td>";
			echo "</tr>";
		}
	}else{ // Jika data tidak ada
		echo "<tr><td colspan='5'>Data tidak ada</td></tr>";
	}
	?>
	 </tbody>  
	</table>
</body>
</html>
<?php
$html = ob_get_contents();
ob_end_clean();

require_once('plugin2/html2pdf/html2pdf.class.php');
$pdf = new HTML2PDF('P','A4','en');
$pdf->WriteHTML($html);
$pdf->Output('Data Penjualan.pdf', 'D');
?>
