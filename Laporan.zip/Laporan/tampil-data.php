<?php
// Load file koneksi.php
include "koneksi.php";
?>

<html>
<style type="text/css">
   .left    { text-align: left;}
   .right   { text-align: right;}
   .center  { text-align: center;}
   .justify { text-align: justify;}
   /* Penomoran otomatis pada baris */
.noTab {
  counter-reset: serial-number;  /* Atur penomoran ke 0 */
}
.noTab td:first-child:before {
  counter-increment: serial-number;  /* Kenaikan penomoran */
  content: counter(serial-number);  /* Tampilan counter */
}

</style>
<head>
  
    <link rel="stylesheet" href="plugin2/jquery-ui/jquery-ui.min.css" /> <!-- Load file css jquery-ui -->


    <!-- Fungsi untuk membatasi karakter yang diinputkan -->
    <script src="js2/jquery.min.js"></script> <!-- Load file jquery -->
  </head>
<body>
<div class="row">
    <div class="col-md-12">
      <div class="page-header">
        <h4>
          <i class="glyphicon glyphicon-user"></i> <?=$_SESSION['nama'];?>
        
        </h4>
      </div>
<div class="panel panel-default">
        <div class="panel-heading">
          <h3 class="panel-title">Data Laporan Transaksi</h3>
        </div>

<div class="form-group">    
<form method="get" action="">
        <label><h5><b>Filter Berdasarkan</b></h5></label><br>
        <select name="filter" id="filter">
            <option value="">Pilih</option>
            <option value="1">Per Tanggal</option>
            <option value="2">Per Bulan</option>
            <option value="3">Per Tahun</option>
        </select>
        <br /><br/>
<div>
        <div id="form-tanggal">
            <label>Tanggal</label><br>
            <input type="Date" name="tanggal" />
            <br /><br />
        </div>

        <div id="form-bulan">
            <label>Bulan</label><br>
            <select name="bulan">
                <option value="">Pilih</option>
                <option value="1">Januari</option>
                <option value="2">Februari</option>
                <option value="3">Maret</option>
                <option value="4">April</option>
                <option value="5">Mei</option>
                <option value="6">Juni</option>
                <option value="7">Juli</option>
                <option value="8">Agustus</option>
                <option value="9">September</option>
                <option value="10">Oktober</option>
                <option value="11">November</option>
                <option value="12">Desember</option>
            </select>
            <br /><br />
        </div>

        <div id="form-tahun">
            <label>Tahun</label><br>
            <select name="tahun">
                <option value="">Pilih</option>
                <?php
                $query = "SELECT YEAR(tgl_mulaiterjual) AS tahun FROM penjualan GROUP BY YEAR(tgl_mulaiterjual)"; // Tampilkan tahun sesuai di tabel penjualan
                $sql = mysqli_query($connect, $query); // Eksekusi/Jalankan query dari variabel $query

                while($data = mysqli_fetch_array($sql)){ // Ambil semua data dari hasil eksekusi $sql
                    echo '<option value="'.$data['tahun'].'">'.$data['tahun'].'</option>';
                }

                $time = strtotime('tgl_mulaiterjual');
 
                $newformat = date('Y-m-d',$time);
                ?>
            </select>
            <br /><br />
        </div>

        <button type="submit" class="btn btn-success">Tampilkan</button>
        <a href="index.php" class="btn btn-info">
          <span class="glyphicon glyphicon-refresh"></span> Riset PDF
        </a>
    </form>
    <hr />

    <?php
    if(isset($_GET['filter']) && ! empty($_GET['filter'])){ // Cek apakah user telah memilih filter dan klik tombol tampilkan
        $filter = $_GET['filter']; // Ambil data filder yang dipilih user

        if($filter == '1'){ // Jika filter nya 1 (per tanggal)
            $tgl = date('d-m-y', strtotime($_GET['tanggal']));

            echo '<b><h4> Data Penjualan Tanggal '.$tgl.'</h4></b><br /><br />';
            echo '<a href="print.php?filter=1&tanggal='.$_GET['tanggal'].'" class="btn btn-info " >  <span class="glyphicon glyphicon-print"></span> Cetak PDF</a><br /><br />';

            $query = "SELECT * FROM penjualan WHERE DATE(tgl_mulaiterjual)='".$_GET['tanggal']."'"; // Tampilkan data penjualan sesuai tanggal yang diinput oleh user pada filter
        }else if($filter == '2'){ // Jika filter nya 2 (per bulan)
            $nama_bulan = array('', 'Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember');

            echo '<b><h4>Data Penjualan Bulan '.$nama_bulan[$_GET['bulan']].' '.$_GET['tahun'].'</h4></b><br /><br />';
            echo '<a href="print.php?filter=2&bulan='.$_GET['bulan'].'&tahun='.$_GET['tahun'].'" class="btn btn-info" >  <span class="glyphicon glyphicon-print"></span>Cetak PDF</a><br /><br />';

            $query = "SELECT * FROM penjualan WHERE MONTH(tgl_mulaiterjual)='".$_GET['bulan']."' AND YEAR(tgl_mulaiterjual)='".$_GET['tahun']."'"; // Tampilkan data penjualan sesuai bulan dan tahun yang diinput oleh user pada filter
        }else{ // Jika filter nya 3 (per tahun)
            echo '<b><h4>Data Penjualan Tahun '.$_GET['tahun'].'</h4></b><br /><br />';
            echo '<a href="print.php?filter=3&tahun='.$_GET['tahun'].'" class="btn btn-info " >  <span class="glyphicon glyphicon-print"></span>Cetak PDF</a><br /><br />';

            $query = "SELECT * FROM penjualan WHERE YEAR(tgl_mulaiterjual)='".$_GET['tahun']."'"; // Tampilkan data penjualan sesuai tahun yang diinput oleh user pada filter
        }
    }else{ // Jika user tidak mengklik tombol tampilkan
        echo '<b><h4>Semua Data Penjualan </h4> </b><br /><br />';
        echo '<a href="print.php" class="btn btn-info" > <span class="glyphicon glyphicon-print"></span> Cetak PDF</a><br /><br />';

        $query = "SELECT * FROM penjualan ORDER BY tgl_mulaiterjual"; // Tampilkan semua data penjualan diurutkan berdasarkan tanggal
    }

    ?>
<div class="noTab">
<table class="table table-striped table-hover" id="dataTables-example">
<thead>
    <tr>
        <th>No</th>
        <th>Kode Transaksi</th>
        <th>Id Pelanggan</th>
        <th>Id Kavling</th>
        <th>No Kavling</th>
        <th>Tanggal Jual</th>
        <th>UTJ</th>
        <th>DP</th>
        <th>Angsuran</th>
        <th>Harga</th>
    </tr>
    </thead> 

    <tbody>
    <?php
  
    $sql = mysqli_query($connect, $query); // Eksekusi/Jalankan query dari variabel $query
    $row = mysqli_num_rows($sql); // Ambil jumlah data dari hasil eksekusi $sql

    if($row > 0){ // Jika jumlah data lebih dari 0 (Berarti jika data ada)
        while($data = mysqli_fetch_array($sql)){ // Ambil semua data dari hasil eksekusi $sql
            $tgl = date('d-m-Y', strtotime($data['tgl_mulaiterjual'])); // Ubah format tanggal jadi dd-mm-yyyy

            echo "<tr>
            <td width='50' class='center'></td>";
            echo "<td>".$data['kode_transaksi']."</td>";
            echo "<td>".$data['id_pelanggan']."</td>";
            echo "<td>".$data['id_kavling']."</td>";
            echo "<td>".$data['no_kavling']."</td>";
            echo "<td>".$data['tgl_mulaiterjual']."</td>";
            echo "<td>".$data['utj']."</td>";
            echo "<td>".$data['dp']."</td>";
            echo "<td>".$data['angsuran']."</td>";
            echo "<td>".$data['harga']."</td>";
            echo "</tr>";
        }
    }else{ // Jika data tidak ada
        echo "<tr><td colspan='5'>Data tidak ada</td></tr>";
    }
   
    ?>
    </tbody>   
    </table>
    </div>
    <script>
    $(document).ready(function(){ // Ketika halaman selesai di load
        $('.input-tanggal').datepicker({
            dateFormat: 'yy-mm-dd' // Set format tanggalnya jadi yyyy-mm-dd
        });

        $('#form-tanggal, #form-bulan, #form-tahun').hide(); // Sebagai default kita sembunyikan form filter tanggal, bulan & tahunnya

        $('#filter').change(function(){ // Ketika user memilih filter
            if($(this).val() == '1'){ // Jika filter nya 1 (per tanggal)
                $('#form-bulan, #form-tahun').hide(); // Sembunyikan form bulan dan tahun
                $('#form-tanggal').show(); // Tampilkan form tanggal
            }else if($(this).val() == '2'){ // Jika filter nya 2 (per bulan)
                $('#form-tanggal').hide(); // Sembunyikan form tanggal
                $('#form-bulan, #form-tahun').show(); // Tampilkan form bulan dan tahun
            }else{ // Jika filternya 3 (per tahun)
                $('#form-tanggal, #form-bulan').hide(); // Sembunyikan form tanggal dan bulan
                $('#form-tahun').show(); // Tampilkan form tahun
            }

            $('#form-tanggal input, #form-bulan select, #form-tahun select').val(''); // Clear data pada textbox tanggal, combobox bulan & tahun
        })
    })
    </script>
    <script src="plugin2/jquery-ui/jquery-ui.min.js"></script> <!-- Load file plugin js jquery-ui -->
</body>
</html>
